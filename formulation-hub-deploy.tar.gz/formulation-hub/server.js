'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { loadEnv, sign, verify, parseCookies, readBody, safeEqual } = require('./lib/util');
const { GoogleClient, GoogleStore } = require('./lib/google');
const { MockStore, MockAI } = require('./lib/mock');
const { RealAI } = require('./lib/ai');
const { App, parisParts, parisToday, MAX_PDF } = require('./lib/app');
const { Users } = require('./lib/users');
const { Veille } = require('./lib/veille');

const ROOT = __dirname;
const envFile = process.env.ENV_FILE || '/etc/formulation-hub/.env';
const env = loadEnv(envFile);
const MOCK = env.MOCK === '1';
const PORT = parseInt(env.PORT || '8080', 10);
const HOST = env.HOST || '0.0.0.0';
const DATA_DIR = env.DATA_DIR || (MOCK ? path.join(ROOT, 'data') : '/var/lib/formulation-hub');
const PASSWORD = env.APP_PASSWORD;
const SECRET = env.SESSION_SECRET;

function fatal(m) { console.error('ERREUR DE CONFIGURATION : ' + m); process.exit(1); }
if (!PASSWORD || PASSWORD.length < 8) fatal('APP_PASSWORD manquant ou trop court (8 caracteres minimum).');
if (!SECRET || SECRET.length < 24) fatal('SESSION_SECRET manquant ou trop court.');

let app;
const users = new Users(DATA_DIR);
const veille = new Veille(DATA_DIR, path.join(ROOT, 'prompts', 'veille_sources.json'));
if (MOCK) {
  const fix = path.join(ROOT, 'tests', 'fixtures');
  app = new App({ store: new MockStore(path.join(fix, 'mock_seed.json')), ai: new MockAI(fix), users, veille, dataDir: DATA_DIR, mock: true });
} else {
  if (!env.GEMINI_API_KEY) fatal('GEMINI_API_KEY manquant.');
  if (!env.SPREADSHEET_ID) fatal('SPREADSHEET_ID manquant.');
  const saFile = env.GOOGLE_SA_FILE || '/etc/formulation-hub/service-account.json';
  if (!fs.existsSync(saFile)) fatal('Fichier du compte de service introuvable : ' + saFile);
  const g = new GoogleClient(JSON.parse(fs.readFileSync(saFile, 'utf8')));
  app = new App({
    store: new GoogleStore(g, env.SPREADSHEET_ID), users, veille, dataDir: DATA_DIR, mock: false,
    ai: new RealAI({ key: env.GEMINI_API_KEY, model: env.GEMINI_MODEL, promptsDir: path.join(ROOT, 'prompts'), onRetry: (n, ms) => console.log(`Gemini occupe, nouvel essai ${n} dans ${ms / 1000}s`) })
  });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const SESSION_MS = 30 * 24 * 3600 * 1000;
const attempts = new Map();

function secHeaders(res, https) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  if (https) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}
function send(res, status, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': b.length }); res.end(b);
}
function isHttps(req) { return req.headers['x-forwarded-proto'] === 'https'; }
function clientIp(req) {
  // Derriere le reverse proxy, seule la DERNIERE adresse de X-Forwarded-For est ajoutee par le proxy (les autres
  // viennent du client et sont falsifiables). CF-Connecting-IP est ignore : on n'est pas derriere Cloudflare.
  const xff = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean);
  return xff.length ? xff[xff.length - 1] : req.socket.remoteAddress;
}
function session(req) { const c = parseCookies(req.headers.cookie); return verify(SECRET, c.fh_session); }
function cleanName(n) { const s = String(n || '').normalize('NFC').replace(/[^\p{L}\p{M}' -]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 30); return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
function sameOrigin(req) {
  const o = req.headers.origin; if (!o) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
}

async function api(req, res, url) {
  const m = req.method; const p = url.pathname;
  if (!sameOrigin(req)) return send(res, 403, { error: 'Origine refusee' });

  if (p === '/api/login' && m === 'POST') {
    const ip = clientIp(req); const now = Date.now();
    const a = (attempts.get(ip) || []).filter(t => now - t < 10 * 60 * 1000);
    if (a.length >= 8) return send(res, 429, { error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
    let body = {}; try { body = JSON.parse((await readBody(req, 4096)).toString() || '{}'); } catch { /* vide */ }
    const who = cleanName(body.name);
    if (!who) return send(res, 400, { error: 'Indiquez votre prénom' });
    if (!safeEqual(String(body.password || ''), PASSWORD)) { a.push(now); attempts.set(ip, a); await new Promise(r => setTimeout(r, 600)); return send(res, 401, { error: 'Mot de passe incorrect' }); }
    attempts.delete(ip);
    const tok = sign(SECRET, { exp: Date.now() + SESSION_MS, n: who, r: crypto.randomBytes(6).toString('hex') });
    res.setHeader('Set-Cookie', `fh_session=${encodeURIComponent(tok)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_MS / 1000}${isHttps(req) ? '; Secure' : ''}`);
    return send(res, 200, { ok: true, name: who });
  }
  if (p === '/api/logout' && m === 'POST') {
    res.setHeader('Set-Cookie', 'fh_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); return send(res, 200, { ok: true });
  }
  const sess = session(req);
  if (!sess || !sess.n) return send(res, 401, { error: 'Connexion requise' });
  const me = sess.n;

  const J = async (limit = 1 << 20) => { const b = await readBody(req, limit); try { return JSON.parse(b.toString() || '{}'); } catch { throw Object.assign(new Error('JSON invalide'), { status: 400 }); } };
  let mm;
  if (p === '/api/me' && m === 'GET') { const pp = parisParts(); return send(res, 200, { name: me, mock: MOCK, ui: app.ui(), today: parisToday(), date: `${pp.weekday} ${pp.day} ${pp.month} ${pp.year}` }); }
  if (p === '/api/home' && m === 'GET') {
    const favIds = users.favs(me);
    return send(res, 200, { recents: users.recents(me), favs: await app.favoriteItems(favIds.slice(0, 5)), agenda: users.agenda(me, parisToday(), parisToday()) });
  }
  if (p === '/api/mps' && m === 'GET') return send(res, 200, { items: await app.listMPs(url.searchParams.get('q') || '') });
  if (p === '/api/mp-names' && m === 'GET') return send(res, 200, { items: await app.allNames() });
  if (p === '/api/mps' && m === 'POST') { const b = await J(); return send(res, 200, await app.addMP(b.name)); }
  if (p === '/api/export.csv' && m === 'GET') {
    const csv = await app.exportCSV(url.searchParams.get('q') || '');
    res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="matieres-premieres.csv"', 'Cache-Control': 'no-store' }); return res.end(csv);
  }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)$/))) {
    if (m === 'GET') { const d = await app.getMP(mm[1]); d.fav = users.favs(me).includes(mm[1]); return send(res, 200, d); }
    if (m === 'PUT') { const b = await J(); return send(res, 200, await app.updateMP(mm[1], b.changes, me)); }
  }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)\/open$/)) && m === 'POST') { const d = await app.getMP(mm[1]); return send(res, 200, { recents: users.pushRecent(me, mm[1], d.fields['Trade name']) }); }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)\/verify$/)) && m === 'POST') return send(res, 200, await app.updateMP(mm[1], { Statut: 'Verifie' }, me));
  if ((mm = p.match(/^\/api\/favs\/(MP-\d+)$/))) {
    if (m === 'PUT') return send(res, 200, { favs: users.addFav(me, mm[1]) });
    if (m === 'DELETE') return send(res, 200, { favs: users.removeFav(me, mm[1]) });
  }
  if (p === '/api/favs' && m === 'GET') return send(res, 200, { items: await app.favoriteItems(users.favs(me)) });
  if (p === '/api/compare' && m === 'POST') { const b = await J(); return send(res, 200, { items: await app.compare(b.ids) }); }
  if (p === '/api/upload' && m === 'POST') { const buf = await readBody(req, MAX_PDF + 1024); return send(res, 200, app.saveUpload(url.searchParams.get('name'), buf)); }
  if (p === '/api/extract' && m === 'POST') { const b = await J(); return send(res, 200, app.startExtract(b.mp_id, b.files)); }
  if ((mm = p.match(/^\/api\/jobs\/([a-f0-9]+)$/)) && m === 'GET') return send(res, 200, app.getJob(mm[1]));
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)$/))) {
    if (m === 'GET') return send(res, 200, app.getNotes(mm[1]));
    if (m === 'PUT') { const b = await J(); return send(res, 200, app.saveNotesText(mm[1], b.text)); }
  }
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)\/image$/)) && m === 'POST') return send(res, 200, app.saveNoteImage(mm[1], await readBody(req, 6 * 1024 * 1024)));
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)\/image\/([A-Za-z0-9_.-]+)$/)) && m === 'DELETE') return send(res, 200, app.deleteNoteImage(mm[1], mm[2]));
  if ((mm = p.match(/^\/api\/note-img\/([A-Za-z0-9_.-]+)$/)) && m === 'GET') {
    const f = app.noteImagePath(mm[1]); if (!f) return send(res, 404, { error: 'Image introuvable' });
    const ext = path.extname(f).slice(1); res.writeHead(200, { 'Content-Type': ext === 'jpg' ? 'image/jpeg' : 'image/' + ext, 'Cache-Control': 'private, max-age=3600' }); return fs.createReadStream(f).pipe(res);
  }
  // bloc-notes libre
  if (p === '/api/bloc' && m === 'GET') return send(res, 200, { items: users.notes(me) });
  if (p === '/api/bloc' && m === 'POST') { const b = await J(); return send(res, 200, users.addNote(me, b.title, b.text)); }
  if ((mm = p.match(/^\/api\/bloc\/([a-f0-9]+)$/))) {
    if (m === 'PUT') { const b = await J(); return send(res, 200, users.updateNote(me, mm[1], b.title, b.text)); }
    if (m === 'DELETE') { users.deleteNote(me, mm[1]); return send(res, 200, { ok: true }); }
  }
  // agenda et rappels
  if (p === '/api/agenda' && m === 'GET') return send(res, 200, { items: users.agenda(me, url.searchParams.get('from') || '', url.searchParams.get('to') || '') });
  if (p === '/api/agenda' && m === 'POST') { const b = await J(); return send(res, 200, users.addEvent(me, b)); }
  if ((mm = p.match(/^\/api\/agenda\/([a-f0-9]+)$/)) && m === 'DELETE') { users.deleteEvent(me, mm[1]); return send(res, 200, { ok: true }); }
  // veille : liste de liens
  if (p === '/api/veille' && m === 'GET') return send(res, 200, await veille.get());
  return send(res, 404, { error: 'Introuvable' });
}

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname); if (rel === '/') rel = '/index.html';
  const f = path.normalize(path.join(ROOT, 'public', rel));
  if (!f.startsWith(path.join(ROOT, 'public') + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Introuvable'); }
  const ext = path.extname(f);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.woff2' ? 'public, max-age=31536000, immutable' : 'no-cache' });
  fs.createReadStream(f).pipe(res);
}

const server = http.createServer(async (req, res) => {
  secHeaders(res, isHttps(req));
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, url);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error(new Date().toISOString(), req.method, url.pathname, e.message);
    if (!res.headersSent) send(res, status, { error: status >= 500 && !e.expose ? (e.message || 'Erreur interne') : e.message });
  }
});
server.requestTimeout = 0; server.headersTimeout = 30000;

(async () => {
  try { await app.init(); } catch (e) { console.error('Demarrage : ' + e.message + ' (le site demarre quand meme)'); }
  server.listen(PORT, HOST, () => console.log(`Formulation Hub pret sur http://${HOST}:${PORT} ${MOCK ? '(mode demonstration)' : ''}`));
})();
process.on('SIGTERM', () => server.close(() => process.exit(0)));
