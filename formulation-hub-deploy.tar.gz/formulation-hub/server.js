'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { loadEnv, sign, verify, parseCookies, readBody, safeEqual } = require('./lib/util');
const { GoogleClient, GoogleStore, GoogleDrive } = require('./lib/google');
const { MockStore, MockDrive, MockAI } = require('./lib/mock');
const { RealAI } = require('./lib/ai');
const { App, parisParts } = require('./lib/app');
const { CATS, FONCS } = require('./lib/schemas');

const ROOT = __dirname;
const envFile = process.env.ENV_FILE || '/etc/formulation-hub/.env';
const env = loadEnv(envFile);
const MOCK = env.MOCK === '1';
const PORT = parseInt(env.PORT || '8080', 10);
const HOST = env.HOST || '0.0.0.0';
const DATA_DIR = env.DATA_DIR || (MOCK ? path.join(ROOT, 'data') : '/var/lib/formulation-hub');
const PASSWORD = env.APP_PASSWORD;
const SECRET = env.SESSION_SECRET;

function fatal(m) { console.error('ERREUR DE CONFIGURATION : ' + m); process.exit(1); }
if (!PASSWORD || PASSWORD.length < 8) fatal('APP_PASSWORD manquant ou trop court (8 caracteres minimum).');
if (!SECRET || SECRET.length < 24) fatal('SESSION_SECRET manquant ou trop court.');

let app;
if (MOCK) {
  const fix = path.join(ROOT, 'tests', 'fixtures');
  app = new App({ store: new MockStore(path.join(fix, 'mock_seed.json')), drive: new MockDrive(fix), ai: new MockAI(fix), dataDir: DATA_DIR, mock: true });
} else {
  if (!env.GEMINI_API_KEY) fatal('GEMINI_API_KEY manquant.');
  if (!env.SPREADSHEET_ID) fatal('SPREADSHEET_ID manquant.');
  const saFile = env.GOOGLE_SA_FILE || '/etc/formulation-hub/service-account.json';
  if (!fs.existsSync(saFile)) fatal('Fichier du compte de service introuvable : ' + saFile);
  const g = new GoogleClient(JSON.parse(fs.readFileSync(saFile, 'utf8')));
  app = new App({
    store: new GoogleStore(g, env.SPREADSHEET_ID), drive: new GoogleDrive(g), dataDir: DATA_DIR, mock: false,
    ai: new RealAI({ key: env.GEMINI_API_KEY, model: env.GEMINI_MODEL, promptsDir: path.join(ROOT, 'prompts'), onRetry: (n, ms) => console.log(`Gemini occupe, nouvel essai ${n} dans ${ms / 1000}s`) })
  });
}

app.veilleEnabled = env.VEILLE !== '0';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const SESSION_MS = 30 * 24 * 3600 * 1000;
const attempts = new Map();

function secHeaders(res, https) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  if (https) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
}
function send(res, status, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': b.length }); res.end(b);
}
function isHttps(req) { return req.headers['x-forwarded-proto'] === 'https'; }
function clientIp(req) {
  // Derriere le reverse proxy, seule la DERNIERE adresse de X-Forwarded-For est ajoutee par le proxy (les autres
  // viennent du client et sont falsifiables). CF-Connecting-IP est ignore : on n'est pas derriere Cloudflare.
  const xff = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean);
  return xff.length ? xff[xff.length - 1] : req.socket.remoteAddress;
}
function authed(req) { const c = parseCookies(req.headers.cookie); return !!verify(SECRET, c.fh_session); }
function sameOrigin(req) {
  const o = req.headers.origin; if (!o) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
}

async function api(req, res, url) {
  const m = req.method; const p = url.pathname;
  if (!sameOrigin(req)) return send(res, 403, { error: 'Origine refusee' });

  if (p === '/api/login' && m === 'POST') {
    const ip = clientIp(req); const now = Date.now();
    const a = (attempts.get(ip) || []).filter(t => now - t < 10 * 60 * 1000);
    if (a.length >= 8) return send(res, 429, { error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
    let body = {}; try { body = JSON.parse((await readBody(req, 4096)).toString() || '{}'); } catch { /* vide */ }
    if (!safeEqual(String(body.password || ''), PASSWORD)) { a.push(now); attempts.set(ip, a); await new Promise(r => setTimeout(r, 600)); return send(res, 401, { error: 'Mot de passe incorrect' }); }
    attempts.delete(ip);
    const tok = sign(SECRET, { exp: Date.now() + SESSION_MS, n: crypto.randomBytes(6).toString('hex') });
    res.setHeader('Set-Cookie', `fh_session=${encodeURIComponent(tok)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_MS / 1000}${isHttps(req) ? '; Secure' : ''}`);
    return send(res, 200, { ok: true });
  }
  if (p === '/api/logout' && m === 'POST') {
    res.setHeader('Set-Cookie', 'fh_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); return send(res, 200, { ok: true });
  }
  if (!authed(req)) return send(res, 401, { error: 'Connexion requise' });

  const J = async (limit = 1 << 20) => { const b = await readBody(req, limit); try { return JSON.parse(b.toString() || '{}'); } catch { throw Object.assign(new Error('JSON invalide'), { status: 400 }); } };
  let mm;
  if (p === '/api/me' && m === 'GET') { const pp = parisParts(); return send(res, 200, { mock: MOCK, lists: { cats: CATS, foncs: FONCS }, date: `${pp.weekday} ${pp.day} ${pp.month} ${pp.year}` }); }
  if (p === '/api/mps' && m === 'GET') return send(res, 200, { items: await app.listMPs(url.searchParams.get('q') || '') });
  if (p === '/api/mp-names' && m === 'GET') return send(res, 200, { items: await app.allNames() });
  if (p === '/api/mps' && m === 'POST') { const b = await J(); return send(res, 200, await app.addMP(b.name)); }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)$/))) {
    if (m === 'GET') { const d = await app.getMP(mm[1]); return send(res, 200, d); }
    if (m === 'PUT') { const b = await J(); return send(res, 200, await app.updateMP(mm[1], b.changes)); }
  }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)\/open$/)) && m === 'POST') { const d = await app.getMP(mm[1]); return send(res, 200, { recents: app.pushRecent(mm[1], d.fields['Trade name']) }); }
  if ((mm = p.match(/^\/api\/mp\/(MP-\d+)\/verify$/)) && m === 'POST') return send(res, 200, await app.updateMP(mm[1], { Statut: 'Verifie' }));
  if (p === '/api/recents' && m === 'GET') return send(res, 200, { items: app.recents() });
  if (p === '/api/compare' && m === 'POST') { const b = await J(); return send(res, 200, { items: await app.compare(b.ids) }); }
  if (p === '/api/drive/search' && m === 'GET') { const q = (url.searchParams.get('q') || '').trim(); if (q.length < 2) return send(res, 200, { items: [] }); return send(res, 200, await app.searchDrive(q)); }
  if (p === '/api/upload' && m === 'POST') { const buf = await readBody(req, 18 * 1024 * 1024 + 1024); return send(res, 200, app.saveUpload(url.searchParams.get('name'), buf)); }
  if (p === '/api/extract' && m === 'POST') { const b = await J(); return send(res, 200, app.startExtract(b.mp_id, b.files)); }
  if (p === '/api/formula' && m === 'POST') { const b = await J(); return send(res, 200, app.startFormula(b.file, b.replace)); }
  if ((mm = p.match(/^\/api\/jobs\/([a-f0-9]+)$/)) && m === 'GET') return send(res, 200, app.getJob(mm[1]));
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)$/))) {
    if (m === 'GET') return send(res, 200, app.getNotes(mm[1]));
    if (m === 'PUT') { const b = await J(); return send(res, 200, app.saveNotesText(mm[1], b.text)); }
  }
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)\/image$/)) && m === 'POST') return send(res, 200, app.saveNoteImage(mm[1], await readBody(req, 6 * 1024 * 1024)));
  if ((mm = p.match(/^\/api\/notes\/(MP-\d+)\/image\/([A-Za-z0-9_.-]+)$/)) && m === 'DELETE') return send(res, 200, app.deleteNoteImage(mm[1], mm[2]));
  if ((mm = p.match(/^\/api\/note-img\/([A-Za-z0-9_.-]+)$/)) && m === 'GET') {
    const f = app.noteImagePath(mm[1]); if (!f) return send(res, 404, { error: 'Image introuvable' });
    const ext = path.extname(f).slice(1); res.writeHead(200, { 'Content-Type': ext === 'jpg' ? 'image/jpeg' : 'image/' + ext, 'Cache-Control': 'private, max-age=3600' }); return fs.createReadStream(f).pipe(res);
  }
  if (p === '/api/veille' && m === 'GET') {
    const v = app.getVeille();
    if (app.needsVeille() && !app.veilleRunning) app.runVeille().catch(e => console.error('Veille : ' + e.message));
    return send(res, 200, { veille: v, loading: app.veilleRunning });
  }
  if (p === '/api/veille/run' && m === 'POST') { app.runVeille(true).catch(e => console.error('Veille : ' + e.message)); return send(res, 200, { started: true }); }
  return send(res, 404, { error: 'Introuvable' });
}

function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname); if (rel === '/') rel = '/index.html';
  const f = path.normalize(path.join(ROOT, 'public', rel));
  if (!f.startsWith(path.join(ROOT, 'public') + path.sep) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Introuvable'); }
  const ext = path.extname(f);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.woff2' ? 'public, max-age=31536000, immutable' : 'no-cache' });
  fs.createReadStream(f).pipe(res);
}

const server = http.createServer(async (req, res) => {
  secHeaders(res, isHttps(req));
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, url);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error(new Date().toISOString(), req.method, url.pathname, e.message);
    if (!res.headersSent) send(res, status, { error: status >= 500 && !e.expose ? (e.message || 'Erreur interne') : e.message });
  }
});
server.requestTimeout = 0; server.headersTimeout = 30000;

(async () => {
  try { await app.init(); } catch (e) { console.error('Demarrage : ' + e.message + ' (le site demarre quand meme)'); }
  server.listen(PORT, HOST, () => console.log(`Formulation Hub pret sur http://${HOST}:${PORT} ${MOCK ? '(mode demonstration)' : ''}`));
  // Veille : verification toutes les heures (le lundi a partir de 7 h, rattrapage ensuite)
  setInterval(() => { if (app.needsVeille() && !app.veilleRunning) app.runVeille().catch(e => console.error('Veille : ' + e.message)); }, 60 * 60 * 1000).unref();
  setTimeout(() => { if (app.needsVeille() && !app.veilleRunning) app.runVeille().catch(e => console.error('Veille : ' + e.message)); }, 20000).unref();
})();
process.on('SIGTERM', () => server.close(() => process.exit(0)));
