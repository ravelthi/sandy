#!/bin/bash
# Usage (en root, dans le conteneur) : bash install.sh <dossier-du-projet | archive.tar.gz>
set -euo pipefail
SRC="${1:?Indiquer le dossier du projet ou l archive .tar.gz}"
command -v node >/dev/null 2>&1 && node -e 'process.exit(+process.versions.node.split(".")[0]>=22?0:1)' || {
  apt-get update && apt-get install -y curl ca-certificates openssl
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
}
id hub >/dev/null 2>&1 || useradd --system --home /opt/formulation-hub --shell /usr/sbin/nologin hub
rm -rf /opt/formulation-hub.new && mkdir -p /opt/formulation-hub.new
if [ -d "$SRC" ]; then cp -a "$SRC"/. /opt/formulation-hub.new/ && rm -rf /opt/formulation-hub.new/.git; else tar -xzf "$SRC" -C /opt/formulation-hub.new --strip-components=1; fi
rm -rf /opt/formulation-hub && mv /opt/formulation-hub.new /opt/formulation-hub
chown -R root:root /opt/formulation-hub
mkdir -p /etc/formulation-hub /var/lib/formulation-hub
chown hub:hub /var/lib/formulation-hub
if [ ! -f /etc/formulation-hub/.env ]; then
  cp /opt/formulation-hub/deploy/.env.example /etc/formulation-hub/.env
  sed -i "s|^SESSION_SECRET=.*|SESSION_SECRET=$(openssl rand -hex 32)|" /etc/formulation-hub/.env
fi
chown root:hub /etc/formulation-hub /etc/formulation-hub/.env
chmod 750 /etc/formulation-hub; chmod 640 /etc/formulation-hub/.env
cp /opt/formulation-hub/deploy/formulation-hub.service /etc/systemd/system/
systemctl daemon-reload && systemctl enable formulation-hub
echo "Installe. Reste a remplir /etc/formulation-hub/.env et deposer service-account.json, puis : systemctl restart formulation-hub && curl http://127.0.0.1:8080/health"
