# Mise en service - Formulation Hub

## 1. Compte de service Google (une fois)
1. console.cloud.google.com : creer un projet, activer **Google Sheets API**.
2. IAM et administration > Comptes de service > Creer. Puis onglet Cles > Ajouter une cle > JSON. Garder le fichier.
3. Copier l'adresse e-mail du compte de service (xxx@projet.iam.gserviceaccount.com).
4. Dans Google Drive : partager le **Google Sheet** avec cette adresse (Editeur).
5. Depuis le conteneur : deposer le JSON dans `/etc/formulation-hub/service-account.json` (proprietaire root, groupe hub, chmod 640).

## 2. Cle Gemini
aistudio.google.com/apikey : creer une cle (regenerer celle des tests). La coller dans `GEMINI_API_KEY`.

## 3. Fichier de configuration
Editer `/etc/formulation-hub/.env` : `APP_PASSWORD`, `GEMINI_API_KEY`, `SPREADSHEET_ID`. `SESSION_SECRET` est genere par install.sh.

## 4. Demarrage
`systemctl restart formulation-hub` puis `curl http://127.0.0.1:8080/health` doit repondre `ok`. Logs : `journalctl -u formulation-hub -f`.

## 5. Lien public
**Option A - proxy existant (Nginx Proxy Manager ou autre) :** creer un hote proxy `sous-domaine.ton-domaine` vers `http://<IP du conteneur>:8080`, activer le certificat SSL (Let's Encrypt) et la redirection HTTPS. Le pare-feu doit autoriser le proxy a joindre le conteneur sur le port 8080 (et lui seul). `HOST=0.0.0.0` dans le .env. Aucun tunnel ni nouveau domaine necessaire.

**Option B - Cloudflare Tunnel :** cloudflared vers `http://127.0.0.1:8080` (HOST=127.0.0.1), avec un nom de domaine. Voir la phase 4 du prompt Chrome.

## 6. Sauvegardes
Activer une sauvegarde Proxmox du conteneur (les notes sont dans /var/lib/formulation-hub). Les donnees principales sont dans le Google Sheet.
