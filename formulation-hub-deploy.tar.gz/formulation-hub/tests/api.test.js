'use strict';
// Test de bout en bout en mode demonstration : node tests/api.test.js
const { spawn } = require('child_process');
const fs = require('fs'); const os = require('os'); const path = require('path');
const assert = require('assert');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'fh-'));
const PORT = 18000 + Math.floor(Math.random() * 1000);
const env = Object.assign({}, process.env, { MOCK: '1', PORT: String(PORT), HOST: '127.0.0.1', DATA_DIR: dir, APP_PASSWORD: 'motdepasse-test', SESSION_SECRET: 'x'.repeat(40), ENV_FILE: '/nonexistent' });
const srv = spawn(process.execPath, ['server.js'], { env, cwd: path.join(__dirname, '..') });
let log = ''; srv.stdout.on('data', d => { log += d; }); srv.stderr.on('data', d => { log += d; });
const base = 'http://127.0.0.1:' + PORT; let cookie = '';
async function call(method, url, body, raw) {
  const opts = { method, headers: { Cookie: cookie } };
  if (raw) { opts.body = raw; opts.headers['Content-Type'] = 'application/pdf'; } else if (body !== undefined) { opts.body = JSON.stringify(body); opts.headers['Content-Type'] = 'application/json'; }
  const r = await fetch(base + url, opts);
  const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, body: ct.includes('json') ? await r.json() : await r.text() };
}
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  for (let i = 0; i < 40; i++) { try { const r = await fetch(base + '/health'); if (r.ok) break; } catch { /* attente */ } await wait(150); }
  let r;
  r = await call('GET', '/api/me'); assert.equal(r.status, 401, 'connexion requise');
  r = await call('POST', '/api/login', { name: 'Sandy', password: 'mauvais' }); assert.equal(r.status, 401);
  r = await call('POST', '/api/login', { name: '', password: 'motdepasse-test' }); assert.equal(r.status, 400);
  r = await call('POST', '/api/login', { name: 'sandy', password: 'motdepasse-test' }); assert.equal(r.status, 200); assert.equal(r.body.name, 'Sandy');
  r = await call('GET', '/api/me'); assert.equal(r.body.name, 'Sandy'); assert.equal(r.body.ui.groups.length, 5); assert.equal(r.body.ui.cats.length, 23); assert.equal(r.body.ui.foncs.length, 36);

  // recherche + ajout
  r = await call('GET', '/api/mps?q=camellia oil'); const cam = r.body.items.find(x => x.name === 'CAMELLIA OIL'); assert.ok(cam, 'CAMELLIA OIL present');
  r = await call('POST', '/api/mps', { name: 'Ma nouvelle MP' }); assert.match(r.body.id, /^MP-\d{4}$/); const newId = r.body.id;
  r = await call('POST', '/api/mps', { name: 'ma nouvelle mp' }); assert.equal(r.status, 409, 'doublon refuse');
  const max = Math.max(...(await call('GET', '/api/mp-names')).body.items.map(x => +x.id.slice(3))); assert.equal('MP-' + String(max).padStart(4, '0'), newId, 'identifiant = dernier + 1');

  // upload + extraction de 2 documents
  r = await call('POST', '/api/upload?name=notpdf.pdf', undefined, Buffer.from('hello')); assert.equal(r.status, 400, 'non PDF refuse');
  const up1 = (await call('POST', '/api/upload?name=TDS.pdf', undefined, Buffer.from('%PDF-mock:tds'))).body;
  const up2 = (await call('POST', '/api/upload?name=MSDS.pdf', undefined, Buffer.from('%PDF-mock:sds'))).body;
  const up3 = (await call('POST', '/api/upload?name=trad.pdf', undefined, Buffer.from('%PDF-mock:skipped'))).body;
  r = await call('POST', '/api/extract', { mp_id: cam.id, files: [up1, up2, up3] }); assert.equal(r.status, 200);
  let job; for (let i = 0; i < 60; i++) { job = (await call('GET', '/api/jobs/' + r.body.job)).body; if (job.status !== 'running') break; await wait(200); }
  assert.equal(job.status, 'done', JSON.stringify(job)); assert.equal(job.result.docsRead, 2); assert.equal(job.result.skipped.length, 1);
  r = await call('POST', '/api/upload?name=gone.pdf', undefined, Buffer.from('%PDF-mock:tds')); // les PDF utilises sont oublies
  const g = await call('POST', '/api/extract', { mp_id: cam.id, files: [up1] }); assert.equal(g.status, 400, 'document deja analyse = supprime');

  r = await call('GET', '/api/mp/' + cam.id); const f = r.body.fields;
  assert.equal(f['Categories'], 'Agents émollients et relipidants'); assert.equal(f['Fonction'], 'Hydratant');
  assert.equal(f['Flash point'], '316 °C'); assert.equal(f['Vegan'], 'Oui'); assert.equal(f['Palm'], 'Non'); assert.equal(f['Halal'], '', 'Oui/Non absent = vide');
  assert.equal(f['Color'], 'Jaune pâle'); assert.equal(f['Dosage max'], 100);
  assert.ok(r.body.sources['Point d\'éclair'].includes('MSDS')); assert.ok(r.body.sources['Vegan'].includes('TDS'));
  assert.ok(r.body.toVerify.some(t => t.field === 'Nom INCI'), 'ecart INCI signale'); assert.ok(r.body.toVerify.some(t => t.field === 'Fournisseur'));
  assert.equal(r.body.toVerify.filter(t => t.field === 'Nom INCI').length, 1, 'une seule entree par champ');

  // modification directe : valeur conservee, source = saisie manuelle, to_verify nettoye
  r = await call('PUT', '/api/mp/' + cam.id, { changes: { INCI: 'Camellia Oleifera Seed Oil', Fonction: 'Hydratant, Apaisant', Halal: 'Oui', 'pH min': '5,5', 'Chemical formula': 'C18H34O2' } });
  assert.equal(r.status, 200); assert.equal(r.body.fields['Fonction'], 'Hydratant, Apaisant'); assert.equal(r.body.fields['pH min'], 5.5);
  assert.ok(!r.body.toVerify.some(t => t.field === 'Nom INCI'), 'point corrige = retire'); assert.ok(r.body.toVerify.some(t => t.field === 'Fournisseur'));
  assert.ok(r.body.sources['Nom INCI'].startsWith('Saisie manuelle'));
  r = await call('PUT', '/api/mp/' + cam.id, { changes: { Categories: 'Inconnue' } }); assert.equal(r.status, 400);
  r = await call('PUT', '/api/mp/' + cam.id, { changes: { Fonction: 'Pas une fonction' } }); assert.equal(r.status, 400);
  r = await call('PUT', '/api/mp/' + cam.id, { changes: { 'pH min': 'abc' } }); assert.equal(r.status, 400);
  r = await call('PUT', '/api/mp/' + cam.id, { changes: { mp_id: 'MP-9999' } }); assert.equal(r.status, 400, 'identifiant non modifiable');
  r = await call('POST', '/api/mp/' + cam.id + '/verify'); assert.equal(r.body.fields.Statut, 'Verifie');
  assert.equal(r.body.toVerify.length, 0);

  // une nouvelle analyse n'ecrase rien
  const up4 = (await call('POST', '/api/upload?name=TDS2.pdf', undefined, Buffer.from('%PDF-mock:tds'))).body;
  r = await call('POST', '/api/extract', { mp_id: cam.id, files: [up4] });
  for (let i = 0; i < 60; i++) { job = (await call('GET', '/api/jobs/' + r.body.job)).body; if (job.status !== 'running') break; await wait(200); }
  r = await call('GET', '/api/mp/' + cam.id); assert.equal(r.body.fields['INCI'], 'Camellia Oleifera Seed Oil', 'valeur saisie conservee'); assert.equal(r.body.fields['Fonction'], 'Hydratant, Apaisant');

  // favoris, recents, bloc-notes, agenda (par utilisatrice)
  r = await call('PUT', '/api/favs/' + cam.id); assert.deepEqual(r.body.favs, [cam.id]);
  r = await call('POST', '/api/mp/' + cam.id + '/open'); assert.equal(r.body.recents[0].id, cam.id);
  r = await call('GET', '/api/favs'); assert.equal(r.body.items[0].name, 'CAMELLIA OIL');
  r = await call('POST', '/api/bloc', { title: 'Idée', text: 'Tester un baume' }); const nid = r.body.id;
  r = await call('PUT', '/api/bloc/' + nid, { text: 'Tester un baume solide' }); assert.equal(r.body.text, 'Tester un baume solide');
  r = await call('GET', '/api/bloc'); assert.equal(r.body.items.length, 1);
  const today = (await call('GET', '/api/me')).body.today;
  r = await call('POST', '/api/agenda', { date: today, time: '09:30', title: 'Appeler le fournisseur', color: 'blue' }); const eid = r.body.id;
  r = await call('POST', '/api/agenda', { date: 'pas une date', title: 'x' }); assert.equal(r.status, 400);
  r = await call('GET', '/api/home'); assert.equal(r.body.agenda.length, 1); assert.equal(r.body.favs.length, 1); assert.equal(r.body.recents.length, 1);
  r = await call('PUT', '/api/agenda/' + eid, { date: today, time: '10:00', title: 'Appeler le fournisseur (modifie)', color: 'amber', note: 'Demander la SDS' }); assert.equal(r.status, 200); assert.equal(r.body.note, 'Demander la SDS'); assert.equal(r.body.time, '10:00');
  r = await call('PUT', '/api/agenda/ffffffff', { date: today, title: 'x' }); assert.equal(r.status, 404);
  r = await call('DELETE', '/api/agenda/' + eid); r = await call('GET', '/api/agenda?from=2000-01-01&to=2100-01-01'); assert.equal(r.body.items.length, 0);
  // autre utilisatrice : donnees separees
  const saved = cookie; cookie = '';
  r = await call('POST', '/api/login', { name: 'Marie', password: 'motdepasse-test' }); r = await call('GET', '/api/favs'); assert.equal(r.body.items.length, 0, 'favoris par prenom');
  cookie = saved;

  // comparaison jusqu'a 10, export CSV, veille
  const ids = (await call('GET', '/api/mps?q=a')).body.items.slice(0, 10).map(x => x.id);
  r = await call('POST', '/api/compare', { ids: ids.concat(['MP-0001', 'MP-0002']) }); assert.ok(r.body.items.length <= 10 && r.body.items.length >= 3);
  r = await call('GET', '/api/export.csv?q=camellia oil'); assert.ok(r.body.includes('CAMELLIA OIL')); assert.ok(r.body.includes('Identifiant;Nom commercial'));
  r = await call('GET', '/api/veille'); assert.ok(Array.isArray(r.body.sites) && r.body.salons.length >= 1);
  r = await call('POST', '/api/logout'); cookie = ''; r = await call('GET', '/api/home'); assert.equal(r.status, 401);
  console.log('TOUS LES TESTS PASSENT');
})().catch(e => { console.error('ECHEC :', e.message); console.error(log); process.exitCode = 1; }).finally(() => { srv.kill(); fs.rmSync(dir, { recursive: true, force: true }); });
