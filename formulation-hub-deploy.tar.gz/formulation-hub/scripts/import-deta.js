'use strict';
// Pre-remplit les fiches avec les informations du fichier DETA (scripts/deta-import.json).
//   node scripts/import-deta.js            : simulation (n'ecrit rien)
//   node scripts/import-deta.js --apply    : ecrit dans le Google Sheet
// Regles : une cellule deja remplie n'est jamais ecrasee ; chaque valeur importee est marquee "DETA (import)" ;
// toutes les informations d'origine de DETA (y compris celles sans champ equivalent) sont gardees dans la colonne deta_info.
const fs = require('fs');
const path = require('path');
const { loadEnv } = require('../lib/util');
const { GoogleClient, GoogleStore } = require('../lib/google');
const { MockStore } = require('../lib/mock');
const { EXTRA_COLUMNS, BY_HEADER } = require('../lib/schemas');

const APPLY = process.argv.includes('--apply');
const ROOT = path.join(__dirname, '..');
const env = loadEnv(process.env.ENV_FILE || '/etc/formulation-hub/.env');
const key = s => String(s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim().toUpperCase();
const empty = v => v === '' || v === null || v === undefined;

(async () => {
  let store;
  if (process.env.MOCK === '1') store = new MockStore(path.join(ROOT, 'tests', 'fixtures', 'mock_seed.json'));
  else {
    const sa = JSON.parse(fs.readFileSync(env.GOOGLE_SA_FILE || '/etc/formulation-hub/service-account.json', 'utf8'));
    store = new GoogleStore(new GoogleClient(sa), env.SPREADSHEET_ID);
  }
  await store.ensureHeaders('Raw_Materials', EXTRA_COLUMNS);
  const t = await store.loadTable('Raw_Materials');
  const deta = JSON.parse(fs.readFileSync(path.join(__dirname, 'deta-import.json'), 'utf8'));
  const byKey = new Map(); for (const r of t.rows) if (r.mp_id && r['Trade name'] && !byKey.has(key(r['Trade name']))) byKey.set(key(r['Trade name']), r);
  const items = []; let matched = 0, fieldsSet = 0, kept = 0; const unmatched = [];
  for (const d of deta) {
    const r = byKey.get(d.key);
    if (!r) { unmatched.push(d.name); continue; }
    matched++;
    const obj = { deta_info: JSON.stringify(d.entries) };
    let src = {}; try { src = JSON.parse(r.sources || '{}'); } catch { src = {}; }
    let n = 0;
    for (const [h, v] of Object.entries(d.mapped)) {
      if (!empty(r[h])) { kept++; continue; }
      obj[h] = v; src[(BY_HEADER[h] && BY_HEADER[h].label) || h] = 'DETA (import)'; n++;
    }
    if (n) { obj.sources = JSON.stringify(src); obj.Statut = r.Statut === 'Verifie' ? 'Verifie' : 'A verifier'; obj.updated_at = new Date().toISOString(); fieldsSet += n; }
    items.push({ row: r._row, obj });
  }
  console.log(`MP du fichier DETA : ${deta.length} ; retrouvees dans le Sheet : ${matched} ; non retrouvees : ${unmatched.length}`);
  if (unmatched.length) console.log('Non retrouvees :', unmatched.slice(0, 20).join(' | '));
  console.log(`Valeurs a ecrire : ${fieldsSet} ; deja remplies (conservees) : ${kept}`);
  if (!APPLY) { console.log('Simulation : rien n\'a ete ecrit. Relancer avec --apply pour ecrire.'); return; }
  await store.updateMany('Raw_Materials', items, t.headers);
  console.log('Ecriture terminee : ' + items.length + ' lignes mises a jour.');
})().catch(e => { console.error('ERREUR : ' + e.message); process.exit(1); });
