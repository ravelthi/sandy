'use strict';
(() => {
  const root = document.getElementById('root');
  const state = { me: null, cmp: [], names: null };
  try { state.cmp = JSON.parse(localStorage.getItem('fh_cmp') || '[]'); } catch { state.cmp = []; }
  const saveCmp = () => { try { localStorage.setItem('fh_cmp', JSON.stringify(state.cmp)); } catch { /* stockage indisponible */ } };

  // ---------- outils DOM (aucun innerHTML : tout passe par textContent) ----------
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (k === 'value') e.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected') e[k] = !!v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) { if (kid === null || kid === undefined || kid === false) continue; e.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return e;
  }
  const $ = (s, r = document) => r.querySelector(s);

  async function api(path, opts = {}) {
    const o = Object.assign({ headers: {} }, opts);
    if (o.json !== undefined) { o.method = o.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(o.json); delete o.json; }
    const r = await fetch(path, o);
    let j = {}; try { j = await r.json(); } catch { /* corps vide */ }
    if (r.status === 401 && path !== '/api/login') { renderLogin(); throw new Error('Connexion requise'); }
    if (!r.ok) throw new Error(j.error || 'Erreur ' + r.status);
    return j;
  }

  // ---------- coque de page ----------
  function shell(content) {
    root.replaceChildren(h('div', { class: 'fh-page' }, h('div', { class: 'fh-shell' },
      h('div', { style: 'height:4px;background:var(--color-text)' }),
      h('div', { class: 'fh-topbar', style: 'display:flex;align-items:baseline;justify-content:space-between;gap:14px;padding:9px 0 8px;flex-wrap:wrap' },
        h('a', { href: '#/', style: 'font-family:var(--font-heading);font-weight:600;font-size:20px;font-style:italic;line-height:1;color:var(--color-text)' }, 'Formulation Hub'),
        h('span', { style: 'font-size:10.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--color-neutral-700)' },
          (state.me ? cap(state.me.date) : '') + ' · Labo R&D', state.me && state.me.mock ? ' · DEMONSTRATION' : '', ' · ',
          h('a', { href: '#', onclick: async (e) => { e.preventDefault(); await api('/api/logout', { method: 'POST' }); renderLogin(); } }, 'Quitter'))),
      h('div', { style: 'height:1px;background:var(--color-text)' }),
      h('div', { style: 'padding-bottom:26px' }, content),
      h('div', { style: 'height:1px;background:var(--color-text);margin-top:10px' }),
      h('div', { class: 'fh-noprint', style: 'display:flex;flex-wrap:wrap;gap:6px 18px;justify-content:space-between;padding:10px 0 14px;font-size:11.5px;color:var(--color-neutral-700)' },
        h('span', {}, '© 2026 Thierry Ravelojaona. Tous droits réservés.'), h('span', {}, 'Formulation Hub')))));
  }
  const cap = s => String(s || '').charAt(0).toUpperCase() + String(s || '').slice(1);
  const back = () => h('button', { class: 'btn btn-ghost fh-noprint', style: 'margin:0 0 14px;padding-left:0', onclick: () => { location.hash = '#/'; } }, '← Retour à la recherche');
  const view = (...k) => h('div', { class: 'fh-view' }, ...k);
  const eyebrow = t => h('p', { class: 'fh-eyebrow' }, t);
  const title = t => h('h2', { class: 'fh-h2' }, t);
  const label = t => h('p', { class: 'fh-label' }, t);
  const err = t => h('p', { class: 'fh-err' }, t);

  // ---------- connexion ----------
  function renderLogin() {
    const pw = h('input', { class: 'input', type: 'password', placeholder: 'Mot de passe', autocomplete: 'current-password', style: 'min-height:42px;background:var(--color-neutral-100)' });
    const msg = h('p', { class: 'fh-err', style: 'min-height:20px;margin-top:10px' });
    const go = async () => {
      msg.textContent = '';
      try { await api('/api/login', { json: { password: pw.value } }); await boot(); } catch (e) { msg.textContent = e.message; }
    };
    pw.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    root.replaceChildren(h('div', { class: 'fh-page' }, h('div', { class: 'fh-login' },
      h('p', { style: 'font-family:var(--font-heading);font-weight:600;font-size:28px;font-style:italic;margin:0 0 20px' }, 'Formulation Hub'),
      pw, h('div', { style: 'margin-top:12px' }, h('button', { class: 'btn btn-primary', style: 'min-height:42px;width:100%', onclick: go }, 'Entrer')), msg)));
    pw.focus();
  }

  // ---------- recherche ----------
  async function viewHome() {
    shell(view(h('p', { style: 'color:var(--color-neutral-700)' }, 'Chargement...')));
    const [rec, ven] = await Promise.all([api('/api/recents'), api('/api/veille').catch(() => ({ veille: null }))]);
    const q = h('input', { class: 'input', type: 'text', placeholder: 'Nom de la matière première', style: 'min-height:42px;font-size:15px;background:var(--color-neutral-100)' });
    const go = () => { location.hash = '#/results/' + encodeURIComponent(q.value.trim()); };
    q.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    const addBox = h('div');
    let addOpen = false;
    const plus = h('button', { class: 'btn btn-secondary', title: 'Ajouter', style: 'min-height:42px;width:42px;padding:0;font-size:19px', onclick: () => { addOpen = !addOpen; drawAdd(); } }, '+');
    function drawAdd(mode) {
      if (!addOpen) { addBox.replaceChildren(); return; }
      const wrap = h('div', { class: 'fh-note', style: 'margin-top:16px;max-width:620px' }, h('p', { style: 'margin:0 0 10px;font-size:14px' }, 'Qu\'est-ce que vous voulez ajouter ?'));
      if (!mode) wrap.append(h('div', { style: 'display:flex;gap:10px' },
        h('button', { class: 'btn btn-secondary', onclick: () => drawAdd('mp') }, 'Une MP'),
        h('button', { class: 'btn btn-secondary', onclick: () => drawAdd('doc') }, 'Des documents')));
      if (mode === 'mp') {
        const n = h('input', { class: 'input', type: 'text', placeholder: 'Nom de la nouvelle MP', style: 'background:var(--color-neutral-100)' });
        const m = h('p', { class: 'fh-err' });
        wrap.append(h('div', { style: 'display:flex;gap:10px;align-items:center;max-width:420px' }, n, h('button', { class: 'btn btn-primary', style: 'white-space:nowrap', onclick: async () => {
          m.textContent = ''; try { const r = await api('/api/mps', { json: { name: n.value } }); location.hash = '#/extract/' + r.id; } catch (e) { m.textContent = e.message; } } }, 'Ajouter à la base')), m);
      }
      if (mode === 'doc') wrap.append(h('p', { style: 'margin:0 0 10px;font-size:13.5px;color:var(--color-neutral-700);max-width:46ch' },
        'Les documents se rangent dans le dossier Google Drive partagé. Pour analyser un fichier, ouvrez la matière première concernée : vous pourrez y déposer un PDF.'));
      if (mode) wrap.append(h('p', { style: 'margin:12px 0 0;font-size:12.5px;color:var(--color-accent-700);cursor:pointer', onclick: () => drawAdd() }, '← Retour'));
      addBox.replaceChildren(wrap);
    }
    const cmpBox = h('div'); drawCmpMini(cmpBox);
    const v = ven.veille;
    const nb = v ? v.sections.reduce((a, s) => a + s.items.length, 0) : 0;
    shell(view(
      title('Rechercher une matière première'),
      h('div', { style: 'display:flex;gap:10px;align-items:center;max-width:620px' }, q, h('button', { class: 'btn btn-primary', style: 'min-height:42px;padding:0 18px', onclick: go }, 'Rechercher'), plus),
      addBox,
      h('div', { class: 'fh-grid3', style: 'margin-top:34px' },
        h('div', {}, label('Recherches récentes'),
          rec.items.length ? rec.items.map(r => h('div', { class: 'fh-row fh-link', style: 'font-size:15px;display:flex;justify-content:space-between;gap:10px', onclick: () => { location.hash = '#/fiche/' + r.id; } }, h('span', {}, r.name), h('span', { style: 'font-size:12px;color:var(--color-neutral-600)' }, ago(r.at)))) : h('p', { style: 'font-size:13.5px;color:var(--color-neutral-700)' }, 'Aucune recherche pour le moment.')),
        cmpBox,
        h('div', {}, label('Cette semaine'),
          h('p', { style: 'margin:0 0 6px;font-family:var(--font-heading);font-weight:600;font-size:19px;line-height:1.15' }, v ? `Veille - ${nb} articles` : 'Veille de la semaine'),
          h('p', { style: 'margin:0 0 12px;font-size:13.5px;color:var(--color-neutral-700);max-width:40ch' }, v ? 'Tendances, produits, ingrédients, salons et brevets. Actualisée chaque lundi.' : (ven.loading ? 'La veille de la semaine est en préparation.' : 'Pas encore de veille cette semaine.')),
          h('button', { class: 'btn btn-secondary', onclick: () => { location.hash = '#/veille'; } }, 'Ouvrir la veille')))));
    q.focus();
  }
  function ago(iso) {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 2) return 'à l\'instant'; if (m < 60) return 'il y a ' + m + ' min'; const hr = Math.round(m / 60);
    if (hr < 24) return 'il y a ' + hr + ' h'; const d = Math.round(hr / 24); return d === 1 ? 'hier' : 'il y a ' + d + ' j';
  }

  // ---------- resultats ----------
  async function viewResults(q) {
    shell(view(back(), h('p', {}, 'Recherche...')));
    const r = await api('/api/mps?q=' + encodeURIComponent(q));
    const exact = r.items.filter(x => x.name.toLowerCase() === q.toLowerCase());
    if (exact.length === 1) return openMP(exact[0].id);
    shell(view(back(), eyebrow('Résultats'),
      title(`${r.items.length}${r.items.length === 100 ? '+' : ''} matières premières pour « ${q || 'toutes'} »`),
      h('div', { style: 'max-width:760px' }, r.items.length ? r.items.map(m => h('div', { class: 'fh-link', style: 'padding:15px 0;border-bottom:1px solid var(--color-divider)', onclick: () => openMP(m.id) },
        h('p', { style: 'margin:0 0 3px;font-family:var(--font-heading);font-weight:600;font-size:17px;line-height:1.2' }, m.name),
        h('p', { style: 'margin:0 0 6px;font-size:13px;color:var(--color-neutral-700)' }, [m.inci, m.supplier].filter(Boolean).join(' · ')),
        h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' }, m.cat ? h('span', { class: 'tag tag-accent' }, m.cat) : null, m.fn ? h('span', { class: 'tag tag-neutral' }, m.fn) : null,
          !m.inci && !m.cat ? h('span', { class: 'tag tag-accent-2' }, 'à extraire') : null))) : h('p', { style: 'color:var(--color-neutral-700)' }, 'Aucune matière première ne correspond. Utilisez + pour en ajouter une.'))));
  }
  async function openMP(id) {
    const d = await api('/api/mp/' + id);
    const filled = Object.keys(d.fields).filter(k => !['mp_id', 'Trade name', 'Statut', 'to_verify', 'updated_at'].includes(k) && d.fields[k] !== '' && d.fields[k] !== null).length;
    location.hash = filled > 0 ? '#/fiche/' + id : '#/extract/' + id;
  }

  // ---------- documents + extraction (composant partage) ----------
  function docsPanel(mp, onDone) {
    const box = h('div');
    const list = h('div'); const status = h('div');
    let files = []; const picked = new Set();
    const nameIn = h('input', { class: 'input', type: 'text', value: mp.fields['Trade name'] || '', style: 'min-height:40px;background:var(--color-neutral-100)' });
    async function search() {
      list.replaceChildren(h('p', { style: 'font-size:13px;color:var(--color-neutral-700)' }, 'Recherche dans Google Drive...'));
      try {
        const r = await api('/api/drive/search?q=' + encodeURIComponent(nameIn.value)); const keep = files.filter(f => f.local);
        files = keep.concat(r.items); files.forEach(f => { if (!f.off && !picked.has('x' + f.id)) { picked.add(f.id); picked.add('x' + f.id); } });
      } catch (e) { files = files.filter(f => f.local); list.replaceChildren(err(e.message)); return; }
      draw();
    }
    function draw() {
      list.replaceChildren(...(files.length ? files.map(f => h('label', { style: `display:flex;gap:11px;align-items:center;padding:8px 0;border-bottom:1px solid var(--color-divider);font-size:14px;opacity:${f.off ? .5 : 1};cursor:pointer` },
        h('input', { type: 'checkbox', checked: picked.has(f.id), style: 'accent-color:var(--color-accent);width:15px;height:15px', onchange: e => { e.target.checked ? picked.add(f.id) : picked.delete(f.id); sync(); } }),
        h('span', { style: 'flex:1;min-width:0;overflow-wrap:anywhere' }, f.name), h('span', { class: 'tag tag-neutral' }, f.local ? 'Envoyé' : f.kind)))
        : [h('p', { style: 'font-size:13.5px;color:var(--color-neutral-700);max-width:46ch' }, 'Aucun document trouvé pour ce nom. Essayez un autre nom, ou déposez un PDF ci-dessous.')]));
      sync();
    }
    const runBtn = h('button', { class: 'btn btn-primary', onclick: run }, 'Extraire les documents sélectionnés');
    const count = h('p', { style: 'margin:0 0 16px;font-family:var(--font-heading);font-weight:600;font-size:18px' });
    function sync() { const n = files.filter(f => picked.has(f.id)).length; count.textContent = n + (n > 1 ? ' documents sélectionnés' : ' document sélectionné'); runBtn.disabled = n === 0; }
    const file = h('input', { type: 'file', accept: 'application/pdf', multiple: true, style: 'display:none', onchange: e => upload([...e.target.files]) });
    const drop = h('div', { class: 'fh-drop', style: 'margin-top:12px', onclick: () => file.click() }, 'Déposer un PDF ici (analysé sans être enregistré dans Drive)');
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); upload([...e.dataTransfer.files]); });
    async function upload(fl) {
      for (const f of fl) {
        if (!/\.pdf$/i.test(f.name)) { status.replaceChildren(err('Seuls les PDF sont acceptés.')); continue; }
        try { const r = await api('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f, headers: { 'Content-Type': 'application/pdf' } }); files.unshift(r); picked.add(r.id); } catch (e) { status.replaceChildren(err(e.message)); }
      }
      draw();
    }
    async function run() {
      const sel = files.filter(f => picked.has(f.id)).map(f => ({ id: f.id, name: f.name, kind: f.kind }));
      runBtn.disabled = true;
      const bar = h('div', {}); const stepEl = h('p', { style: 'margin:0;font-size:13px;color:var(--color-neutral-700)' });
      const fill = h('div', { style: 'width:0%' });
      status.replaceChildren(h('p', { style: 'margin:0 0 10px;font-family:var(--font-heading);font-weight:600;font-size:18px' }, 'Extraction en cours…'), h('div', { class: 'fh-bar' }, fill), stepEl,
        h('p', { style: 'margin:8px 0 0;font-size:12px;color:var(--color-neutral-600)' }, 'Comptez environ une minute par document. Vous pouvez laisser cette page ouverte.'));
      void bar;
      try {
        const { job } = await api('/api/extract', { json: { mp_id: mp.id, files: sel } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500));
          const j = await api('/api/jobs/' + job);
          fill.style.width = j.pct + '%'; stepEl.textContent = j.step;
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') { showResult(j.result); break; }
        }
      } catch (e) { status.replaceChildren(err(e.message)); runBtn.disabled = false; }
    }
    function showResult(r) {
      const lines = [
        h('p', { style: 'margin:0 0 8px;font-family:var(--font-heading);font-weight:600;font-size:18px' }, `${r.filledTotal} champs remplis sur ${r.total}`),
        h('p', { style: 'margin:0 0 6px;font-size:13.5px;color:var(--color-neutral-700)' }, `${r.docsRead} document${r.docsRead > 1 ? 's' : ''} lu${r.docsRead > 1 ? 's' : ''}. ${r.filledNow} champ${r.filledNow > 1 ? 's' : ''} ajouté${r.filledNow > 1 ? 's' : ''}, ${r.missing} à compléter à la main.`),
        h('p', { style: 'margin:0 0 12px;font-size:13px;color:var(--color-accent-2-700)' }, 'Aucune valeur existante n\'a été écrasée.' + (r.toVerify ? ` ${r.toVerify} point${r.toVerify > 1 ? 's' : ''} à vérifier.` : ''))
      ];
      for (const s of r.skipped) {
        const row = h('div', { style: 'margin:0 0 10px;font-size:13px' }, h('span', {}, `${s.name} : ${s.reason}. `));
        if (s.formula) row.append(h('button', { class: 'btn btn-secondary', style: 'min-height:32px', onclick: () => importFormula(s, row) }, 'Importer comme formule'));
        lines.push(row);
      }
      for (const f of r.failed) lines.push(err(`${f.name} : ${f.error}`));
      lines.push(h('button', { class: 'btn btn-primary', onclick: () => { if (onDone) onDone(); else location.hash = '#/fiche/' + mp.id; } }, 'Voir la fiche'));
      status.replaceChildren(h('div', { class: 'fh-view', style: 'padding:0' }, ...lines)); runBtn.disabled = false;
    }
    async function importFormula(s, row, replace) {
      row.replaceChildren(h('span', { style: 'font-size:13px' }, 'Lecture de la formule...'));
      try {
        const { job } = await api('/api/formula', { json: { file: { id: s.id, name: s.name }, replace: !!replace } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500)); const j = await api('/api/jobs/' + job);
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') {
            const r = j.result;
            if (r.duplicate) { row.replaceChildren(h('span', {}, `La formule ${r.reference} existe déjà. `), h('button', { class: 'btn btn-secondary', style: 'min-height:32px', onclick: () => importFormula(s, row, true) }, 'Remplacer')); }
            else if (r.skipped) row.replaceChildren(h('span', {}, r.reason));
            else row.replaceChildren(h('span', {}, `Formule ${r.name || r.reference} importée : ${r.ingredients} ingrédients, somme ${r.sum}%${r.sumOk === false ? ' (différente du total annoncé)' : ''}, ${r.unmatched} non rattaché${r.unmatched > 1 ? 's' : ''} à la base.`));
            break;
          }
        }
      } catch (e) { row.replaceChildren(err(e.message)); }
    }
    box.append(h('div', { style: 'display:flex;gap:10px;align-items:center;margin-bottom:18px;max-width:460px' }, nameIn, h('button', { class: 'btn btn-secondary', style: 'min-height:40px;white-space:nowrap', onclick: search }, 'Relancer')), list, file, drop,
      h('div', { style: 'margin-top:22px' }, count, runBtn, h('div', { style: 'margin-top:16px' }, status)));
    nameIn.addEventListener('keydown', e => { if (e.key === 'Enter') search(); });
    search();
    return box;
  }
  async function viewExtract(id) {
    const mp = await api('/api/mp/' + id); mp.id = id;
    shell(view(back(), eyebrow('Étape 2 · Extraction'), title('Documents trouvés dans Google Drive'),
      h('p', { style: 'margin:-12px 0 20px;font-size:14px;color:var(--color-neutral-700)' }, mp.fields['Trade name']), docsPanel(mp)));
  }

  // ---------- fiche ----------
  const yesno = v => v === true || String(v).toUpperCase() === 'TRUE' ? 'Oui' : v === false || String(v).toUpperCase() === 'FALSE' ? 'Non' : '';
  const driveUrl = id => 'https://drive.google.com/file/d/' + encodeURIComponent(id) + '/view';
  const GROUPS = [
    ['Identification', [['Ingredient'], ['Trade name'], ['INCI'], ['Supplier'], ['Categories', 'cat'], ['Fonction', 'fn']]],
    ['Caractéristiques techniques', [['Dosage (min / max)', 'range', 'Dosage min', 'Dosage max', '%'], ['Solubility'], ['Drop point', 'num', '°C'], ['Flash point', 'num', '°C'], ['pH (min / max)', 'range', 'pH min', 'pH max', '']]],
    ['Compatibilité', [['Compatibilities'], ['Incompatibilities'], ['Warning']]],
    ['Organoleptique', [['Organoleptic characteristics'], ['Sensory']]],
    ['Réglementation et labels', [['Regulation'], ['IECIC China', 'bool'], ['COSMOS'], ['Vegan', 'bool'], ['ISO 16128 NOI', 'num'], ['ISO 16128 NI', 'num']]],
    ['Distribution et alternatives', [['Distribution countries'], ['Alternatives']]],
    ['Documents et références', [['TDS', 'doc'], ['SDS', 'doc'], ['Booklet', 'doc'], ['Publication'], ['Patents']]]
  ];
  const isEmpty = v => v === '' || v === null || v === undefined;
  function display(d, [lab, kind, a, b, unit]) {
    const f = d.fields;
    if (kind === 'range') { const lo = f[a], hi = f[b]; if (isEmpty(lo) && isEmpty(hi)) return ''; const u = unit ? ' ' + unit : ''; return isEmpty(hi) ? `${lo}${u}` : isEmpty(lo) ? `${hi}${u}` : `${lo} - ${hi}${u}`; }
    const v = f[lab]; if (isEmpty(v)) return '';
    if (kind === 'bool') return yesno(v);
    if (kind === 'num') return `${v}${a ? ' ' + a : ''}`;
    return String(v);
  }
  function missingCount(d) { let n = 0; GROUPS.forEach(([, rows]) => rows.forEach(r => { if (!display(d, r)) n++; })); return n; }

  async function viewFiche(id) {
    const d = await api('/api/mp/' + id); d.id = id;
    api('/api/mp/' + id + '/open', { method: 'POST' }).catch(() => { });
    const f = d.fields; const lists = state.me.lists;
    const notes = d.notes;
    const grid = h('div', { class: 'fh-cols' });
    const msg = h('p', { class: 'fh-err fh-noprint', style: 'min-height:18px' });
    async function save(changes) { try { msg.textContent = ''; const nd = await api('/api/mp/' + id, { method: 'PUT', json: { changes } }); nd.id = id; Object.assign(d, nd); drawGrid(); } catch (e) { msg.textContent = e.message; drawGrid(); } }
    function cell(row) {
      const [lab, kind, a, b] = row; const val = display(d, row);
      const wrap = h('span', {});
      const edit = () => {
        let input;
        if (kind === 'cat' || kind === 'fn') { input = h('select', { class: 'input fh-edit' }, h('option', { value: '' }, '(vide)'), (kind === 'cat' ? lists.cats : lists.foncs).map(o => h('option', { value: o, selected: f[lab] === o }, o))); }
        else if (kind === 'bool') input = h('select', { class: 'input fh-edit' }, ['', 'Oui', 'Non'].map(o => h('option', { value: o, selected: yesno(f[lab]) === o }, o || '(vide)')));
        else if (kind === 'range') input = h('input', { class: 'input fh-edit', type: 'text', placeholder: 'min - max', value: val.replace(/\s*(%|°C)$/, '') });
        else input = h('input', { class: 'input fh-edit', type: 'text', value: isEmpty(f[lab]) ? '' : f[lab] });
        wrap.replaceChildren(input); input.focus();
        let done = false;
        const commit = () => {
          if (done) return; done = true; const v = input.value;
          if (kind === 'range') { const parts = v.split(/\s*[-;\/]\s*/); save({ [a]: (parts[0] || '').trim(), [b]: (parts[1] !== undefined ? parts[1] : '').trim() }); }
          else save({ [lab]: v });
        };
        input.addEventListener('blur', commit);
        input.addEventListener('keydown', e => { if (e.key === 'Enter' && input.tagName !== 'TEXTAREA') { e.preventDefault(); input.blur(); } if (e.key === 'Escape') { done = true; drawGrid(); } });
      };
      if (kind === 'doc' && !isEmpty(f[lab]) && /^[A-Za-z0-9_-]{15,}$/.test(String(f[lab]))) return h('a', { href: driveUrl(f[lab]), target: '_blank', rel: 'noopener noreferrer' }, 'Ouvrir dans Drive');
      if (val) { wrap.append(h('span', { class: 'fh-link', title: 'Cliquer pour modifier', onclick: edit }, val)); }
      else wrap.append(h('span', { class: 'fh-empty', title: 'Cliquer pour renseigner', onclick: edit }, 'Non renseigné'));
      return wrap;
    }
    function drawGrid() {
      grid.replaceChildren(...GROUPS.map(([t, rows]) => h('div', { class: 'fh-group' }, h('p', { class: 'fh-group-title' }, t), rows.map(r => h('div', { class: 'fh-kv' }, h('span', {}, r[0]), cell(r))))));
      miss.textContent = missingCount(d) ? `${missingCount(d)} champs à compléter` : 'Tous les champs sont renseignés';
      statusTag.className = 'tag ' + (f.Statut === 'Verifie' ? 'tag-accent' : 'tag-accent-2'); statusTag.textContent = f.Statut === 'Verifie' ? 'Vérifié' : 'À vérifier';
    }
    const miss = h('span', { style: 'font-size:12.5px;color:var(--color-neutral-700)' });
    const statusTag = h('span', { class: 'tag' });
    const isCmp = () => state.cmp.some(c => c.id === id);
    const cmpBtn = h('button', { class: 'btn btn-secondary', onclick: () => { if (!isCmp()) { if (state.cmp.length >= 5) { msg.textContent = 'Maximum 5 matières premières dans la comparaison.'; return; } state.cmp.push({ id, name: f['Trade name'] }); saveCmp(); } location.hash = '#/compare'; } }, 'Comparer');
    // notes
    const ta = h('textarea', { class: 'input', placeholder: 'Ajouter une note, une remarque, un contexte…', style: 'background:var(--color-neutral-100);min-height:110px;font-size:14px' }); ta.value = notes.text || '';
    let tmr; const noteState = h('p', { style: 'margin:4px 0 0;font-size:12px;color:var(--color-neutral-600);min-height:16px' });
    ta.addEventListener('input', () => { clearTimeout(tmr); noteState.textContent = ''; tmr = setTimeout(async () => { try { await api('/api/notes/' + id, { method: 'PUT', json: { text: ta.value } }); noteState.textContent = 'Enregistré'; printNotes(); } catch (e) { noteState.textContent = e.message; } }, 800); });
    const imgs = h('div'); const printBox = h('div', { class: 'fh-onlyprint', style: 'margin-top:24px' });
    function drawImgs() {
      imgs.replaceChildren(...notes.images.map(n => h('div', { style: 'position:relative' }, h('img', { class: 'fh-notes-img', src: '/api/note-img/' + n, alt: 'Image de la note' }),
        h('button', { class: 'btn btn-ghost', style: 'font-size:12px;padding-left:0', onclick: async () => { const r = await api('/api/notes/' + id + '/image/' + n, { method: 'DELETE' }); notes.images = r.images; drawImgs(); printNotes(); } }, 'Retirer l\'image'))));
    }
    function printNotes() {
      printBox.replaceChildren(); if (!ta.value && !notes.images.length) return;
      printBox.append(h('p', { class: 'fh-group-title' }, 'Notes'), ta.value ? h('p', { style: 'white-space:pre-wrap;font-size:14px' }, ta.value) : null, ...notes.images.map(n => h('img', { class: 'fh-notes-img', src: '/api/note-img/' + n, alt: '' })));
    }
    const imgIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: 'display:none', onchange: async e => { const fl = e.target.files[0]; if (!fl) return; try { const r = await api('/api/notes/' + id + '/image', { method: 'POST', body: fl, headers: { 'Content-Type': fl.type } }); notes.images = r.images; drawImgs(); printNotes(); } catch (er) { noteState.textContent = er.message; } } });
    drawImgs(); printNotes(); drawGrid();
    // formules
    const formulas = d.formulas.length ? d.formulas.map(x => h('div', { style: 'display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--color-divider);font-size:14px' }, h('span', {}, x.name), h('span', { style: 'color:var(--color-neutral-700)' }, (x.percent !== '' ? x.percent + ' %' : '')))) : [h('p', { style: 'font-size:13.5px;color:var(--color-neutral-700)' }, 'Aucune formule enregistrée.')];
    const tv = d.toVerify.length ? h('div', { class: 'fh-warn fh-noprint', style: 'margin:0 0 24px;max-width:760px' }, h('p', { style: 'margin:0 0 8px;font-family:var(--font-heading);font-weight:600;font-size:17px' }, `${d.toVerify.length} point${d.toVerify.length > 1 ? 's' : ''} à vérifier`),
      ...d.toVerify.map(t => h('p', { style: 'margin:0 0 6px;font-size:13.5px' }, h('b', { style: 'font-weight:600' }, t.field + ' : '), t.reason, t.source_excerpt ? h('i', { style: 'color:var(--color-neutral-700)' }, ' « ' + t.source_excerpt + ' »') : null))) : null;
    const verifyBtn = f.Statut !== 'Verifie' ? h('button', { class: 'btn btn-secondary fh-noprint', onclick: async () => { const nd = await api('/api/mp/' + id + '/verify', { method: 'POST' }); nd.id = id; Object.assign(d, nd); drawGrid(); verifyBtn.remove(); } }, 'Marquer comme vérifié') : null;
    const docsBox = h('div', { class: 'fh-noprint' }, h('p', { class: 'fh-label', style: 'margin-top:18px' }, 'Documents sources'));
    docsBox.append(docsPanel(d, () => viewFiche(id)));
    document.title = (f['Trade name'] || 'Fiche') + ' - Formulation Hub';
    shell(view(back(),
      h('div', { style: 'display:flex;flex-wrap:wrap;gap:14px;align-items:baseline;justify-content:space-between;margin-bottom:22px' },
        h('div', {}, eyebrow('Fiche matière première'),
          h('h2', { style: 'margin:0;font-family:var(--font-heading);font-weight:600;font-style:italic;font-size:42px;line-height:1.05' }, f['Trade name'] || f.Ingredient || id),
          h('p', { style: 'margin:5px 0 0;font-size:13.5px;color:var(--color-neutral-700)' }, [f.INCI, f.Supplier].filter(Boolean).join(' · ')),
          h('p', { class: 'fh-noprint', style: 'margin:6px 0 0' }, miss)),
        h('div', { class: 'fh-noprint', style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap' }, statusTag, f.COSMOS ? h('span', { class: 'tag tag-accent' }, 'COSMOS') : null, cmpBtn, h('button', { class: 'btn btn-primary', onclick: () => window.print() }, 'Télécharger la fiche'))),
      msg, tv, grid,
      h('div', { class: 'fh-grid3', style: 'margin-top:34px;max-width:1000px' },
        h('div', {}, label('Formules (' + d.formulas.length + ')'), formulas, docsBox),
        h('div', { class: 'fh-noprint' }, label('Notes'), ta, noteState, imgs, imgIn,
          h('div', { class: 'fh-drop', style: 'margin-top:10px', onclick: () => imgIn.click() }, 'Ajouter une image'),
          h('p', { style: 'margin:10px 0 0;font-size:12.5px;color:var(--color-neutral-700);max-width:40ch' }, 'Ces notes et images seront intégrées à la fiche lors du téléchargement. Dans la fenêtre d\'impression, choisissez « Enregistrer au format PDF ».'),
          verifyBtn)),
      printBox));
  }

  // ---------- comparaison ----------
  function drawCmpMini(box) {
    box.replaceChildren(h('div', { style: 'display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin-bottom:10px' }, label('Comparaison'), h('p', { style: 'margin:0;font-size:11.5px;color:var(--color-neutral-600)' }, state.cmp.length + ' / 5')),
      state.cmp.length ? state.cmp.map(c => h('div', { style: 'display:flex;align-items:baseline;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--color-divider);font-size:14.5px' }, h('span', {}, c.name), h('button', { class: 'btn btn-ghost', style: 'font-size:13px', onclick: () => { state.cmp = state.cmp.filter(x => x.id !== c.id); saveCmp(); drawCmpMini(box); } }, 'Retirer'))) :
        h('p', { style: 'margin:0 0 10px;font-size:13.5px;color:var(--color-neutral-700)' }, 'Aucune matière première sélectionnée. Ajoutez-en jusqu\'à cinq pour les comparer.'),
      h('div', { style: 'margin-top:12px' }, h('button', { class: 'btn btn-secondary', onclick: () => { location.hash = '#/compare'; } }, 'Ouvrir la comparaison')));
  }
  const CRIT = [['INCI', f => f.INCI], ['Fournisseur', f => f.Supplier], ['Fonction', f => f.Fonction], ['Dosage (min / max)', f => isEmpty(f['Dosage min']) && isEmpty(f['Dosage max']) ? '' : [f['Dosage min'], f['Dosage max']].filter(x => !isEmpty(x)).join(' - ') + ' %'],
    ['Flash point', f => isEmpty(f['Flash point']) ? '' : f['Flash point'] + ' °C'], ['Solubility', f => f.Solubility], ['COSMOS', f => f.COSMOS], ['Vegan', f => yesno(f.Vegan)], ['Toucher', f => f.Sensory], ['Formules internes', (f, n) => String(n)]];
  async function viewCompare() {
    if (!state.names) state.names = (await api('/api/mp-names')).items;
    const data = state.cmp.length ? (await api('/api/compare', { json: { ids: state.cmp.map(c => c.id) } })).items : [];
    const msg = h('p', { class: 'fh-err', style: 'min-height:18px' });
    const dl = h('datalist', { id: 'fh-names' }, state.names.slice(0, 1200).map(n => h('option', { value: n.name })));
    const add = h('input', { class: 'input', type: 'text', list: 'fh-names', placeholder: 'Ajouter une MP - tapez pour filtrer', style: 'min-height:38px;background:var(--color-neutral-100);max-width:280px' });
    const tryAdd = () => {
      const v = add.value.trim().toLowerCase(); if (!v) return;
      const hit = state.names.find(n => n.name.toLowerCase() === v) || state.names.find(n => n.name.toLowerCase().startsWith(v));
      if (!hit) { msg.textContent = `Aucune matière première ne correspond à « ${add.value} ».`; return; }
      if (state.cmp.some(c => c.id === hit.id)) { msg.textContent = hit.name + ' est déjà dans la comparaison.'; return; }
      if (state.cmp.length >= 5) { msg.textContent = 'Maximum 5 matières premières. Retirez-en une avant d\'ajouter ' + hit.name + '.'; return; }
      state.cmp.push(hit); saveCmp(); viewCompare();
    };
    add.addEventListener('change', tryAdd); add.addEventListener('keydown', e => { if (e.key === 'Enter') tryAdd(); });
    const table = data.length ? h('div', { style: 'overflow-x:auto' }, h('table', { class: 'table', style: `min-width:${180 + data.length * 150}px` },
      h('thead', {}, h('tr', {}, h('th', {}, 'Critère'), data.map(c => h('th', {}, h('span', { style: 'display:flex;gap:10px;align-items:baseline;justify-content:space-between' }, h('a', { href: '#/fiche/' + c.id }, c.name), h('span', { style: 'cursor:pointer;color:var(--color-accent-700);font-size:13px;text-transform:none;letter-spacing:0', onclick: () => { state.cmp = state.cmp.filter(x => x.id !== c.id); saveCmp(); viewCompare(); } }, 'retirer'))))) ),
      h('tbody', {}, CRIT.map(([k, fn]) => h('tr', {}, h('td', { style: 'color:var(--color-neutral-700);white-space:nowrap' }, k), data.map(c => h('td', {}, String(fn(c.fields, c.formulas) || '-')))))))) :
      h('p', { style: 'font-size:14px;color:var(--color-neutral-700)' }, 'Aucune matière première dans la comparaison.');
    shell(view(back(), eyebrow('Comparaison'), title(data.length === 0 ? 'Comparaison vide' : data.length === 1 ? 'Une matière première sélectionnée' : data.length + ' matières premières côte à côte'),
      h('div', { style: 'display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:16px' }, add, dl, h('span', { style: 'font-size:12px;color:var(--color-neutral-600)' }, state.cmp.length + ' / 5')), msg, table,
      h('p', { style: 'margin:14px 0 0;font-size:12.5px;color:var(--color-neutral-700)' }, 'Un tiret signale un champ non renseigné dans la fiche source.')));
  }

  // ---------- veille ----------
  async function viewVeille() {
    const r = await api('/api/veille');
    const v = r.veille;
    const body = v ? h('div', { class: 'fh-veille' }, v.sections.map(s => h('div', { style: 'break-inside:avoid;margin-bottom:26px' },
      h('p', { class: 'fh-group-title', style: 'margin-bottom:10px' }, s.title),
      s.items.map(a => h('div', { style: 'padding:8px 0' },
        a.u ? h('a', { href: a.u, target: '_blank', rel: 'noopener noreferrer', style: 'font-family:var(--font-heading);font-weight:600;font-size:15.5px;line-height:1.25;color:var(--color-text);display:block' }, a.t) : h('span', { style: 'font-family:var(--font-heading);font-weight:600;font-size:15.5px;line-height:1.25;display:block' }, a.t),
        h('p', { style: 'margin:3px 0 0;font-size:11.5px;color:var(--color-neutral-600)' }, a.s)))))) :
      h('p', { style: 'font-size:14px;color:var(--color-neutral-700)' }, r.loading ? 'La veille de la semaine est en cours de préparation, revenez dans une ou deux minutes.' : 'Pas encore de veille pour cette semaine.');
    shell(view(back(), eyebrow('Veille de la semaine' + (v ? ' · ' + new Date(v.generated_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }) : '')), title('Ce qui a bougé depuis lundi dernier'), body,
      h('p', { style: 'margin:10px 0 0;font-size:12px;color:var(--color-neutral-600)' }, v && v.demo ? 'Contenu d\'exemple (mode démonstration).' : 'Les liens proviennent de la recherche web ; vérifiez les sources avant de vous y fier.'),
      h('button', { class: 'btn btn-secondary', style: 'margin-top:14px', onclick: async () => { await api('/api/veille/run', { method: 'POST' }); setTimeout(viewVeille, 2000); } }, 'Actualiser la veille maintenant')));
  }

  // ---------- routeur ----------
  async function route() {
    if (!state.me) return;
    const h0 = location.hash.replace(/^#/, '') || '/'; const parts = h0.split('/').filter(Boolean);
    document.title = 'Formulation Hub';
    try {
      if (!parts.length) return await viewHome();
      if (parts[0] === 'results') return await viewResults(decodeURIComponent(parts[1] || ''));
      if (parts[0] === 'extract' && /^MP-\d+$/.test(parts[1] || '')) return await viewExtract(parts[1]);
      if (parts[0] === 'fiche' && /^MP-\d+$/.test(parts[1] || '')) return await viewFiche(parts[1]);
      if (parts[0] === 'compare') return await viewCompare();
      if (parts[0] === 'veille') return await viewVeille();
      location.hash = '#/';
    } catch (e) { if (e.message !== 'Connexion requise') shell(view(back(), err(e.message))); }
  }
  async function boot() { try { state.me = await api('/api/me'); } catch { return; } route(); }
  window.addEventListener('hashchange', route);
  boot();
})();
