'use strict';
(() => {
  const root = document.getElementById('root');
  const state = { me: null, cmp: [] };
  try { state.cmp = JSON.parse(localStorage.getItem('fh_cmp') || '[]'); } catch { state.cmp = []; }
  const saveCmp = () => { try { localStorage.setItem('fh_cmp', JSON.stringify(state.cmp)); } catch { /* stockage indisponible */ } document.querySelectorAll('[data-cmp]').forEach(e => { e.textContent = 'Comparaison (' + state.cmp.length + ')'; }); };
  const MAX_CMP = 10; const MAX_DOCS = 10; const MAX_MB = 25;
  const NR = 'Non renseigné';

  // ---------- outils DOM (aucun innerHTML : tout passe par textContent) ----------
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (k === 'value') e.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected') e[k] = !!v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) { if (kid === null || kid === undefined || kid === false) continue; e.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return e;
  }
  const NS = 'http://www.w3.org/2000/svg';
  function icon(paths, size = 28, color = '#0b6b63') {
    const s = document.createElementNS(NS, 'svg');
    for (const [k, v] of Object.entries({ width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, 'stroke-width': 1.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) s.setAttribute(k, v);
    for (const d of paths) { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); s.append(p); }
    return s;
  }
  const IC = {
    logo: ['M9 3h6', 'M10 3v6l-5.2 9a2 2 0 0 0 1.7 3h11a2 2 0 0 0 1.7-3L14 9V3', 'M7.5 15h9'],
    search: ['M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z', 'm20 20-3.5-3.5'],
    plus: ['M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z', 'M12 8v8M8 12h8'],
    news: ['M4 5h13a2 2 0 0 1 2 2v12H6a2 2 0 0 1-2-2z', 'M8 9h7M8 13h7M8 17h4'],
    cmp: ['M4.5 4h4a1.5 1.5 0 0 1 1.5 1.5v13A1.5 1.5 0 0 1 8.5 20h-4A1.5 1.5 0 0 1 3 18.5v-13A1.5 1.5 0 0 1 4.5 4z', 'M15.5 4h4A1.5 1.5 0 0 1 21 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-4a1.5 1.5 0 0 1-1.5-1.5v-13A1.5 1.5 0 0 1 15.5 4z'],
    up: ['M12 16V4M7 9l5-5 5 5', 'M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3'],
    chev: ['m6 9 6 6 6-6']
  };
  { const orig = Element.prototype.replaceChildren; Element.prototype.replaceChildren = function (...k) { return orig.apply(this, k.flat(Infinity).filter(x => x !== null && x !== undefined && x !== false)); }; }
  const $ = (s, r = document) => r.querySelector(s);
  const cap = s => String(s || '').charAt(0).toUpperCase() + String(s || '').slice(1);
  const isEmpty = v => v === '' || v === null || v === undefined;

  async function api(path, opts = {}) {
    const o = Object.assign({ headers: {} }, opts);
    if (o.json !== undefined) { o.method = o.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(o.json); delete o.json; }
    const r = await fetch(path, o);
    let j = {}; try { j = await r.json(); } catch { /* corps vide */ }
    if (r.status === 401 && path !== '/api/login') { renderLogin(); throw new Error('Connexion requise'); }
    if (!r.ok) throw new Error(j.error || 'Erreur ' + r.status);
    return j;
  }
  function toast(t) { const e = h('div', { class: 'toast' }, t); document.body.append(e); setTimeout(() => e.remove(), 1800); }
  document.addEventListener('click', e => { document.querySelectorAll('details.dd[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); }); });
  window.addEventListener('beforeprint', () => document.querySelectorAll('details.group').forEach(d => { d.dataset.wasOpen = d.open ? '1' : ''; d.open = true; }));
  window.addEventListener('afterprint', () => document.querySelectorAll('details.group').forEach(d => { d.open = d.dataset.wasOpen === '1'; }));

  // ---------- coque de page ----------
  function shell(active, content, width = 'w-lg') {
    document.title = 'Formulation Hub';
    const link = (href, label, key) => h('a', { href, class: active === key ? 'on' : '' }, label);
    const spaceOn = ['fiches', 'notes', 'agenda'].includes(active);
    root.replaceChildren(h('div', { class: 'page' },
      h('header', { class: 'hdr noprint' },
        h('a', { href: '#/', class: 'brand' }, icon(IC.logo, 28), 'Formulation Hub'),
        h('nav', { class: 'nav' },
          h('details', { class: 'dd' }, h('summary', { class: spaceOn ? 'on' : '' }, 'Mon espace'),
            h('div', { class: 'menu' }, h('a', { href: '#/fiches' }, 'Fiches existantes'), h('a', { href: '#/notes' }, 'Bloc-notes'), h('a', { href: '#/agenda' }, 'Agenda et rappels'))),
          link('#/consulter', 'Consulter une fiche', 'consulter'), link('#/ajout', 'Ajouter une MP', 'ajout'), link('#/veille', 'Veille', 'veille'),
          h('a', { href: '#/comparaison', class: active === 'comparaison' ? 'on' : '', 'data-cmp': '1' }, 'Comparaison (' + state.cmp.length + ')')),
        h('details', { class: 'dd' }, h('summary', { class: 'profile' }, h('span', { class: 'avatar' }, state.me.name.charAt(0).toUpperCase()), state.me.name),
          h('div', { class: 'menu right' }, h('button', { onclick: async () => { await api('/api/logout', { method: 'POST' }); state.me = null; location.hash = '#/'; renderLogin(); } }, 'Déconnexion')))),
      h('main', { class: 'main ' + width }, content),
      h('footer', { class: 'footer noprint' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.' + (state.me.mock ? ' Mode démonstration.' : ''))));
    window.scrollTo(0, 0);
  }

  // ---------- connexion ----------
  function renderLogin() {
    let saved = ''; try { saved = localStorage.getItem('fh_name') || ''; } catch { /* stockage indisponible */ }
    const name = h('input', { class: 'input', id: 'prenom', type: 'text', placeholder: 'Votre prénom', autocomplete: 'given-name', value: saved });
    const pw = h('input', { class: 'input', id: 'mdp', type: 'password', autocomplete: 'current-password' });
    const msg = h('p', { class: 'err' });
    const keep = h('input', { type: 'checkbox', id: 'garder' });
    const go = async () => {
      msg.textContent = '';
      try { const r = await api('/api/login', { json: { name: name.value, password: pw.value, remember: keep.checked } }); try { localStorage.setItem('fh_name', r.name); } catch { /* ignore */ } pw.value = ''; location.hash = '#/'; await boot(); } catch (e) { msg.textContent = e.message; }
    };
    for (const i of [name, pw]) i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    root.replaceChildren(h('div', { class: 'page' }, h('div', { class: 'login-wrap' }, h('section', { class: 'card login' },
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('div', { style: 'display:flex;align-items:center;gap:12px' }, icon(IC.logo, 32), h('h1', { style: 'font-size:28px;font-weight:700;letter-spacing:-.02em' }, 'Formulation Hub')),
        h('p', { class: 'muted', style: 'font-size:15px' }, 'Base de connaissances matières premières. Connectez-vous pour continuer.')),
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('label', { for: 'prenom', style: 'font-size:14px;font-weight:600' }, 'Prénom'), name),
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('label', { for: 'mdp', style: 'font-size:14px;font-weight:600' }, 'Mot de passe'), pw),
      h('label', { for: 'garder', style: 'display:flex;gap:10px;align-items:center;font-size:15px;cursor:pointer' }, keep, 'Rester connectée sur cet appareil'),
      msg, h('button', { class: 'btn primary', style: 'padding:14px 20px;font-size:16px;text-align:center', onclick: go }, 'Se connecter'),
      h('p', { class: 'muted', style: 'font-size:13px' }, 'Le prénom sert uniquement à vous saluer. Il est gardé dans votre navigateur.'))),
      h('footer', { class: 'footer' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.')));
    (saved ? pw : name).focus();
  }

  // ---------- accueil ----------
  const ago = iso => {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 2) return 'à l\'instant'; if (m < 60) return 'il y a ' + m + ' min'; const hr = Math.round(m / 60);
    if (hr < 24) return 'il y a ' + hr + ' h'; const d = Math.round(hr / 24); return d === 1 ? 'hier' : 'il y a ' + d + ' j';
  };
  const itemRow = (href, left, right) => h('a', { href, style: 'display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-top:1px solid var(--line);text-decoration:none;color:var(--text);font-size:16px;font-weight:500' }, h('span', {}, left), h('span', { style: 'color:var(--muted);font-weight:400;font-size:14px' }, right));
  async function viewHome() {
    const home = await api('/api/home');
    const tile = (href, ic, title, text) => h('a', { class: 'tile', href }, icon(ic, 32), h('b', {}, title), h('span', {}, text), h('em', {}, 'Ouvrir'));
    const agenda = h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Aujourd\'hui dans l\'agenda'),
      home.agenda.length ? home.agenda.map(e => itemRow('#/agenda/' + e.id, e.title, e.time || 'Journée')) : h('p', { class: 'muted' }, 'Aucun rappel aujourd\'hui. ', h('a', { href: '#/agenda' }, 'Ouvrir l\'agenda')));
    shell('home', [
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('p', { class: 'eyebrow' }, 'Base de connaissances matières premières'),
        h('h1', { style: 'font-size:44px;line-height:1.1;font-weight:700;letter-spacing:-.02em' }, 'Bonjour ' + state.me.name),
        h('p', { style: 'font-size:20px;line-height:1.5;max-width:640px' }, 'Que souhaitez-vous faire ?'),
        h('p', { class: 'sub', style: 'max-width:640px' }, 'Retrouvez les informations d\'une matière première à partir de ses documents, ajoutez-en une nouvelle, comparez des fiches ou consultez la veille de la semaine.')),
      agenda,
      h('div', { class: 'cards4' },
        tile('#/consulter', IC.search, 'Consulter une fiche', 'Cherchez une matière première, déposez ses documents PDF et obtenez sa fiche complète.'),
        tile('#/ajout', IC.plus, 'Ajouter une matière première', 'Créez une nouvelle entrée dans la base. Un identifiant MP-xxxx lui est attribué automatiquement.'),
        tile('#/veille', IC.news, 'Veille de la semaine', 'Les liens des articles et des salons cosmétiques de la semaine, à consulter.'),
        tile('#/comparaison', IC.cmp, 'Comparaison', 'Placez jusqu\'à ' + MAX_CMP + ' fiches côte à côte pour les comparer critère par critère.')),
      h('div', { class: 'row2' },
        h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Dernières fiches consultées'),
          home.recents.length ? home.recents.map(r => itemRow('#/fiche/' + r.id, r.name, ago(r.at))) : h('p', { class: 'muted' }, 'Aucune fiche consultée pour le moment.')),
        h('section', { class: 'card tight', style: 'gap:12px' }, h('h2', { class: 'card-title', style: 'margin:0' }, 'Comparaison en cours'),
          h('p', {}, state.cmp.length ? `${state.cmp.length} fiche${state.cmp.length > 1 ? 's' : ''} sélectionnée${state.cmp.length > 1 ? 's' : ''} sur ${MAX_CMP}.` : 'Aucune fiche sélectionnée.'),
          h('a', { class: 'btn primary', style: 'align-self:flex-start', href: '#/comparaison' }, 'Voir la comparaison'))),
      h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Fiches existantes'),
        home.fiches.length ? home.fiches.map(r => itemRow('#/fiche/' + r.id, r.name, 'Ouvrir')) : h('p', { class: 'muted' }, 'Aucune fiche pour le moment. Elles apparaissent ici automatiquement après la lecture d\'un document.'))
    ]);
  }

  // ---------- consulter une fiche ----------
  async function viewConsulter(preId) {
    let selected = null; let q = ''; let items = []; const ready = []; // { id, name, size, state }
    const msg = h('p', { class: 'err' });
    const search = h('input', { class: 'input', id: 'q', type: 'search', placeholder: 'Nom commercial', autocomplete: 'off' });
    const listBox = h('div'); const selBox = h('div');
    const docList = h('div'); const status = h('div');
    const go = h('button', { class: 'btn primary', style: 'padding:14px 24px;font-size:16px', disabled: true, onclick: run }, 'Extraire et afficher la fiche');
    let tmr;
    async function load() {
      q = search.value.trim();
      try { items = (await api('/api/mps?q=' + encodeURIComponent(q))).items; } catch (e) { msg.textContent = e.message; return; }
      drawList();
    }
    function drawList() {
      listBox.replaceChildren(items.length ? h('div', { class: 'list', style: 'max-height:300px;overflow-y:auto' }, items.slice(0, 50).map(m => { const on = selected && selected.id === m.id;
        return h('div', { class: 'pick' + (on ? ' sel' : ''), style: on ? 'border-left:4px solid var(--accent);padding-left:12px' : null, onclick: () => choose(m) },
          h('span', { style: 'font-size:16px;display:flex;align-items:center;gap:8px;font-weight:' + (on ? 700 : 400) }, on ? h('span', { style: 'display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:var(--accent);color:#fff;font-size:14px;line-height:1' }, '✓') : null, m.name), m.fiche ? h('span', { style: 'font-size:12px;font-weight:600;color:var(--accent);background:var(--accent-soft);border-radius:10px;padding:2px 8px;white-space:nowrap' }, 'Fiche existante') : null, h('span', { style: 'font-size:13px;color:var(--muted);white-space:nowrap' }, m.id)); })) :
        h('p', { class: 'muted' }, q ? 'Aucune matière première ne correspond. ' : '', h('a', { href: '#/ajout' }, 'Ajouter une MP')));
    }
    function choose(m) {
      selected = m; drawList(); drawSel(); syncGo();
    }
    function drawSel() {
      selBox.replaceChildren(selected ? h('div', { style: 'margin-top:14px;padding:14px 16px;border-radius:10px;background:var(--accent-soft);border:1px solid var(--accent);display:flex;align-items:center;gap:12px;flex-wrap:wrap' },
        h('span', { style: 'display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;background:var(--accent);color:#fff;font-size:16px' }, '✓'),
        h('span', { style: 'flex:1;min-width:200px' }, h('span', { class: 'muted', style: 'display:block;font-size:13px' }, 'Matière première sélectionnée'), h('b', { style: 'font-size:17px' }, selected.name), ' ', h('span', { class: 'muted' }, '(' + selected.id + ')')),
        h('a', { class: 'btn' + (selected.fiche ? ' primary' : ''), href: '#/fiche/' + selected.id }, selected.fiche ? 'Voir la fiche existante' : 'Voir la fiche (vide pour l\'instant)')) : null);
    }
    function syncGo() { go.disabled = !(selected && ready.some(f => f.state === 'ok')); }
    search.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(load, 250); });
    // documents
    const file = h('input', { type: 'file', accept: 'application/pdf', multiple: true, style: 'display:none', onchange: e => { upload([...e.target.files]); e.target.value = ''; } });
    const drop = h('div', { class: 'drop', onclick: () => file.click() }, icon(IC.up, 32, '#5b6b77'), h('b', {}, 'Glissez les PDF ici, ou cliquez pour les choisir'), h('span', {}, `Fiche technique, fiche de sécurité, brochure. Jusqu'à ${MAX_DOCS} documents, ${MAX_MB} Mo chacun.`));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); upload([...e.dataTransfer.files]); });
    function drawDocs() {
      docList.replaceChildren(ready.length ? h('div', { class: 'list' }, ready.map(f => h('div', {}, h('span', { style: 'font-size:15px;min-width:0;overflow-wrap:anywhere' }, f.name),
        h('span', { style: 'display:flex;gap:10px;align-items:center' }, h('span', { class: 'badge' + (f.state === 'err' ? ' warn' : '') }, f.state === 'ok' ? 'Prêt' : f.state === 'err' ? f.error : 'Envoi...'),
          h('button', { class: 'link', onclick: () => { ready.splice(ready.indexOf(f), 1); drawDocs(); syncGo(); } }, 'Retirer'))))) : null);
    }
    async function upload(fl) {
      msg.textContent = '';
      const batch = [];
      for (const f of fl) {
        if (ready.length >= MAX_DOCS) { msg.textContent = `${MAX_DOCS} documents maximum.`; break; }
        if (!/\.pdf$/i.test(f.name)) { msg.textContent = 'Seuls les fichiers PDF sont acceptés.'; continue; }
        if (f.size > MAX_MB * 1024 * 1024) { msg.textContent = `${f.name} dépasse ${MAX_MB} Mo.`; continue; }
        const it = { name: f.name, state: 'up' }; ready.push(it); batch.push([it, f]);
      }
      drawDocs(); // tous les documents apparaissent d'un coup, puis chacun passe a "Prêt" des qu'il est envoyé
      await Promise.all(batch.map(async ([it, f]) => {
        try { const r = await api('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f, headers: { 'Content-Type': 'application/pdf' } }); it.id = r.id; it.state = 'ok'; } catch (e) { it.state = 'err'; it.error = e.message; }
        drawDocs(); syncGo();
      }));
    }
    async function run() {
      msg.textContent = ''; go.disabled = true;
      const fill = h('div', { style: 'width:0%' }); const stepEl = h('p', { class: 'muted' });
      status.replaceChildren(h('p', { style: 'font-size:18px;font-weight:600;margin-bottom:10px' }, 'Analyse en cours...'), h('div', { class: 'bar' }, fill), stepEl,
        h('p', { class: 'muted', style: 'font-size:13px;margin-top:8px' }, 'Comptez environ une minute par document. Vous pouvez laisser cette page ouverte.'));
      const anim = { base: 0, max: 6, t0: Date.now(), shown: 0, last: -1 };
      const tick = setInterval(() => { const p = anim.base + (anim.max - anim.base) * (1 - Math.exp(-(Date.now() - anim.t0) / 25000)); anim.shown = Math.max(anim.shown, p); fill.style.width = anim.shown.toFixed(1) + '%'; }, 250);
      try {
        const { job } = await api('/api/extract', { json: { mp_id: selected.id, files: ready.filter(f => f.state === 'ok').map(f => ({ id: f.id })) } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500));
          const j = await api('/api/jobs/' + job);
          if (j.pct !== anim.last) { anim.last = j.pct; anim.base = Math.max(anim.shown, j.pct); anim.max = Math.max(j.pctMax || j.pct, anim.base); anim.t0 = Date.now(); }
          stepEl.textContent = j.step;
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') {
            const r = j.result; fill.style.width = '100%';
            if (!r.failed.length && !r.skipped.length) { location.hash = '#/fiche/' + selected.id; return; }
            status.replaceChildren(h('p', { style: 'font-size:18px;font-weight:600' }, `${r.docsRead} document${r.docsRead > 1 ? 's' : ''} analysé${r.docsRead > 1 ? 's' : ''}`),
              r.skipped.map(s => h('p', { class: 'muted' }, `${s.name} : ${s.reason}.`)), r.failed.map(f => h('p', { class: 'err' }, `${f.name} : ${f.error}`)),
              h('a', { class: 'btn primary', style: 'align-self:flex-start', href: '#/fiche/' + selected.id }, 'Voir la fiche'));
            ready.length = 0; drawDocs(); return;
          }
        }
      } catch (e) { status.replaceChildren(h('p', { class: 'err' }, e.message)); syncGo(); } finally { clearInterval(tick); }
    }
    shell('consulter', [
      h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, h('h1', { class: 'h1' }, 'Consulter une fiche'), h('p', { class: 'sub' }, 'Deux étapes : choisissez la matière première, puis déposez ses documents.')),
      h('section', { class: 'card' }, h('div', { class: 'step-h' }, h('span', { class: 'step' }, '1'), h('h2', {}, 'Matière première')), h('label', { for: 'q', class: 'lbl' }, 'Nom commercial'), search, listBox, selBox),
      h('section', { class: 'card' }, h('div', { class: 'step-h' }, h('span', { class: 'step' }, '2'), h('h2', {}, 'Documents')), drop, file, docList, msg,
        h('div', { style: 'display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px' },
          h('p', { class: 'muted', style: 'max-width:520px' }, 'Les documents sont analysés puis supprimés. Ils ne sont pas conservés, seules les informations extraites sont enregistrées.'), go), status)
    ], 'w-md');
    if (preId) { try { const d = await api('/api/mps?q='); void d; const all = (await api('/api/mp-names')).items; const m = all.find(x => x.id === preId); if (m) { search.value = m.name; await load(); const hit = items.find(x => x.id === preId); if (hit) choose(hit); } } catch { /* ignore */ } } else load();
    search.focus();
  }

  // ---------- ajouter une MP ----------
  async function viewAjout() {
    const names = (await api('/api/mp-names')).items;
    const next = 'MP-' + String(Math.max(0, ...names.map(n => parseInt(n.id.slice(3), 10) || 0)) + 1).padStart(4, '0');
    const input = h('input', { class: 'input', id: 'trade', type: 'text', placeholder: 'Ex : CAMELLIA OIL' });
    const msg = h('p', { class: 'err' }); const done = h('div');
    const add = async () => {
      msg.textContent = '';
      try { const r = await api('/api/mps', { json: { name: input.value } }); done.replaceChildren(h('section', { class: 'card', style: 'background:var(--accent-soft);border-color:#b9dcd7;gap:10px' },
        h('p', { class: 'ok', style: 'font-size:15px' }, `Matière première ajoutée : ${r.name} (${r.id})`), h('a', { class: 'btn primary small', style: 'align-self:flex-start', href: '#/consulter/' + r.id }, 'Déposer ses documents'))); input.value = ''; } catch (e) { msg.textContent = e.message; }
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
    shell('ajout', [
      h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, h('h1', { class: 'h1' }, 'Ajouter une matière première'), h('p', { class: 'sub' }, 'Indiquez son nom commercial. La matière première est ajoutée à la base avec un identifiant unique, puis vous pouvez déposer ses documents.')),
      h('section', { class: 'card' }, h('label', { for: 'trade', style: 'font-size:14px;font-weight:600' }, 'Nom commercial'), input,
        h('p', { class: 'muted' }, 'Identifiant attribué : ', h('b', { style: 'color:var(--text)' }, next), ' (le numéro suivant dans la base).'), msg,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:12px;align-items:center' }, h('button', { class: 'btn primary', style: 'padding:14px 24px;font-size:16px', onclick: add }, 'Ajouter à la base'), h('a', { href: '#/', style: 'font-size:15px;font-weight:500;text-decoration:none' }, 'Annuler'))),
      done
    ], 'w-sm');
    input.focus();
  }

  // ---------- fiche ----------
  const joinRange = (lo, hi) => (isEmpty(lo) && isEmpty(hi)) ? '' : isEmpty(hi) ? String(lo) : isEmpty(lo) ? String(hi) : lo + ' - ' + hi;
  async function viewFiche(id) {
    const d = await api('/api/mp/' + id);
    api('/api/mp/' + id + '/open', { method: 'POST' }).catch(() => { });
    const ui = state.me.ui; const f = () => d.fields;
    const msg = h('p', { class: 'err noprint' });
    const top = h('div', { class: 'actions noprint' }); const bottom = h('div', { class: 'actions bottom noprint' });
    const verifyBox = h('div'); const head = h('div'); const groupsBox = h('div', { class: 'groups' }); const docsLu = h('div');
    const isCmp = () => state.cmp.some(c => c.id === id);
    // enregistrements en file d'attente : l'ecran se met a jour tout de suite, le serveur suit en arriere-plan
    let chain = Promise.resolve();
    function save(changes) {
      msg.textContent = '';
      const before = {}; for (const k of Object.keys(changes)) before[k] = d.fields[k];
      Object.assign(d.fields, changes); drawAll();
      chain = chain.then(async () => {
        try {
          const nd = await api('/api/mp/' + id, { method: 'PUT', json: { changes } });
          const changed = JSON.stringify([nd.sources, nd.toVerify]) !== JSON.stringify([d.sources, d.toVerify]);
          d.sources = nd.sources; d.toVerify = nd.toVerify; d.fields.Statut = nd.fields.Statut;
          if (changed) drawAll(); toast('Enregistré');
        } catch (e) { Object.assign(d.fields, before); msg.textContent = 'Non enregistré : ' + e.message; drawAll(); }
      });
      return chain;
    }
    function toggleFav() {
      d.fav = !d.fav; drawAll(); toast(d.fav ? 'Ajouté aux favoris' : 'Retiré des favoris');
      const want = d.fav;
      chain = chain.then(async () => { try { await api('/api/favs/' + id, { method: want ? 'PUT' : 'DELETE' }); } catch (e) { d.fav = !want; msg.textContent = 'Non enregistré : ' + e.message; drawAll(); } });
    }
    function unverify() { save({ Statut: 'A verifier' }); }
    function markVerified() {
      const oldTv = d.toVerify; const oldSt = d.fields.Statut; d.fields.Statut = 'Verifie'; d.toVerify = []; drawAll(); toast('Marqué comme vérifié');
      chain = chain.then(async () => { try { await api('/api/mp/' + id + '/verify', { method: 'POST' }); } catch (e) { d.toVerify = oldTv; d.fields.Statut = oldSt; msg.textContent = 'Non enregistré : ' + e.message; drawAll(); } });
    }
    const srcOf = row => { for (const l of row.src) if (d.sources[l]) return d.sources[l]; return ''; };
    function valueOf(row) { return row.kind === 'range' ? joinRange(f()[row.header], f()[row.header2]) : f()[row.header]; }
    function control(row) {
      const val = f()[row.header];
      if (row.kind === 'yn' || row.kind === 'charge') {
        const opts = row.kind === 'yn' ? ['Oui', 'Non'] : state.me.ui.charges;
        return [opts.concat([NR]).map(o => h('button', { type: 'button', class: 'chip' + ((o === NR ? isEmpty(val) : val === o) ? ' on' : ''), onclick: () => save({ [row.header]: o === NR ? '' : o }) }, o))];
      }
      if (row.kind === 'cat') {
        const det = h('details', { class: 'dd', style: 'position:relative' }, h('summary', { class: 'sel-btn', style: isEmpty(val) ? 'color:var(--muted);font-style:italic' : '' }, isEmpty(val) ? NR : val, icon(IC.chev, 14, '#5b6b77')),
          h('div', { class: 'pop' }, [NR].concat(ui.cats).map(o => h('div', { class: (o === NR ? isEmpty(val) : val === o) ? 'on' : '', onclick: () => { det.removeAttribute('open'); save({ [row.header]: o === NR ? '' : o }); } }, o))));
        return [det];
      }
      if (row.kind === 'multi') {
        const cur = isEmpty(val) ? [] : String(val).split(/\s*,\s*/);
        const det = h('details', { class: 'dd', style: 'position:relative' }, h('summary', { class: 'pill add' }, '+ Ajouter'),
          h('div', { class: 'pop' }, ui.foncs.filter(x => !cur.includes(x)).map(o => h('div', { onclick: () => { det.removeAttribute('open'); save({ [row.header]: cur.concat([o]).join(', ') }); } }, o))));
        return [cur.length ? null : h('span', { class: 'empty', style: 'font-size:14px' }, NR), cur.map(x => h('button', { type: 'button', class: 'pill', title: 'Cliquer pour retirer', onclick: () => save({ [row.header]: cur.filter(y => y !== x).join(', ') }) }, x + ' x')), det];
      }
      // texte, nombre, plage : champ modifiable directement
      const v = row.kind === 'range' ? joinRange(f()[row.header], f()[row.header2]) : (isEmpty(val) ? '' : String(val));
      const ta = h('textarea', { class: 'edit', rows: 1, placeholder: NR, 'aria-label': row.label }); ta.value = v;
      const fit = () => { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 'px'; };
      let done = false;
      ta.addEventListener('input', fit);
      ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ta.blur(); } if (e.key === 'Escape') { done = true; ta.value = v; ta.blur(); } });
      ta.addEventListener('blur', () => {
        if (done) { done = false; return; } const nv = ta.value.trim(); if (nv === v) return;
        if (row.kind === 'range') { const p = nv.split(/\s*[-;\/]\s*/); save({ [row.header]: (p[0] || '').trim(), [row.header2]: p[1] !== undefined ? p[1].trim() : '' }); } else save({ [row.header]: nv });
      });
      setTimeout(fit, 0);
      return [ta, row.unit && v ? h('span', { class: 'muted', style: 'white-space:nowrap' }, row.unit) : null];
    }
    function drawGroups() {
      const open = {}; groupsBox.querySelectorAll('details.group').forEach(g => { open[g.dataset.t] = g.open; });
      groupsBox.replaceChildren(...ui.groups.map((g, gi) => {
        const filled = g.rows.filter(r => !isEmpty(valueOf(r))).length;
        const det = h('details', { class: 'group', 'data-t': g.title }, h('summary', {}, h('h2', {}, g.title), h('span', { class: 'cnt' }, `${filled} sur ${g.rows.length} renseignés`, icon(IC.chev, 16, '#5b6b77'))),
          g.rows.map(row => {
            const filledRow = !isEmpty(valueOf(row)); const s = srcOf(row);
            return h('div', { class: 'frow' }, h('span', { class: 'fl' }, row.label, filledRow && s ? h('span', { class: 'src', tabindex: '0' }, '?', h('span', { class: 'tip' }, s)) : null), h('div', { class: 'fv' }, ...control(row)));
          }));
        det.querySelector('summary').lastChild.lastChild.setAttribute('class', 'chev');
        det.open = open[g.title] !== undefined ? open[g.title] : gi === 0;
        return det;
      }));
    }
    function actions() {
      const verified = d.fields.Statut === 'Verifie';
      return [
        h('button', { class: 'btn', onclick: () => { if (isCmp()) { state.cmp = state.cmp.filter(c => c.id !== id); saveCmp(); drawAll(); toast('Retiré de la comparaison'); return; } if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches dans la comparaison.`; return; } state.cmp.push({ id, name: f()['Trade name'] }); saveCmp(); drawAll(); toast('Ajouté à la comparaison'); } }, isCmp() ? 'Retirer de la comparaison' : 'Ajouter à la comparaison'),
        h('button', { class: 'btn', onclick: verified ? unverify : markVerified }, verified ? 'Retirer le statut vérifié' : 'Marquer comme vérifié'),
        h('button', { class: 'btn primary', onclick: () => window.print() }, 'Télécharger la fiche (PDF)')
      ];
    }
    function drawAll() {
      const verified = d.fields.Statut === 'Verifie';
      head.replaceChildren(h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, h('span', { style: 'font-size:13px;color:var(--muted);font-weight:500' }, id), h('span', { class: 'badge' + (verified ? '' : ' warn') }, verified ? 'Vérifié' : 'À vérifier')),
        h('h1', { style: 'font-size:40px;line-height:1.1;font-weight:700;letter-spacing:-.02em' }, f()['Trade name'] || id),
        h('p', { class: 'sub' }, [f().INCI, f().Supplier].filter(Boolean).join(' - ')));
      top.replaceChildren(...actions()); bottom.replaceChildren(...actions());
      verifyBox.replaceChildren(d.toVerify.length ? h('section', { class: 'warnbox noprint' }, h('h2', {}, `${d.toVerify.length} point${d.toVerify.length > 1 ? 's' : ''} à vérifier`),
        d.toVerify.map(t => h('p', {}, h('b', {}, t.field + ' : '), t.reason, t.source_excerpt ? h('i', { style: 'color:var(--muted)' }, ' « ' + t.source_excerpt + ' »') : null))) : null);
      const names = [...new Set(Object.values(d.sources).flatMap(s => String(s).split(' ; ')).filter(s => s && !s.startsWith('Saisie manuelle')))];
      docsLu.replaceChildren(h('h2', { class: 'eyebrow' }, 'Documents lus'), names.length ? names.map(n => h('p', { style: 'font-size:15px;overflow-wrap:anywhere' }, n)) : h('p', { class: 'muted' }, 'Aucun document analysé pour le moment.'), h('p', { class: 'muted', style: 'font-size:13px' }, 'Ces documents ne sont pas conservés.'));
      drawGroups();
    }
    // notes de la fiche
    const notes = d.notes;
    const ta = h('textarea', { class: 'input sm', id: 'note', rows: 6, style: 'resize:vertical', placeholder: 'Ajouter une note, une remarque, un contexte' }); ta.value = notes.text || '';
    let tmr; const noteState = h('p', { class: 'muted', style: 'font-size:12px;min-height:16px' });
    ta.addEventListener('input', () => { clearTimeout(tmr); noteState.textContent = ''; tmr = setTimeout(async () => { try { await api('/api/notes/' + id, { method: 'PUT', json: { text: ta.value } }); noteState.textContent = 'Enregistré'; } catch (e) { noteState.textContent = e.message; } }, 800); });
    const imgs = h('div');
    const drawImgs = () => imgs.replaceChildren(...notes.images.map(n => h('div', {}, h('img', { class: 'notes-img', src: '/api/note-img/' + n, alt: 'Image de la note' }),
      h('button', { class: 'link noprint', onclick: async () => { const r = await api('/api/notes/' + id + '/image/' + n, { method: 'DELETE' }); notes.images = r.images; drawImgs(); } }, 'Retirer l\'image'))));
    const imgIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', multiple: true, style: 'display:none', onchange: async e => {
      const files = [...e.target.files]; e.target.value = ''; let n = 0;
      for (const fl of files) {
        noteState.textContent = `Envoi de l'image ${n + 1} sur ${files.length}...`;
        try { const r = await api('/api/notes/' + id + '/image', { method: 'POST', body: fl, headers: { 'Content-Type': fl.type } }); notes.images = r.images; drawImgs(); n++; } catch (er) { noteState.textContent = fl.name + ' : ' + er.message; return; }
      }
      noteState.textContent = n > 1 ? n + ' images ajoutées' : 'Image ajoutée';
    } });
    drawImgs(); drawAll();
    document.title = (f()['Trade name'] || 'Fiche') + ' - Formulation Hub';
    shell('fiche', [
      h('a', { href: '#/consulter', class: 'noprint', style: 'font-size:14px;text-decoration:none;font-weight:500' }, 'Retour à la recherche'),
      h('div', { style: 'display:flex;flex-direction:column;gap:20px' }, h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, head), top),
      msg, verifyBox,
      h('p', { class: 'muted noprint' }, 'Cliquez sur une valeur pour la modifier. Les modifications sont enregistrées automatiquement et ne sont jamais écrasées par une nouvelle analyse.'),
      groupsBox,
      h('div', { class: 'row2' }, h('section', { class: 'card', style: 'padding:20px 24px;gap:12px' }, docsLu),
        h('section', { class: 'card noprint', style: 'padding:20px 24px;gap:12px' }, h('h2', { class: 'eyebrow' }, 'Notes'), h('label', { for: 'note', class: 'lbl' }, 'Ajouter une note, une remarque, un contexte'), ta, noteState, imgs, imgIn,
          h('button', { class: 'btn small', style: 'align-self:flex-start', onclick: () => imgIn.click() }, 'Ajouter des images'))),
      h('div', { class: 'only-print' }, notes.text ? h('p', { style: 'white-space:pre-wrap' }, notes.text) : null),
      bottom
    ]);
  }

  // ---------- comparaison ----------
  async function viewComparaison() {
    const names = (await api('/api/mp-names')).items;
    const data = state.cmp.length ? (await api('/api/compare', { json: { ids: state.cmp.map(c => c.id) } })).items : [];
    const ui = state.me.ui; const msg = h('p', { class: 'err' });
    const norm = t => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const add = h('input', { class: 'input sm', type: 'text', placeholder: 'Ajouter une fiche...', autocomplete: 'off', 'aria-label': 'Ajouter une fiche' });
    const results = h('div', { class: 'results', hidden: true }); let hi = -1; let shown = [];
    const pick = n => {
      if (state.cmp.some(c => c.id === n.id)) { msg.textContent = n.name + ' est déjà dans la comparaison.'; return; }
      if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches.`; return; }
      state.cmp.push({ id: n.id, name: n.name }); saveCmp(); viewComparaison();
    };
    const drawResults = () => {
      const q = norm(add.value.trim()); msg.textContent = '';
      if (!q) { results.hidden = true; return; }
      shown = names.filter(n => !state.cmp.some(c => c.id === n.id) && (norm(n.name).includes(q) || n.id.toLowerCase().includes(q))).slice(0, 8); hi = shown.length ? 0 : -1;
      results.replaceChildren(...(shown.length ? shown.map((n, i) => h('div', { class: 'res' + (i === hi ? ' on' : ''), onmousedown: e => { e.preventDefault(); pick(n); } }, h('span', {}, n.name), h('small', {}, n.id))) : [h('div', { class: 'res none' }, 'Aucune matière première trouvée')]));
      results.hidden = false;
    };
    add.addEventListener('input', drawResults);
    add.addEventListener('blur', () => { results.hidden = true; });
    add.addEventListener('focus', drawResults);
    add.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!shown.length) return; hi = (hi + (e.key === 'ArrowDown' ? 1 : -1) + shown.length) % shown.length; [...results.children].forEach((c, i) => c.classList.toggle('on', i === hi)); }
      else if (e.key === 'Enter') { e.preventDefault(); if (shown[hi]) pick(shown[hi]); }
      else if (e.key === 'Escape') { results.hidden = true; }
    });
    const combo = h('div', { class: 'combo' }, add, results);
    const cell = (v, kind) => { const e = isEmpty(v); return h('td', { class: e ? 'empty' : '', style: !e && v === 'Oui' ? 'color:var(--accent);font-weight:600' : '' }, e ? NR : kind === 'unit' ? v : String(v)); };
    const rows = [];
    for (const g of ui.groups) {
      rows.push(h('tr', { class: 'head' }, h('td', {}, g.title), data.map(() => h('td'))));
      for (const r of g.rows) rows.push(h('tr', {}, h('td', {}, r.label), data.map(c => cell(r.kind === 'range' ? (joinRange(c.fields[r.header], c.fields[r.header2]) ? joinRange(c.fields[r.header], c.fields[r.header2]) + (r.unit ? ' ' + r.unit : '') : '') : c.fields[r.header], 'unit'))));
    }
    shell('comparaison', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Comparaison'), h('p', { class: 'sub' }, `${state.cmp.length} fiche${state.cmp.length > 1 ? 's' : ''} sélectionnée${state.cmp.length > 1 ? 's' : ''} sur ${MAX_CMP} au maximum.`)),
        h('div', { class: 'actions noprint', style: 'flex-wrap:wrap;align-items:center' }, combo, h('button', { class: 'btn primary', onclick: () => window.print() }, 'Télécharger la comparaison (PDF)'))),
      msg,
      data.length ? h('div', { class: 'cmp' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', {}, 'Critère'), data.map(c => h('th', {}, h('a', { href: '#/fiche/' + c.id, style: 'font-size:17px;font-weight:700;color:var(--text);text-decoration:none;display:block' }, c.name), h('span', { style: 'font-size:13px;color:var(--muted);font-weight:400;display:block' }, c.id),
        h('button', { class: 'link noprint', onclick: () => { state.cmp = state.cmp.filter(x => x.id !== c.id); saveCmp(); viewComparaison(); } }, 'Retirer'))))), h('tbody', {}, rows))) :
        h('section', { class: 'card' }, h('p', { class: 'muted' }, 'Aucune fiche dans la comparaison. Utilisez le champ ci-dessus ou le bouton « Ajouter à la comparaison » d\'une fiche.')),
      data.length ? h('div', { class: 'actions bottom noprint' }, h('button', { class: 'btn primary', onclick: () => window.print() }, 'Télécharger la comparaison (PDF)')) : null,
      h('p', { class: 'muted noprint', style: 'font-size:13px;max-width:720px' }, 'Sur ordinateur, jusqu\'à ' + MAX_CMP + ' colonnes avec défilement horizontal ; la colonne des critères reste visible.')
    ], 'w-xl');
  }

  // ---------- fiches existantes ----------
  const fold = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  async function viewFiches() {
    let items = (await api('/api/fiches')).items; let confirmId = null;
    const search = h('input', { class: 'input', type: 'search', placeholder: 'Rechercher une fiche (nom, INCI, fournisseur, identifiant)', autocomplete: 'off' });
    const box = h('div'); const msg = h('p', { class: 'err', role: 'alert' });
    async function del(m) { try { await api('/api/mp/' + m.id + '/fiche', { method: 'DELETE' }); } catch (e) { msg.textContent = e.message; return; } items = items.filter(x => x.id !== m.id); confirmId = null; draw(); }
    function draw() {
      const q = fold(search.value.trim());
      const shown = q ? items.filter(m => [m.name, m.inci, m.supplier, m.id, m.cat].some(v => fold(v).includes(q))) : items;
      box.replaceChildren(h('section', { class: 'card', style: 'padding:8px 24px 12px;gap:0' }, shown.length ? shown.map(m => h('div', { style: 'display:flex;flex-wrap:wrap;gap:4px 16px;align-items:center;padding:14px 0;border-top:1px solid var(--line-soft)' },
          h('a', { href: '#/fiche/' + m.id, style: 'flex:2 1 320px;font-size:16px;font-weight:600;text-decoration:none;color:var(--text)' }, m.name), h('span', { class: 'muted', style: 'flex:1 1 120px' }, m.id), h('span', { class: 'muted', style: 'flex:1 1 200px' }, m.cat || NR),
          confirmId === m.id ? h('span', {}, h('button', { class: 'btn small', onclick: () => del(m) }, 'Confirmer la suppression'), ' ', h('button', { class: 'btn small', onclick: () => { confirmId = null; draw(); } }, 'Annuler')) : h('button', { class: 'btn small', onclick: () => { confirmId = m.id; draw(); } }, 'Supprimer'))) :
          h('p', { class: 'muted', style: 'padding:16px 0' }, items.length ? 'Aucune fiche ne correspond.' : 'Aucune fiche pour le moment. Déposez un document sur une matière première : sa fiche apparaîtra ici.')));
    }
    search.addEventListener('input', draw);
    shell('fiches', [
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Fiches existantes'), h('p', { class: 'sub' }, 'Les matières premières dont la fiche a été remplie. Chaque fiche s\'ajoute ici automatiquement après la lecture d\'un document.')),
      search, msg, box
    ]);
    draw();
  }

  // ---------- bloc-notes ----------
  async function viewNotes(selId) {
    let items = (await api('/api/bloc')).items; let cur = items.find(n => n.id === selId) || items[0] || null;
    const side = h('div', { class: 'list' }); const edit = h('div', { class: 'card notes-edit' });
    let tmr;
    function drawSide() {
      side.replaceChildren(...(items.length ? items.map(n => h('div', { class: 'noteitem pick' + (cur && cur.id === n.id ? ' on' : ''), onclick: () => { cur = n; drawSide(); drawEdit(); } }, h('b', {}, n.title || 'Sans titre'), h('small', {}, ago(n.updated)))) : [h('div', { class: 'muted' }, 'Aucune note.')]));
    }
    function drawEdit() {
      if (!cur) { edit.replaceChildren(h('p', { class: 'muted' }, 'Créez une note pour commencer. Ce bloc-notes est libre : il n\'est lié à aucune fiche.')); return; }
      const t = h('input', { class: 'input', placeholder: 'Titre', 'aria-label': 'Titre', value: cur.title }); const x = h('textarea', { class: 'input', rows: 14, placeholder: 'Idées, essais à faire, remarques...', style: 'resize:vertical' }); x.value = cur.text;
      const st = h('p', { class: 'muted', style: 'font-size:12px;min-height:16px' });
      const saveSoon = () => { clearTimeout(tmr); st.textContent = ''; tmr = setTimeout(async () => { try { const r = await api('/api/bloc/' + cur.id, { method: 'PUT', json: { title: t.value, text: x.value } }); Object.assign(cur, r); st.textContent = 'Enregistré'; drawSide(); } catch (e) { st.textContent = e.message; } }, 700); };
      t.addEventListener('input', saveSoon); x.addEventListener('input', saveSoon);
      edit.replaceChildren(t, x, st, h('button', { class: 'btn small', style: 'align-self:flex-start', onclick: async () => { await api('/api/bloc/' + cur.id, { method: 'DELETE' }); items = items.filter(n => n.id !== cur.id); cur = items[0] || null; drawSide(); drawEdit(); } }, 'Supprimer cette note'));
    }
    drawSide(); drawEdit();
    shell('notes', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Bloc-notes'), h('p', { class: 'sub' }, 'Vos notes libres : idées de formules, essais à faire, remarques. Elles ne sont pas liées à une fiche.')),
        h('button', { class: 'btn primary', onclick: async () => { const n = await api('/api/bloc', { json: { title: 'Nouvelle note', text: '' } }); items.unshift(n); cur = n; drawSide(); drawEdit(); } }, 'Nouvelle note')),
      h('div', { class: 'notes-layout' }, h('div', { class: 'notes-side' }, side), edit)
    ]);
  }

  // ---------- agenda ----------
  const pad = n => String(n).padStart(2, '0'); const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseIso = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const monday = d => addDays(d, -((d.getDay() + 6) % 7));
  const COLORS = [['teal', 'Vert'], ['blue', 'Bleu'], ['indigo', 'Indigo'], ['mauve', 'Mauve'], ['pink', 'Rose'], ['red', 'Rouge'], ['amber', 'Orange'], ['yellow', 'Jaune'], ['brown', 'Marron'], ['gray', 'Gris']];
  async function viewAgenda(openId) {
    const today = parseIso(state.me.today); let mode = 'month'; let cursor = new Date(today); let events = [];
    const cal = h('section', { class: 'card', style: 'padding:0;gap:0;overflow:hidden' }); const panel = h('div', { class: 'ag-side empty', onclick: e => { if (e.target === panel) clearPanel(); } });
    function clearPanel() { panel.className = 'ag-side empty'; panel.replaceChildren(h('section', { class: 'card ph' }, h('p', { class: 'muted' }, 'Cliquez sur un rappel pour le consulter, ou sur un jour du calendrier pour en ajouter un.'))); }
    function setPanel(el) { panel.className = 'ag-side'; panel.replaceChildren(el); }
    clearPanel();
    const range = () => {
      if (mode === 'day') return [cursor, cursor];
      if (mode === 'week') { const s = monday(cursor); return [s, addDays(s, 6)]; }
      const s = monday(new Date(cursor.getFullYear(), cursor.getMonth(), 1)); const e = addDays(monday(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)), 6); return [s, e];
    };
    async function load() { const [a, b] = range(); events = (await api(`/api/agenda?from=${iso(a)}&to=${iso(b)}`)).items; draw(); }
    const title = () => mode === 'month' ? cursor.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) : mode === 'week' ? 'Semaine du ' + monday(cursor).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }) : cursor.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const move = n => { if (mode === 'month') cursor = new Date(cursor.getFullYear(), cursor.getMonth() + n, 1); else cursor = addDays(cursor, n * (mode === 'week' ? 7 : 1)); load(); };
    function evBtn(e) { return h('button', { class: 'ev ' + e.color, title: e.title, onclick: ev => { ev.stopPropagation(); showEvent(e); } }, (e.time ? e.time + ' ' : '') + e.title + (e.note ? ' *' : '')); }
    function draw() {
      const head = h('div', { class: 'cal-head' },
        h('div', { style: 'display:flex;gap:8px;align-items:center' }, h('button', { class: 'sq', 'aria-label': 'Précédent', onclick: () => move(-1) }, '<'), h('button', { class: 'sq', 'aria-label': 'Suivant', onclick: () => move(1) }, '>'),
          h('button', { class: 'btn small', style: 'height:36px;padding:0 14px;background:var(--bg);color:var(--muted);border-color:var(--line)', onclick: () => { cursor = new Date(today); load(); } }, 'Aujourd\'hui')),
        h('h2', {}, title()),
        h('div', { class: 'seg' }, [['month', 'Mois'], ['week', 'Semaine'], ['day', 'Jour']].map(([k, l]) => h('button', { class: mode === k ? 'on' : '', onclick: () => { mode = k; load(); } }, l))));
      let body;
      if (mode === 'day') {
        const list = events.filter(e => e.date === iso(cursor));
        body = h('div', {}, list.length ? list.map(e => h('div', { class: 'dayline' }, h('span', { class: 'dot ' + e.color }), h('span', { style: 'min-width:56px;color:var(--muted);font-size:14px' }, e.time || 'Journée'), h('span', { style: 'flex:1;font-size:16px' }, e.title), h('button', { class: 'link', onclick: () => showEvent(e) }, 'Détails'))) : h('p', { class: 'muted', style: 'padding:24px 20px' }, 'Aucun rappel ce jour.'),
          h('div', { style: 'padding:16px 20px' }, h('button', { class: 'btn small', onclick: () => showForm(iso(cursor)) }, 'Ajouter un rappel ce jour')));
      } else {
        const [a] = range(); const weeks = mode === 'month' ? Math.round((range()[1] - a) / 86400000 + 1) / 7 : 1; const rows = [];
        for (let w = 0; w < weeks; w++) {
          const cells = [];
          for (let i = 0; i < 7; i++) {
            const day = addDays(a, w * 7 + i); const k = iso(day); const out = mode === 'month' && day.getMonth() !== cursor.getMonth();
            cells.push(h('div', { class: 'cal-cell' + (out ? ' out' : '') + (k === iso(today) ? ' today' : ''), onclick: () => showForm(k) }, h('span', { class: 'n' }, day.getDate()), events.filter(e => e.date === k).map(evBtn)));
          }
          rows.push(h('div', { class: 'cal-row' }, cells));
        }
        body = h('div', { class: 'cal-scroll' }, h('div', { class: 'cal' }, h('div', { class: 'cal-row' }, ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(n => h('div', { class: 'cal-dn' }, n))), rows));
      }
      cal.replaceChildren(head, body);
    }
    function showForm(date, ev) {
      const t = h('input', { class: 'input sm', placeholder: 'Intitulé du rappel', 'aria-label': 'Intitulé', value: ev ? ev.title : '' });
      const dt = h('input', { class: 'input sm', type: 'date', value: ev ? ev.date : date, 'aria-label': 'Date' });
      const tm = h('input', { class: 'input sm', type: 'time', 'aria-label': 'Heure', value: ev ? ev.time : '' });
      let colVal = ev ? ev.color : 'teal';
      const sws = h('div', { class: 'sws', role: 'radiogroup', 'aria-label': 'Couleur' }, COLORS.map(([k, l]) => h('button', { type: 'button', class: 'sw ' + k + (k === colVal ? ' on' : ''), title: l, 'aria-label': l, onclick: () => { colVal = k; sws.querySelectorAll('.sw').forEach(x => x.classList.toggle('on', x.classList.contains(k))); } })));
      const note = h('textarea', { class: 'input sm', rows: 3, placeholder: 'Note (facultatif), visible en cliquant sur le rappel', 'aria-label': 'Note', style: 'resize:vertical' }); note.value = ev ? (ev.note || '') : '';
      const err = h('p', { class: 'err' });
      const save = async () => {
        err.textContent = '';
        const body = { title: t.value, date: dt.value, time: tm.value, color: colVal, note: note.value };
        try { const r = ev ? await api('/api/agenda/' + ev.id, { method: 'PUT', json: body }) : await api('/api/agenda', { json: body }); clearPanel(); await load(); if (ev) showEvent(r); } catch (e) { err.textContent = e.message; }
      };
      t.addEventListener('keydown', e => { if (e.key === 'Enter') save(); });
      setPanel(h('section', { class: 'card', style: 'gap:12px' }, h('h2', { style: 'font-size:18px;font-weight:600' }, ev ? 'Modifier le rappel' : 'Nouveau rappel'), t, h('div', { style: 'display:flex;flex-wrap:wrap;gap:10px' }, dt, tm), sws, note, err,
        h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: save }, 'Enregistrer'), h('button', { class: 'btn', onclick: () => { clearPanel(); if (ev) showEvent(ev); } }, 'Annuler'))));
      t.focus();
    }
    function showEvent(e) {
      setPanel(h('section', { class: 'card', style: 'gap:10px' }, h('h2', { style: 'font-size:18px;font-weight:600' }, e.title),
        h('p', { class: 'muted' }, parseIso(e.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + (e.time ? ' à ' + e.time : '')),
        e.note ? h('p', { style: 'white-space:pre-wrap;font-size:15px;line-height:1.5;background:var(--bg);border-radius:8px;padding:12px 14px' }, e.note) : null,
        h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => showForm(e.date, e) }, 'Modifier'),
          h('button', { class: 'btn', onclick: async () => { await api('/api/agenda/' + e.id, { method: 'DELETE' }); clearPanel(); load(); } }, 'Supprimer'),
          h('button', { class: 'btn', onclick: () => clearPanel() }, 'Fermer'))));
    }
    shell('agenda', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Agenda et rappels'), h('p', { class: 'sub' }, 'Les rappels du jour s\'affichent sur l\'accueil.')),
        h('button', { class: 'btn primary', onclick: () => showForm(iso(today)) }, 'Ajouter un rappel')),
      h('div', { class: 'ag-layout' }, cal, panel), h('p', { class: 'muted', style: 'font-size:13px' }, 'Cliquez sur un jour pour ajouter un rappel. Les rappels sont visibles ici et sur l\'accueil, sans notification sur le téléphone.')
    ], 'w-xl');
    if (openId) { try { const ev = await api('/api/agenda/' + openId); cursor = parseIso(ev.date); await load(); showEvent(ev); return; } catch { /* rappel supprime */ } }
    await load();
  }

  // ---------- veille ----------
  async function viewVeille() {
    const v = await api('/api/veille');
    const link = (href, text, meta) => h('div', { style: 'padding:10px 0;border-top:1px solid var(--line-soft);display:flex;flex-direction:column;gap:2px' }, h('a', { href, target: '_blank', rel: 'noopener noreferrer', style: 'font-size:16px;font-weight:600;text-decoration:none' }, text), meta ? h('span', { class: 'muted', style: 'font-size:13px' }, meta) : null);
    const dateFr = iso => iso ? new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : '';
    shell('veille', [
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Veille de la semaine'), null),
      h('div', { class: 'row2' },
        h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Articles de la semaine'),
          v.articles.length ? v.articles.slice(0, 36).map(a => link(a.url, a.title, a.source + (a.date ? ' - ' + dateFr(a.date) : ''))) : h('p', { class: 'muted' }, 'Aucun article récupéré pour le moment. Les sites ci-contre restent consultables.'),
          v.ko && v.ko.length ? h('p', { class: 'muted', style: 'font-size:12px;margin-top:8px' }, 'Flux injoignables : ' + v.ko.join(', ') + '.') : null),
        h('div', { style: 'display:flex;flex-direction:column;gap:20px' },
          h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Salons'), v.salons.map(s => link(s.url, s.name, [s.dates, s.place].filter(Boolean).join(' - ')))),
          h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Sites suivis'), v.sites.map(s => link(s.url, s.name, s.note)))))
    ]);
  }

  // ---------- routeur ----------
  async function route() {
    if (!state.me) return;
    const parts = (location.hash.replace(/^#/, '') || '/').split('/').filter(Boolean);
    try {
      if (!parts.length) return await viewHome();
      const [a, b] = parts;
      if (a === 'consulter') return await viewConsulter(/^MP-\d+$/.test(b || '') ? b : null);
      if (a === 'ajout') return await viewAjout();
      if (a === 'fiche' && /^MP-\d+$/.test(b || '')) return await viewFiche(b);
      if (a === 'comparaison') return await viewComparaison();
      if (a === 'fiches' || a === 'favoris') return await viewFiches();
      if (a === 'notes') return await viewNotes();
      if (a === 'agenda') return await viewAgenda(/^[a-f0-9]+$/.test(b || '') ? b : null);
      if (a === 'veille') return await viewVeille();
      location.hash = '#/';
    } catch (e) { if (e.message !== 'Connexion requise') shell('', [h('a', { href: '#/' }, 'Retour à l\'accueil'), h('p', { class: 'err' }, e.message)]); }
  }
  async function boot() { try { state.me = await api('/api/me'); } catch { renderLogin(); return; } route(); }
  window.addEventListener('hashchange', route);
  boot();
})();
