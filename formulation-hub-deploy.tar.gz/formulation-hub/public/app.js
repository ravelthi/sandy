'use strict';
(() => {
  const root = document.getElementById('root');
  const state = { me: null, cmp: [] };
  try { state.cmp = JSON.parse(localStorage.getItem('fh_cmp') || '[]'); } catch { state.cmp = []; }
  const saveCmp = () => { try { localStorage.setItem('fh_cmp', JSON.stringify(state.cmp)); } catch { /* stockage indisponible */ } };
  const MAX_CMP = 10; const MAX_DOCS = 10; const MAX_MB = 25;
  const NR = 'Non renseigné';

  // ---------- outils DOM (aucun innerHTML : tout passe par textContent) ----------
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (k === 'value') e.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected') e[k] = !!v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) { if (kid === null || kid === undefined || kid === false) continue; e.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return e;
  }
  const NS = 'http://www.w3.org/2000/svg';
  function icon(paths, size = 28, color = '#0b6b63') {
    const s = document.createElementNS(NS, 'svg');
    for (const [k, v] of Object.entries({ width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, 'stroke-width': 1.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) s.setAttribute(k, v);
    for (const d of paths) { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); s.append(p); }
    return s;
  }
  const IC = {
    logo: ['M9 3h6', 'M10 3v6l-5.2 9a2 2 0 0 0 1.7 3h11a2 2 0 0 0 1.7-3L14 9V3', 'M7.5 15h9'],
    search: ['M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z', 'm20 20-3.5-3.5'],
    plus: ['M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z', 'M12 8v8M8 12h8'],
    news: ['M4 5h13a2 2 0 0 1 2 2v12H6a2 2 0 0 1-2-2z', 'M8 9h7M8 13h7M8 17h4'],
    cmp: ['M4.5 4h4a1.5 1.5 0 0 1 1.5 1.5v13A1.5 1.5 0 0 1 8.5 20h-4A1.5 1.5 0 0 1 3 18.5v-13A1.5 1.5 0 0 1 4.5 4z', 'M15.5 4h4A1.5 1.5 0 0 1 21 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-4a1.5 1.5 0 0 1-1.5-1.5v-13A1.5 1.5 0 0 1 15.5 4z'],
    up: ['M12 16V4M7 9l5-5 5 5', 'M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3'],
    chev: ['m6 9 6 6 6-6']
  };
  { const orig = Element.prototype.replaceChildren; Element.prototype.replaceChildren = function (...k) { return orig.apply(this, k.flat(Infinity).filter(x => x !== null && x !== undefined && x !== false)); }; }
  const $ = (s, r = document) => r.querySelector(s);
  const cap = s => String(s || '').charAt(0).toUpperCase() + String(s || '').slice(1);
  const isEmpty = v => v === '' || v === null || v === undefined;

  async function api(path, opts = {}) {
    const o = Object.assign({ headers: {} }, opts);
    if (o.json !== undefined) { o.method = o.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(o.json); delete o.json; }
    const r = await fetch(path, o);
    let j = {}; try { j = await r.json(); } catch { /* corps vide */ }
    if (r.status === 401 && path !== '/api/login') { renderLogin(); throw new Error('Connexion requise'); }
    if (!r.ok) throw new Error(j.error || 'Erreur ' + r.status);
    return j;
  }
  function toast(t) { const e = h('div', { class: 'toast' }, t); document.body.append(e); setTimeout(() => e.remove(), 1800); }
  document.addEventListener('click', e => { document.querySelectorAll('details.dd[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); }); });
  window.addEventListener('beforeprint', () => document.querySelectorAll('details.group').forEach(d => { d.dataset.wasOpen = d.open ? '1' : ''; d.open = true; }));
  window.addEventListener('afterprint', () => document.querySelectorAll('details.group').forEach(d => { d.open = d.dataset.wasOpen === '1'; }));

  // ---------- coque de page ----------
  function shell(active, content, width = 'w-lg') {
    document.title = 'Formulation Hub';
    const link = (href, label, key) => h('a', { href, class: active === key ? 'on' : '' }, label);
    const spaceOn = ['favoris', 'notes', 'agenda'].includes(active);
    root.replaceChildren(h('div', { class: 'page' },
      h('header', { class: 'hdr noprint' },
        h('a', { href: '#/', class: 'brand' }, icon(IC.logo, 28), 'Formulation Hub'),
        h('nav', { class: 'nav' },
          h('details', { class: 'dd' }, h('summary', { class: spaceOn ? 'on' : '' }, 'Mon espace'),
            h('div', { class: 'menu' }, h('a', { href: '#/favoris' }, 'Favoris'), h('a', { href: '#/notes' }, 'Bloc-notes'), h('a', { href: '#/agenda' }, 'Agenda et rappels'))),
          link('#/consulter', 'Consulter une fiche', 'consulter'), link('#/ajout', 'Ajouter une MP', 'ajout'), link('#/veille', 'Veille', 'veille'),
          link('#/comparaison', 'Comparaison (' + state.cmp.length + ')', 'comparaison')),
        h('details', { class: 'dd' }, h('summary', { class: 'profile' }, h('span', { class: 'avatar' }, state.me.name.charAt(0).toUpperCase()), state.me.name),
          h('div', { class: 'menu right' }, h('button', { onclick: async () => { await api('/api/logout', { method: 'POST' }); renderLogin(); } }, 'Déconnexion')))),
      h('main', { class: 'main ' + width }, content),
      h('footer', { class: 'footer noprint' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.' + (state.me.mock ? ' Mode démonstration.' : ''))));
    window.scrollTo(0, 0);
  }

  // ---------- connexion ----------
  function renderLogin() {
    let saved = ''; try { saved = localStorage.getItem('fh_name') || ''; } catch { /* stockage indisponible */ }
    const name = h('input', { class: 'input', id: 'prenom', type: 'text', placeholder: 'Votre prénom', autocomplete: 'given-name', value: saved });
    const pw = h('input', { class: 'input', id: 'mdp', type: 'password', autocomplete: 'current-password' });
    const msg = h('p', { class: 'err' });
    const go = async () => {
      msg.textContent = '';
      try { const r = await api('/api/login', { json: { name: name.value, password: pw.value } }); try { localStorage.setItem('fh_name', r.name); } catch { /* ignore */ } pw.value = ''; await boot(); } catch (e) { msg.textContent = e.message; }
    };
    for (const i of [name, pw]) i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    root.replaceChildren(h('div', { class: 'page' }, h('div', { class: 'login-wrap' }, h('section', { class: 'card login' },
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('div', { style: 'display:flex;align-items:center;gap:12px' }, icon(IC.logo, 32), h('h1', { style: 'font-size:28px;font-weight:700;letter-spacing:-.02em' }, 'Formulation Hub')),
        h('p', { class: 'muted', style: 'font-size:15px' }, 'Base de connaissances matières premières. Connectez-vous pour continuer.')),
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('label', { for: 'prenom', style: 'font-size:14px;font-weight:600' }, 'Prénom'), name),
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('label', { for: 'mdp', style: 'font-size:14px;font-weight:600' }, 'Mot de passe'), pw),
      msg, h('button', { class: 'btn primary', style: 'padding:14px 20px;font-size:16px;text-align:center', onclick: go }, 'Se connecter'),
      h('p', { class: 'muted', style: 'font-size:13px' }, 'Le prénom sert uniquement à vous saluer. Il est gardé dans votre navigateur.'))),
      h('footer', { class: 'footer' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.')));
    (saved ? pw : name).focus();
  }

  // ---------- accueil ----------
  const ago = iso => {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 2) return 'à l\'instant'; if (m < 60) return 'il y a ' + m + ' min'; const hr = Math.round(m / 60);
    if (hr < 24) return 'il y a ' + hr + ' h'; const d = Math.round(hr / 24); return d === 1 ? 'hier' : 'il y a ' + d + ' j';
  };
  const itemRow = (href, left, right) => h('a', { href, style: 'display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-top:1px solid var(--line);text-decoration:none;color:var(--text);font-size:16px;font-weight:500' }, h('span', {}, left), h('span', { style: 'color:var(--muted);font-weight:400;font-size:14px' }, right));
  async function viewHome() {
    const home = await api('/api/home');
    const tile = (href, ic, title, text) => h('a', { class: 'tile', href }, icon(ic, 32), h('b', {}, title), h('span', {}, text), h('em', {}, 'Ouvrir'));
    const agenda = h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Aujourd\'hui dans l\'agenda'),
      home.agenda.length ? home.agenda.map(e => itemRow('#/agenda', e.title, e.time || 'Journée')) : h('p', { class: 'muted' }, 'Aucun rappel aujourd\'hui. ', h('a', { href: '#/agenda' }, 'Ouvrir l\'agenda')));
    shell('home', [
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('p', { class: 'eyebrow' }, 'Base de connaissances matières premières'),
        h('h1', { style: 'font-size:44px;line-height:1.1;font-weight:700;letter-spacing:-.02em' }, 'Bonjour ' + state.me.name),
        h('p', { style: 'font-size:20px;line-height:1.5;max-width:640px' }, 'Que souhaitez-vous faire ?'),
        h('p', { class: 'sub', style: 'max-width:640px' }, 'Retrouvez les informations d\'une matière première à partir de ses documents, ajoutez-en une nouvelle, comparez des fiches ou consultez la veille de la semaine.')),
      agenda,
      h('div', { class: 'cards4' },
        tile('#/consulter', IC.search, 'Consulter une fiche', 'Cherchez une matière première, déposez ses documents PDF et obtenez sa fiche complète.'),
        tile('#/ajout', IC.plus, 'Ajouter une matière première', 'Créez une nouvelle entrée dans la base. Un identifiant MP-xxxx lui est attribué automatiquement.'),
        tile('#/veille', IC.news, 'Veille de la semaine', 'Les liens des articles et des salons cosmétiques de la semaine, à consulter.'),
        tile('#/comparaison', IC.cmp, 'Comparaison', 'Placez jusqu\'à ' + MAX_CMP + ' fiches côte à côte pour les comparer critère par critère.')),
      h('div', { class: 'row2' },
        h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Dernières fiches consultées'),
          home.recents.length ? home.recents.map(r => itemRow('#/fiche/' + r.id, r.name, ago(r.at))) : h('p', { class: 'muted' }, 'Aucune fiche consultée pour le moment.')),
        h('section', { class: 'card tight', style: 'gap:12px' }, h('h2', { class: 'card-title', style: 'margin:0' }, 'Comparaison en cours'),
          h('p', {}, state.cmp.length ? `${state.cmp.length} fiche${state.cmp.length > 1 ? 's' : ''} sélectionnée${state.cmp.length > 1 ? 's' : ''} sur ${MAX_CMP}.` : 'Aucune fiche sélectionnée.'),
          h('a', { class: 'btn primary', style: 'align-self:flex-start', href: '#/comparaison' }, 'Voir la comparaison'))),
      h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Favoris'),
        home.favs.length ? home.favs.map(r => itemRow('#/fiche/' + r.id, r.name, 'Ouvrir')) : h('p', { class: 'muted' }, 'Aucun favori. Utilisez « Épingler en favori » sur une fiche.'))
    ]);
  }

  // ---------- consulter une fiche ----------
  async function viewConsulter(preId) {
    let selected = null; let q = ''; let items = []; const ready = []; // { id, name, size, state }
    const msg = h('p', { class: 'err' });
    const search = h('input', { class: 'input', id: 'q', type: 'search', placeholder: 'Nom commercial', autocomplete: 'off' });
    const listBox = h('div'); const selBox = h('div'); const exp = h('a', { class: 'btn small', style: 'align-self:flex-start', href: '/api/export.csv', download: 'matieres-premieres.csv' }, 'Exporter la liste en tableau (CSV)');
    const docList = h('div'); const status = h('div');
    const go = h('button', { class: 'btn primary', style: 'padding:14px 24px;font-size:16px', disabled: true, onclick: run }, 'Extraire et afficher la fiche');
    let tmr;
    async function load() {
      q = search.value.trim(); exp.setAttribute('href', '/api/export.csv?q=' + encodeURIComponent(q));
      try { items = (await api('/api/mps?q=' + encodeURIComponent(q))).items; } catch (e) { msg.textContent = e.message; return; }
      drawList();
    }
    function drawList() {
      listBox.replaceChildren(items.length ? h('div', { class: 'list', style: 'max-height:300px;overflow-y:auto' }, items.slice(0, 50).map(m => h('div', { class: 'pick' + (selected && selected.id === m.id ? ' sel' : ''), onclick: () => choose(m) },
        h('span', { style: 'font-size:16px;font-weight:' + (selected && selected.id === m.id ? 600 : 400) }, m.name), h('span', { style: 'font-size:13px;color:var(--muted);white-space:nowrap' }, m.id + (selected && selected.id === m.id ? ' - Sélectionnée' : ''))))) :
        h('p', { class: 'muted' }, q ? 'Aucune matière première ne correspond. ' : '', h('a', { href: '#/ajout' }, 'Ajouter une MP')));
    }
    function choose(m) {
      selected = m; drawList(); drawSel(); syncGo();
    }
    function drawSel() {
      selBox.replaceChildren(selected ? h('p', { class: 'muted' }, 'Matière première choisie : ', h('b', { style: 'color:var(--text)' }, selected.name), ' (' + selected.id + ')',
        selected.inci || selected.cat ? [' - ', h('a', { href: '#/fiche/' + selected.id }, 'Ouvrir la fiche déjà enregistrée')] : null) : null);
    }
    function syncGo() { go.disabled = !(selected && ready.some(f => f.state === 'ok')); }
    search.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(load, 250); });
    // documents
    const file = h('input', { type: 'file', accept: 'application/pdf', multiple: true, style: 'display:none', onchange: e => { upload([...e.target.files]); e.target.value = ''; } });
    const drop = h('div', { class: 'drop', onclick: () => file.click() }, icon(IC.up, 32, '#5b6b77'), h('b', {}, 'Glissez les PDF ici, ou cliquez pour les choisir'), h('span', {}, `Fiche technique, fiche de sécurité, brochure. Jusqu'à ${MAX_DOCS} documents, ${MAX_MB} Mo chacun.`));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); upload([...e.dataTransfer.files]); });
    function drawDocs() {
      docList.replaceChildren(ready.length ? h('div', { class: 'list' }, ready.map(f => h('div', {}, h('span', { style: 'font-size:15px;min-width:0;overflow-wrap:anywhere' }, f.name),
        h('span', { style: 'display:flex;gap:10px;align-items:center' }, h('span', { class: 'badge' + (f.state === 'err' ? ' warn' : '') }, f.state === 'ok' ? 'Prêt' : f.state === 'err' ? f.error : 'Envoi...'),
          h('button', { class: 'link', onclick: () => { ready.splice(ready.indexOf(f), 1); drawDocs(); syncGo(); } }, 'Retirer'))))) : null);
    }
    async function upload(fl) {
      msg.textContent = '';
      for (const f of fl) {
        if (ready.length >= MAX_DOCS) { msg.textContent = `${MAX_DOCS} documents maximum.`; break; }
        if (!/\.pdf$/i.test(f.name)) { msg.textContent = 'Seuls les fichiers PDF sont acceptés.'; continue; }
        if (f.size > MAX_MB * 1024 * 1024) { msg.textContent = `${f.name} dépasse ${MAX_MB} Mo.`; continue; }
        const it = { name: f.name, state: 'up' }; ready.push(it); drawDocs();
        try { const r = await api('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f, headers: { 'Content-Type': 'application/pdf' } }); it.id = r.id; it.state = 'ok'; } catch (e) { it.state = 'err'; it.error = e.message; }
        drawDocs(); syncGo();
      }
    }
    async function run() {
      msg.textContent = ''; go.disabled = true;
      const fill = h('div', { style: 'width:0%' }); const stepEl = h('p', { class: 'muted' });
      status.replaceChildren(h('p', { style: 'font-size:18px;font-weight:600;margin-bottom:10px' }, 'Analyse en cours...'), h('div', { class: 'bar' }, fill), stepEl,
        h('p', { class: 'muted', style: 'font-size:13px;margin-top:8px' }, 'Comptez environ une minute par document. Vous pouvez laisser cette page ouverte.'));
      try {
        const { job } = await api('/api/extract', { json: { mp_id: selected.id, files: ready.filter(f => f.state === 'ok').map(f => ({ id: f.id })) } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500));
          const j = await api('/api/jobs/' + job);
          fill.style.width = j.pct + '%'; stepEl.textContent = j.step;
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') {
            const r = j.result;
            if (!r.failed.length && !r.skipped.length) { location.hash = '#/fiche/' + selected.id; return; }
            status.replaceChildren(h('p', { style: 'font-size:18px;font-weight:600' }, `${r.docsRead} document${r.docsRead > 1 ? 's' : ''} analysé${r.docsRead > 1 ? 's' : ''}`),
              r.skipped.map(s => h('p', { class: 'muted' }, `${s.name} : ${s.reason}.`)), r.failed.map(f => h('p', { class: 'err' }, `${f.name} : ${f.error}`)),
              h('a', { class: 'btn primary', style: 'align-self:flex-start', href: '#/fiche/' + selected.id }, 'Voir la fiche'));
            ready.length = 0; drawDocs(); return;
          }
        }
      } catch (e) { status.replaceChildren(h('p', { class: 'err' }, e.message)); syncGo(); }
    }
    shell('consulter', [
      h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, h('h1', { class: 'h1' }, 'Consulter une fiche'), h('p', { class: 'sub' }, 'Deux étapes : choisissez la matière première, puis déposez ses documents.')),
      h('section', { class: 'card' }, h('div', { class: 'step-h' }, h('span', { class: 'step' }, '1'), h('h2', {}, 'Matière première')), h('label', { for: 'q', class: 'lbl' }, 'Nom commercial'), search, listBox, selBox, exp),
      h('section', { class: 'card' }, h('div', { class: 'step-h' }, h('span', { class: 'step' }, '2'), h('h2', {}, 'Documents')), drop, file, docList, msg,
        h('div', { style: 'display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px' },
          h('p', { class: 'muted', style: 'max-width:520px' }, 'Les documents sont analysés puis supprimés. Ils ne sont pas conservés, seules les informations extraites sont enregistrées.'), go), status)
    ], 'w-md');
    if (preId) { try { const d = await api('/api/mps?q='); void d; const all = (await api('/api/mp-names')).items; const m = all.find(x => x.id === preId); if (m) { search.value = m.name; await load(); const hit = items.find(x => x.id === preId); if (hit) choose(hit); } } catch { /* ignore */ } } else load();
    search.focus();
  }

  // ---------- ajouter une MP ----------
  async function viewAjout() {
    const names = (await api('/api/mp-names')).items;
    const next = 'MP-' + String(Math.max(0, ...names.map(n => parseInt(n.id.slice(3), 10) || 0)) + 1).padStart(4, '0');
    const input = h('input', { class: 'input', id: 'trade', type: 'text', placeholder: 'Ex : CAMELLIA OIL' });
    const msg = h('p', { class: 'err' }); const done = h('div');
    const add = async () => {
      msg.textContent = '';
      try { const r = await api('/api/mps', { json: { name: input.value } }); done.replaceChildren(h('section', { class: 'card', style: 'background:var(--accent-soft);border-color:#b9dcd7;gap:10px' },
        h('p', { class: 'ok', style: 'font-size:15px' }, `Matière première ajoutée : ${r.name} (${r.id})`), h('a', { class: 'btn primary small', style: 'align-self:flex-start', href: '#/consulter/' + r.id }, 'Déposer ses documents'))); input.value = ''; } catch (e) { msg.textContent = e.message; }
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
    shell('ajout', [
      h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, h('h1', { class: 'h1' }, 'Ajouter une matière première'), h('p', { class: 'sub' }, 'Indiquez son nom commercial. La matière première est ajoutée à la base avec un identifiant unique, puis vous pouvez déposer ses documents.')),
      h('section', { class: 'card' }, h('label', { for: 'trade', style: 'font-size:14px;font-weight:600' }, 'Nom commercial'), input,
        h('p', { class: 'muted' }, 'Identifiant attribué : ', h('b', { style: 'color:var(--text)' }, next), ' (le numéro suivant dans la base).'), msg,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:12px;align-items:center' }, h('button', { class: 'btn primary', style: 'padding:14px 24px;font-size:16px', onclick: add }, 'Ajouter à la base'), h('a', { href: '#/', style: 'font-size:15px;font-weight:500;text-decoration:none' }, 'Annuler'))),
      done
    ], 'w-sm');
    input.focus();
  }

  // ---------- fiche ----------
  const joinRange = (lo, hi) => (isEmpty(lo) && isEmpty(hi)) ? '' : isEmpty(hi) ? String(lo) : isEmpty(lo) ? String(hi) : lo + ' - ' + hi;
  async function viewFiche(id) {
    const d = await api('/api/mp/' + id);
    api('/api/mp/' + id + '/open', { method: 'POST' }).catch(() => { });
    const ui = state.me.ui; const f = () => d.fields;
    const msg = h('p', { class: 'err noprint' });
    const top = h('div', { class: 'actions noprint' }); const bottom = h('div', { class: 'actions bottom noprint' });
    const verifyBox = h('div'); const head = h('div'); const groupsBox = h('div', { class: 'groups' }); const docsLu = h('div');
    const isCmp = () => state.cmp.some(c => c.id === id);
    async function save(changes) {
      msg.textContent = '';
      try { const nd = await api('/api/mp/' + id, { method: 'PUT', json: { changes } }); Object.assign(d, nd); toast('Enregistré'); } catch (e) { msg.textContent = e.message; }
      drawAll();
    }
    const srcOf = row => { for (const l of row.src) if (d.sources[l]) return d.sources[l]; return ''; };
    function valueOf(row) { return row.kind === 'range' ? joinRange(f()[row.header], f()[row.header2]) : f()[row.header]; }
    function control(row) {
      const val = f()[row.header];
      if (row.kind === 'yn' || row.kind === 'charge') {
        const opts = row.kind === 'yn' ? ['Oui', 'Non'] : state.me.ui.charges;
        return [opts.concat([NR]).map(o => h('button', { type: 'button', class: 'chip' + ((o === NR ? isEmpty(val) : val === o) ? ' on' : ''), onclick: () => save({ [row.header]: o === NR ? '' : o }) }, o))];
      }
      if (row.kind === 'cat') {
        const det = h('details', { class: 'dd', style: 'position:relative' }, h('summary', { class: 'sel-btn', style: isEmpty(val) ? 'color:var(--muted);font-style:italic' : '' }, isEmpty(val) ? NR : val, icon(IC.chev, 14, '#5b6b77')),
          h('div', { class: 'pop' }, [NR].concat(ui.cats).map(o => h('div', { class: (o === NR ? isEmpty(val) : val === o) ? 'on' : '', onclick: () => { det.removeAttribute('open'); save({ [row.header]: o === NR ? '' : o }); } }, o))));
        return [det];
      }
      if (row.kind === 'multi') {
        const cur = isEmpty(val) ? [] : String(val).split(/\s*,\s*/);
        const det = h('details', { class: 'dd', style: 'position:relative' }, h('summary', { class: 'pill add' }, '+ Ajouter'),
          h('div', { class: 'pop' }, ui.foncs.filter(x => !cur.includes(x)).map(o => h('div', { onclick: () => { det.removeAttribute('open'); save({ [row.header]: cur.concat([o]).join(', ') }); } }, o))));
        return [cur.length ? null : h('span', { class: 'empty', style: 'font-size:14px' }, NR), cur.map(x => h('button', { type: 'button', class: 'pill', title: 'Cliquer pour retirer', onclick: () => save({ [row.header]: cur.filter(y => y !== x).join(', ') }) }, x + ' x')), det];
      }
      // texte, nombre, plage : champ modifiable directement
      const v = row.kind === 'range' ? joinRange(f()[row.header], f()[row.header2]) : (isEmpty(val) ? '' : String(val));
      const ta = h('textarea', { class: 'edit', rows: 1, placeholder: NR, 'aria-label': row.label }); ta.value = v;
      const fit = () => { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 'px'; };
      let done = false;
      ta.addEventListener('input', fit);
      ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ta.blur(); } if (e.key === 'Escape') { done = true; ta.value = v; ta.blur(); } });
      ta.addEventListener('blur', () => {
        if (done) { done = false; return; } const nv = ta.value.trim(); if (nv === v) return;
        if (row.kind === 'range') { const p = nv.split(/\s*[-;\/]\s*/); save({ [row.header]: (p[0] || '').trim(), [row.header2]: p[1] !== undefined ? p[1].trim() : '' }); } else save({ [row.header]: nv });
      });
      setTimeout(fit, 0);
      return [ta, row.unit && v ? h('span', { class: 'muted', style: 'white-space:nowrap' }, row.unit) : null];
    }
    function drawGroups() {
      const open = {}; groupsBox.querySelectorAll('details.group').forEach(g => { open[g.dataset.t] = g.open; });
      groupsBox.replaceChildren(...ui.groups.map((g, gi) => {
        const filled = g.rows.filter(r => !isEmpty(valueOf(r))).length;
        const det = h('details', { class: 'group', 'data-t': g.title }, h('summary', {}, h('h2', {}, g.title), h('span', { class: 'cnt' }, `${filled} sur ${g.rows.length} renseignés`, icon(IC.chev, 16, '#5b6b77'))),
          g.rows.map(row => {
            const filledRow = !isEmpty(valueOf(row)); const s = srcOf(row);
            return h('div', { class: 'frow' }, h('span', { class: 'fl' }, row.label, filledRow && s ? h('span', { class: 'src', tabindex: '0' }, '?', h('span', { class: 'tip' }, s)) : null), h('div', { class: 'fv' }, ...control(row)));
          }));
        det.querySelector('summary').lastChild.lastChild.setAttribute('class', 'chev');
        det.open = open[g.title] !== undefined ? open[g.title] : gi === 0;
        return det;
      }));
    }
    function actions() {
      const verified = d.fields.Statut === 'Verifie';
      return [
        h('button', { class: 'btn', onclick: async () => { try { if (d.fav) await api('/api/favs/' + id, { method: 'DELETE' }); else await api('/api/favs/' + id, { method: 'PUT' }); d.fav = !d.fav; drawAll(); toast(d.fav ? 'Ajouté aux favoris' : 'Retiré des favoris'); } catch (e) { msg.textContent = e.message; } } }, d.fav ? 'Retirer des favoris' : 'Épingler en favori'),
        h('button', { class: 'btn', onclick: () => { if (isCmp()) { location.hash = '#/comparaison'; return; } if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches dans la comparaison.`; return; } state.cmp.push({ id, name: f()['Trade name'] }); saveCmp(); drawAll(); toast('Ajouté à la comparaison'); } }, isCmp() ? 'Voir dans la comparaison' : 'Ajouter à la comparaison'),
        verified ? null : h('button', { class: 'btn', onclick: async () => { try { Object.assign(d, await api('/api/mp/' + id + '/verify', { method: 'POST' })); drawAll(); } catch (e) { msg.textContent = e.message; } } }, 'Marquer comme vérifié'),
        h('button', { class: 'btn primary', onclick: () => window.print() }, 'Télécharger la fiche (PDF)')
      ];
    }
    function drawAll() {
      const verified = d.fields.Statut === 'Verifie';
      head.replaceChildren(h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' }, h('span', { style: 'font-size:13px;color:var(--muted);font-weight:500' }, id), h('span', { class: 'badge' + (verified ? '' : ' warn') }, verified ? 'Vérifié' : 'À vérifier')),
        h('h1', { style: 'font-size:40px;line-height:1.1;font-weight:700;letter-spacing:-.02em' }, f()['Trade name'] || id),
        h('p', { class: 'sub' }, [f().INCI, f().Supplier].filter(Boolean).join(' - ')));
      top.replaceChildren(...actions()); bottom.replaceChildren(...actions());
      verifyBox.replaceChildren(d.toVerify.length ? h('section', { class: 'warnbox noprint' }, h('h2', {}, `${d.toVerify.length} point${d.toVerify.length > 1 ? 's' : ''} à vérifier`),
        d.toVerify.map(t => h('p', {}, h('b', {}, t.field + ' : '), t.reason, t.source_excerpt ? h('i', { style: 'color:var(--muted)' }, ' « ' + t.source_excerpt + ' »') : null))) : null);
      const names = [...new Set(Object.values(d.sources).flatMap(s => String(s).split(' ; ')).filter(s => s && !s.startsWith('Saisie manuelle')))];
      docsLu.replaceChildren(h('h2', { class: 'eyebrow' }, 'Documents lus'), names.length ? names.map(n => h('p', { style: 'font-size:15px;overflow-wrap:anywhere' }, n)) : h('p', { class: 'muted' }, 'Aucun document analysé pour le moment.'), h('p', { class: 'muted', style: 'font-size:13px' }, 'Ces documents ne sont pas conservés.'));
      drawGroups();
    }
    // notes de la fiche
    const notes = d.notes;
    const ta = h('textarea', { class: 'input sm', id: 'note', rows: 6, style: 'resize:vertical', placeholder: 'Ajouter une note, une remarque, un contexte' }); ta.value = notes.text || '';
    let tmr; const noteState = h('p', { class: 'muted', style: 'font-size:12px;min-height:16px' });
    ta.addEventListener('input', () => { clearTimeout(tmr); noteState.textContent = ''; tmr = setTimeout(async () => { try { await api('/api/notes/' + id, { method: 'PUT', json: { text: ta.value } }); noteState.textContent = 'Enregistré'; } catch (e) { noteState.textContent = e.message; } }, 800); });
    const imgs = h('div');
    const drawImgs = () => imgs.replaceChildren(...notes.images.map(n => h('div', {}, h('img', { class: 'notes-img', src: '/api/note-img/' + n, alt: 'Image de la note' }),
      h('button', { class: 'link noprint', onclick: async () => { const r = await api('/api/notes/' + id + '/image/' + n, { method: 'DELETE' }); notes.images = r.images; drawImgs(); } }, 'Retirer l\'image'))));
    const imgIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: 'display:none', onchange: async e => { const fl = e.target.files[0]; if (!fl) return; try { const r = await api('/api/notes/' + id + '/image', { method: 'POST', body: fl, headers: { 'Content-Type': fl.type } }); notes.images = r.images; drawImgs(); } catch (er) { noteState.textContent = er.message; } e.target.value = ''; } });
    drawImgs(); drawAll();
    document.title = (f()['Trade name'] || 'Fiche') + ' - Formulation Hub';
    shell('fiche', [
      h('a', { href: '#/consulter', class: 'noprint', style: 'font-size:14px;text-decoration:none;font-weight:500' }, 'Retour à la recherche'),
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:20px' }, h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, head), top),
      msg, verifyBox,
      h('p', { class: 'muted noprint' }, 'Cliquez sur une valeur pour la modifier. Les modifications sont enregistrées automatiquement et ne sont jamais écrasées par une nouvelle analyse.'),
      groupsBox,
      h('div', { class: 'row2' }, h('section', { class: 'card', style: 'padding:20px 24px;gap:12px' }, docsLu),
        h('section', { class: 'card noprint', style: 'padding:20px 24px;gap:12px' }, h('h2', { class: 'eyebrow' }, 'Notes'), h('label', { for: 'note', class: 'lbl' }, 'Ajouter une note, une remarque, un contexte'), ta, noteState, imgs, imgIn,
          h('button', { class: 'btn small', style: 'align-self:flex-start', onclick: () => imgIn.click() }, 'Ajouter une image'))),
      h('div', { class: 'only-print' }, notes.text ? h('p', { style: 'white-space:pre-wrap' }, notes.text) : null),
      bottom
    ]);
  }

  // ---------- comparaison ----------
  async function viewComparaison() {
    const names = (await api('/api/mp-names')).items;
    const data = state.cmp.length ? (await api('/api/compare', { json: { ids: state.cmp.map(c => c.id) } })).items : [];
    const ui = state.me.ui; const msg = h('p', { class: 'err' });
    const dl = h('datalist', { id: 'fh-names' }, names.slice(0, 1500).map(n => h('option', { value: n.name })));
    const add = h('input', { class: 'input sm', type: 'text', list: 'fh-names', placeholder: 'Ajouter une fiche - tapez pour filtrer', style: 'max-width:300px' });
    const tryAdd = () => {
      const v = add.value.trim().toLowerCase(); if (!v) return;
      const hit = names.find(n => n.name.toLowerCase() === v) || names.find(n => n.name.toLowerCase().startsWith(v));
      if (!hit) { msg.textContent = `Aucune matière première ne correspond à « ${add.value} ».`; return; }
      if (state.cmp.some(c => c.id === hit.id)) { msg.textContent = hit.name + ' est déjà dans la comparaison.'; return; }
      if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches.`; return; }
      state.cmp.push(hit); saveCmp(); viewComparaison();
    };
    add.addEventListener('change', tryAdd); add.addEventListener('keydown', e => { if (e.key === 'Enter') tryAdd(); });
    const cell = (v, kind) => { const e = isEmpty(v); return h('td', { class: e ? 'empty' : '', style: !e && v === 'Oui' ? 'color:var(--accent);font-weight:600' : '' }, e ? NR : kind === 'unit' ? v : String(v)); };
    const rows = [];
    for (const g of ui.groups) {
      rows.push(h('tr', { class: 'head' }, h('td', {}, g.title), data.map(() => h('td'))));
      for (const r of g.rows) rows.push(h('tr', {}, h('td', {}, r.label), data.map(c => cell(r.kind === 'range' ? (joinRange(c.fields[r.header], c.fields[r.header2]) ? joinRange(c.fields[r.header], c.fields[r.header2]) + (r.unit ? ' ' + r.unit : '') : '') : c.fields[r.header], 'unit'))));
    }
    shell('comparaison', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Comparaison'), h('p', { class: 'sub' }, `${state.cmp.length} fiche${state.cmp.length > 1 ? 's' : ''} sélectionnée${state.cmp.length > 1 ? 's' : ''} sur ${MAX_CMP} au maximum.`)),
        h('div', { class: 'actions noprint' }, add, dl, h('button', { class: 'btn primary', onclick: () => window.print() }, 'Télécharger la comparaison (PDF)'))),
      msg,
      data.length ? h('div', { class: 'cmp' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', {}, 'Critère'), data.map(c => h('th', {}, h('a', { href: '#/fiche/' + c.id, style: 'font-size:17px;font-weight:700;color:var(--text);text-decoration:none;display:block' }, c.name), h('span', { style: 'font-size:13px;color:var(--muted);font-weight:400;display:block' }, c.id),
        h('button', { class: 'link noprint', onclick: () => { state.cmp = state.cmp.filter(x => x.id !== c.id); saveCmp(); viewComparaison(); } }, 'Retirer'))))), h('tbody', {}, rows))) :
        h('section', { class: 'card' }, h('p', { class: 'muted' }, 'Aucune fiche dans la comparaison. Utilisez le champ ci-dessus ou le bouton « Ajouter à la comparaison » d\'une fiche.')),
      h('p', { class: 'muted noprint', style: 'font-size:13px;max-width:720px' }, 'Sur ordinateur, jusqu\'à ' + MAX_CMP + ' colonnes avec défilement horizontal ; la colonne des critères reste visible.')
    ], 'w-xl');
  }

  // ---------- favoris ----------
  async function viewFavoris() {
    const r = await api('/api/favs');
    shell('favoris', [
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Favoris'), h('p', { class: 'sub' }, 'Les fiches que vous avez épinglées, pour les retrouver en un clic.')),
      h('section', { class: 'card', style: 'padding:8px 24px 12px;gap:0' },
        r.items.length ? r.items.map(m => h('div', { style: 'display:flex;flex-wrap:wrap;gap:4px 16px;align-items:center;padding:14px 0;border-top:1px solid var(--line-soft)' },
          h('a', { href: '#/fiche/' + m.id, style: 'flex:2 1 320px;font-size:16px;font-weight:600;text-decoration:none;color:var(--text)' }, m.name), h('span', { class: 'muted', style: 'flex:1 1 120px' }, m.id), h('span', { class: 'muted', style: 'flex:1 1 200px' }, m.cat || NR),
          h('button', { class: 'btn small', onclick: async () => { await api('/api/favs/' + m.id, { method: 'DELETE' }); viewFavoris(); } }, 'Retirer'))) :
          h('p', { class: 'muted', style: 'padding:16px 0' }, 'Aucun favori pour le moment. Utilisez « Épingler en favori » sur une fiche.'))
    ]);
  }

  // ---------- bloc-notes ----------
  async function viewNotes(selId) {
    let items = (await api('/api/bloc')).items; let cur = items.find(n => n.id === selId) || items[0] || null;
    const side = h('div', { class: 'list' }); const edit = h('div', { class: 'card notes-edit' });
    let tmr;
    function drawSide() {
      side.replaceChildren(...(items.length ? items.map(n => h('div', { class: 'noteitem pick' + (cur && cur.id === n.id ? ' on' : ''), onclick: () => { cur = n; drawSide(); drawEdit(); } }, h('b', {}, n.title || 'Sans titre'), h('small', {}, ago(n.updated)))) : [h('div', { class: 'muted' }, 'Aucune note.')]));
    }
    function drawEdit() {
      if (!cur) { edit.replaceChildren(h('p', { class: 'muted' }, 'Créez une note pour commencer. Ce bloc-notes est libre : il n\'est lié à aucune fiche.')); return; }
      const t = h('input', { class: 'input', placeholder: 'Titre', 'aria-label': 'Titre', value: cur.title }); const x = h('textarea', { class: 'input', rows: 14, placeholder: 'Idées, essais à faire, remarques...', style: 'resize:vertical' }); x.value = cur.text;
      const st = h('p', { class: 'muted', style: 'font-size:12px;min-height:16px' });
      const saveSoon = () => { clearTimeout(tmr); st.textContent = ''; tmr = setTimeout(async () => { try { const r = await api('/api/bloc/' + cur.id, { method: 'PUT', json: { title: t.value, text: x.value } }); Object.assign(cur, r); st.textContent = 'Enregistré'; drawSide(); } catch (e) { st.textContent = e.message; } }, 700); };
      t.addEventListener('input', saveSoon); x.addEventListener('input', saveSoon);
      edit.replaceChildren(t, x, st, h('button', { class: 'btn small', style: 'align-self:flex-start', onclick: async () => { await api('/api/bloc/' + cur.id, { method: 'DELETE' }); items = items.filter(n => n.id !== cur.id); cur = items[0] || null; drawSide(); drawEdit(); } }, 'Supprimer cette note'));
    }
    drawSide(); drawEdit();
    shell('notes', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Bloc-notes'), h('p', { class: 'sub' }, 'Vos notes libres : idées de formules, essais à faire, remarques. Elles ne sont pas liées à une fiche.')),
        h('button', { class: 'btn primary', onclick: async () => { const n = await api('/api/bloc', { json: { title: 'Nouvelle note', text: '' } }); items.unshift(n); cur = n; drawSide(); drawEdit(); } }, 'Nouvelle note')),
      h('div', { class: 'notes-layout' }, h('div', { class: 'notes-side' }, side), edit)
    ]);
  }

  // ---------- agenda ----------
  const pad = n => String(n).padStart(2, '0'); const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseIso = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const monday = d => addDays(d, -((d.getDay() + 6) % 7));
  const COLORS = [['teal', 'Vert'], ['blue', 'Bleu'], ['amber', 'Orange'], ['mauve', 'Mauve']];
  async function viewAgenda() {
    const today = parseIso(state.me.today); let mode = 'month'; let cursor = new Date(today); let events = [];
    const cal = h('section', { class: 'card', style: 'padding:0;gap:0;overflow:hidden' }); const panel = h('div');
    const range = () => {
      if (mode === 'day') return [cursor, cursor];
      if (mode === 'week') { const s = monday(cursor); return [s, addDays(s, 6)]; }
      const s = monday(new Date(cursor.getFullYear(), cursor.getMonth(), 1)); const e = addDays(monday(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)), 6); return [s, e];
    };
    async function load() { const [a, b] = range(); events = (await api(`/api/agenda?from=${iso(a)}&to=${iso(b)}`)).items; draw(); }
    const title = () => mode === 'month' ? cursor.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) : mode === 'week' ? 'Semaine du ' + monday(cursor).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }) : cursor.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const move = n => { if (mode === 'month') cursor = new Date(cursor.getFullYear(), cursor.getMonth() + n, 1); else cursor = addDays(cursor, n * (mode === 'week' ? 7 : 1)); load(); };
    function evBtn(e) { return h('button', { class: 'ev ' + e.color, title: e.title, onclick: ev => { ev.stopPropagation(); showEvent(e); } }, (e.time ? e.time + ' ' : '') + e.title); }
    function draw() {
      const head = h('div', { class: 'cal-head' },
        h('div', { style: 'display:flex;gap:8px;align-items:center' }, h('button', { class: 'sq', 'aria-label': 'Précédent', onclick: () => move(-1) }, '<'), h('button', { class: 'sq', 'aria-label': 'Suivant', onclick: () => move(1) }, '>'),
          h('button', { class: 'btn small', style: 'height:36px;padding:0 14px;background:var(--bg);color:var(--muted);border-color:var(--line)', onclick: () => { cursor = new Date(today); load(); } }, 'Aujourd\'hui')),
        h('h2', {}, title()),
        h('div', { class: 'seg' }, [['month', 'Mois'], ['week', 'Semaine'], ['day', 'Jour']].map(([k, l]) => h('button', { class: mode === k ? 'on' : '', onclick: () => { mode = k; load(); } }, l))));
      let body;
      if (mode === 'day') {
        const list = events.filter(e => e.date === iso(cursor));
        body = h('div', {}, list.length ? list.map(e => h('div', { class: 'dayline' }, h('span', { class: 'dot ' + e.color }), h('span', { style: 'min-width:56px;color:var(--muted);font-size:14px' }, e.time || 'Journée'), h('span', { style: 'flex:1;font-size:16px' }, e.title), h('button', { class: 'link', onclick: () => showEvent(e) }, 'Détails'))) : h('p', { class: 'muted', style: 'padding:24px 20px' }, 'Aucun rappel ce jour.'),
          h('div', { style: 'padding:16px 20px' }, h('button', { class: 'btn small', onclick: () => showForm(iso(cursor)) }, 'Ajouter un rappel ce jour')));
      } else {
        const [a] = range(); const weeks = mode === 'month' ? Math.round((range()[1] - a) / 86400000 + 1) / 7 : 1; const rows = [];
        for (let w = 0; w < weeks; w++) {
          const cells = [];
          for (let i = 0; i < 7; i++) {
            const day = addDays(a, w * 7 + i); const k = iso(day); const out = mode === 'month' && day.getMonth() !== cursor.getMonth();
            cells.push(h('div', { class: 'cal-cell' + (out ? ' out' : '') + (k === iso(today) ? ' today' : ''), onclick: () => showForm(k) }, h('span', { class: 'n' }, day.getDate()), events.filter(e => e.date === k).map(evBtn)));
          }
          rows.push(h('div', { class: 'cal-row' }, cells));
        }
        body = h('div', { class: 'cal-scroll' }, h('div', { class: 'cal' }, h('div', { class: 'cal-row' }, ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(n => h('div', { class: 'cal-dn' }, n))), rows));
      }
      cal.replaceChildren(head, body);
    }
    function showForm(date) {
      const t = h('input', { class: 'input sm', placeholder: 'Intitulé du rappel', 'aria-label': 'Intitulé' }); const dt = h('input', { class: 'input sm', type: 'date', value: date, 'aria-label': 'Date' }); const tm = h('input', { class: 'input sm', type: 'time', 'aria-label': 'Heure' });
      const col = h('select', { class: 'input sm', 'aria-label': 'Couleur' }, COLORS.map(([k, l]) => h('option', { value: k }, l))); const err = h('p', { class: 'err' });
      const save = async () => { err.textContent = ''; try { await api('/api/agenda', { json: { title: t.value, date: dt.value, time: tm.value, color: col.value } }); panel.replaceChildren(); load(); } catch (e) { err.textContent = e.message; } };
      t.addEventListener('keydown', e => { if (e.key === 'Enter') save(); });
      panel.replaceChildren(h('section', { class: 'card', style: 'gap:12px' }, h('h2', { style: 'font-size:18px;font-weight:600' }, 'Nouveau rappel'), t, h('div', { style: 'display:flex;flex-wrap:wrap;gap:10px' }, dt, tm, col), err,
        h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: save }, 'Enregistrer'), h('button', { class: 'btn', onclick: () => panel.replaceChildren() }, 'Annuler'))));
      t.focus(); panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    function showEvent(e) {
      panel.replaceChildren(h('section', { class: 'card', style: 'gap:10px' }, h('h2', { style: 'font-size:18px;font-weight:600' }, e.title), h('p', { class: 'muted' }, parseIso(e.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) + (e.time ? ' à ' + e.time : '')),
        h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: async () => { await api('/api/agenda/' + e.id, { method: 'DELETE' }); panel.replaceChildren(); load(); } }, 'Supprimer'), h('button', { class: 'btn', onclick: () => panel.replaceChildren() }, 'Fermer'))));
      panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    shell('agenda', [
      h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px' },
        h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Agenda et rappels'), h('p', { class: 'sub' }, 'Les rappels du jour s\'affichent sur l\'accueil.')),
        h('button', { class: 'btn primary', onclick: () => showForm(iso(today)) }, 'Ajouter un rappel')),
      cal, panel, h('p', { class: 'muted', style: 'font-size:13px' }, 'Cliquez sur un jour pour ajouter un rappel. Les rappels sont visibles ici et sur l\'accueil, sans notification sur le téléphone.')
    ], 'w-xl');
    await load();
  }

  // ---------- veille ----------
  async function viewVeille() {
    const v = await api('/api/veille');
    const link = (href, text, meta) => h('div', { style: 'padding:10px 0;border-top:1px solid var(--line-soft);display:flex;flex-direction:column;gap:2px' }, h('a', { href, target: '_blank', rel: 'noopener noreferrer', style: 'font-size:16px;font-weight:600;text-decoration:none' }, text), meta ? h('span', { class: 'muted', style: 'font-size:13px' }, meta) : null);
    const dateFr = iso => iso ? new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : '';
    shell('veille', [
      h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h1', { class: 'h1' }, 'Veille de la semaine'), h('p', { class: 'sub' }, 'Des liens à consulter : articles récents, sites à suivre et salons de l\'année. Aucun résumé, juste les sources.')),
      h('div', { class: 'row2' },
        h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Articles de la semaine'),
          v.articles.length ? v.articles.slice(0, 25).map(a => link(a.url, a.title, a.source + (a.date ? ' - ' + dateFr(a.date) : ''))) : h('p', { class: 'muted' }, 'Aucun article récupéré pour le moment. Les sites ci-contre restent consultables.'),
          v.ko && v.ko.length ? h('p', { class: 'muted', style: 'font-size:12px;margin-top:8px' }, 'Flux injoignables : ' + v.ko.join(', ') + '.') : null),
        h('div', { style: 'display:flex;flex-direction:column;gap:20px' },
          h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Salons'), v.salons.map(s => link(s.url, s.name, [s.dates, s.place].filter(Boolean).join(' - ')))),
          h('section', { class: 'card tight' }, h('h2', { class: 'card-title' }, 'Sites suivis'), v.sites.map(s => link(s.url, s.name, s.note)))))
    ]);
  }

  // ---------- routeur ----------
  async function route() {
    if (!state.me) return;
    const parts = (location.hash.replace(/^#/, '') || '/').split('/').filter(Boolean);
    try {
      if (!parts.length) return await viewHome();
      const [a, b] = parts;
      if (a === 'consulter') return await viewConsulter(/^MP-\d+$/.test(b || '') ? b : null);
      if (a === 'ajout') return await viewAjout();
      if (a === 'fiche' && /^MP-\d+$/.test(b || '')) return await viewFiche(b);
      if (a === 'comparaison') return await viewComparaison();
      if (a === 'favoris') return await viewFavoris();
      if (a === 'notes') return await viewNotes();
      if (a === 'agenda') return await viewAgenda();
      if (a === 'veille') return await viewVeille();
      location.hash = '#/';
    } catch (e) { if (e.message !== 'Connexion requise') shell('', [h('a', { href: '#/' }, 'Retour à l\'accueil'), h('p', { class: 'err' }, e.message)]); }
  }
  async function boot() { try { state.me = await api('/api/me'); } catch { renderLogin(); return; } route(); }
  window.addEventListener('hashchange', route);
  boot();
})();
