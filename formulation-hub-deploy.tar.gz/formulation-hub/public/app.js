'use strict';
(() => {
  const SPRITE = {"logo": ["0 0 256 256", "<rect width=\"256\" height=\"256\" rx=\"58\" fill=\"#0E7A6E\"></rect><g transform=\"translate(0 -6)\"><path d=\"M100 52h56\" fill=\"none\" stroke=\"#fff\" stroke-width=\"14\" stroke-linecap=\"round\"></path><path d=\"M110 56v52L72 186a26 26 0 0 0 23 38h66a26 26 0 0 0 23-38l-38-78V56\" fill=\"none\" stroke=\"#fff\" stroke-width=\"14\" stroke-linejoin=\"round\"></path><path d=\"M83 163q45 8 90 0l11 23a26 26 0 0 1-23 38H95a26 26 0 0 1-23-38z\" fill=\"#fff\"></path></g>"], "chev-d": ["0 0 24 24", "<path d=\"m6 9 6 6 6-6\"></path>"], "chev-r": ["0 0 24 24", "<path d=\"m9 6 6 6-6 6\"></path>"], "star": ["0 0 24 24", "<path d=\"m12 3.8 2.5 5.1 5.6.8-4 4 .9 5.6-5-2.7-5 2.7.9-5.6-4-4 5.6-.8z\"></path>"], "note": ["0 0 24 24", "<rect x=\"5\" y=\"3.5\" width=\"14\" height=\"17\" rx=\"2.5\"></rect><path d=\"M8.5 8.5h7M8.5 12h7M8.5 15.5h4\"></path>"], "cal": ["0 0 24 24", "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"15.5\" rx=\"2.5\"></rect><path d=\"M3.5 9.5h17M8 3v4M16 3v4\"></path>"], "logout": ["0 0 24 24", "<path d=\"M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4\"></path><path d=\"M9 8l-4 4 4 4M5 12h10\"></path>"], "search": ["0 0 24 24", "<circle cx=\"11\" cy=\"11\" r=\"6.5\"></circle><path d=\"m20 20-4.4-4.4\"></path>"], "plus": ["0 0 24 24", "<path d=\"M12 5v14M5 12h14\"></path>"], "news": ["0 0 24 24", "<rect x=\"3.5\" y=\"4.5\" width=\"14\" height=\"15\" rx=\"2\"></rect><path d=\"M17.5 8.5h3v9a2 2 0 0 1-2 2\"></path><path d=\"M7 8.5h7M7 12h7M7 15.5h4\"></path>"], "compare": ["0 0 24 24", "<rect x=\"3.5\" y=\"4.5\" width=\"7\" height=\"15\" rx=\"2\"></rect><rect x=\"13.5\" y=\"4.5\" width=\"7\" height=\"15\" rx=\"2\"></rect>"], "lines": ["0 0 24 24", "<path d=\"M5 7h14M5 12h14M5 17h9\"></path>"], "chev-l": ["0 0 24 24", "<path d=\"m15 6-6 6 6 6\"></path>"], "clock": ["0 0 24 24", "<circle cx=\"12\" cy=\"12\" r=\"8.5\"></circle><path d=\"M12 7.5V12l3 2\"></path>"], "x": ["0 0 24 24", "<path d=\"M7 7l10 10M17 7 7 17\"></path>"], "trash": ["0 0 24 24", "<path d=\"M4.5 7h15M10 4h4M6.5 7l.8 12.1A1.5 1.5 0 0 0 8.8 20.5h6.4a1.5 1.5 0 0 0 1.5-1.4L17.5 7\"></path><path d=\"M10 11v6M14 11v6\"></path>"], "pencil": ["0 0 24 24", "<path d=\"M15.5 5.5l3 3L8 19H5v-3z\"></path>"], "check": ["0 0 24 24", "<path d=\"m5 12.5 4.5 4.5L19 7\"></path>"], "download": ["0 0 24 24", "<path d=\"M12 4v11M7.5 10.5 12 15l4.5-4.5\"></path><path d=\"M5 19.5h14\"></path>"], "sliders": ["0 0 24 24", "<path d=\"M4 7h9M17 7h3M4 17h3M11 17h9\"></path><circle cx=\"15\" cy=\"7\" r=\"2\"></circle><circle cx=\"9\" cy=\"17\" r=\"2\"></circle>"], "up": ["0 0 24 24", "<path d=\"M12 15V4M7.5 8.5 12 4l4.5 4.5\"></path><path d=\"M4.5 14.5V18a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-3.5\"></path>"], "doc": ["0 0 24 24", "<path d=\"M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z\"></path><path d=\"M14 3.5V8h4.5\"></path>"], "img": ["0 0 24 24", "<rect x=\"3.5\" y=\"4.5\" width=\"17\" height=\"15\" rx=\"2.5\"></rect><circle cx=\"9\" cy=\"9.5\" r=\"1.8\"></circle><path d=\"m20.5 15.5-5-5-9 9\"></path>"], "alert": ["0 0 24 24", "<circle cx=\"12\" cy=\"12\" r=\"8.5\"></circle><path d=\"M12 8v4.8M12 16v.2\"></path>"], "lock": ["0 0 24 24", "<rect x=\"5\" y=\"10.5\" width=\"14\" height=\"10\" rx=\"2.5\"></rect><path d=\"M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5\"></path>"], "refresh": ["0 0 24 24", "<path d=\"M19.5 12a7.5 7.5 0 1 1-2.2-5.3\"></path><path d=\"M19.5 4.5v4h-4\"></path>"], "minus": ["0 0 24 24", "<path d=\"M7 12h10\"></path>"], "eye": ["0 0 24 24", "<path d=\"M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12z\"></path><circle cx=\"12\" cy=\"12\" r=\"3\"></circle>"], "shield": ["0 0 24 24", "<path d=\"M12 3.5 5 6.2v5.3c0 4.3 3 7.6 7 9 4-1.4 7-4.7 7-9V6.2z\"></path><path d=\"m9 12 2.2 2.2L15.5 10\"></path>"], "home": ["0 0 24 24", "<path d=\"M4 10.5 12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19z\"></path>"], "ext": ["0 0 24 24", "<path d=\"M14 4h6v6M20 4l-9 9\"></path><path d=\"M18 14v4.5A1.5 1.5 0 0 1 16.5 20h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10\"></path>"], "pin": ["0 0 24 24", "<path d=\"M12 20.5s6.5-5.6 6.5-10.5a6.5 6.5 0 0 0-13 0c0 4.9 6.5 10.5 6.5 10.5z\"></path><circle cx=\"12\" cy=\"10\" r=\"2.3\"></circle>"]};
  const root = document.getElementById('root');
  const state = { me: null, cmp: [], crit: null, diff: false };
  try { state.cmp = JSON.parse(localStorage.getItem('fh_cmp') || '[]'); } catch { state.cmp = []; }
  const saveCmp = () => { try { localStorage.setItem('fh_cmp', JSON.stringify(state.cmp)); } catch { /* stockage indisponible */ } document.querySelectorAll('[data-cmp]').forEach(e => { e.textContent = state.cmp.length; e.hidden = !state.cmp.length; }); };
  const MAX_CMP = 10; const MAX_DOCS = 10; const MAX_MB = 25;
  const NR = 'Non renseigné';

  // ---------- outils DOM (aucun innerHTML pour les donnees : tout passe par textContent) ----------
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (k === 'value') e.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'hidden') e[k] = !!v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) { if (kid === null || kid === undefined || kid === false) continue; e.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
    return e;
  }
  const NS = 'http://www.w3.org/2000/svg';
  function ico(id, cls, style) {
    const s = document.createElementNS(NS, 'svg'); s.setAttribute('class', 'ico' + (cls ? ' ' + cls : '')); s.setAttribute('aria-hidden', 'true'); if (style) s.setAttribute('style', style);
    const u = document.createElementNS(NS, 'use'); u.setAttribute('href', '#' + id); s.append(u); return s;
  }
  const S = id => ico(id, 'ico-s');
  function mountSprite() {
    if (document.getElementById('fh-sprite')) return;
    const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('id', 'fh-sprite'); svg.setAttribute('width', '0'); svg.setAttribute('height', '0'); svg.setAttribute('style', 'position:absolute'); svg.setAttribute('aria-hidden', 'true');
    for (const [id, [vb, inner]] of Object.entries(SPRITE)) {
      const doc = new DOMParser().parseFromString('<svg xmlns="' + NS + '">' + inner + '</svg>', 'image/svg+xml');
      const sym = document.createElementNS(NS, 'symbol'); sym.setAttribute('id', id); sym.setAttribute('viewBox', vb);
      for (const c of [...doc.documentElement.childNodes]) sym.append(document.importNode(c, true));
      svg.append(sym);
    }
    document.body.prepend(svg);
  }
  { const orig = Element.prototype.replaceChildren; Element.prototype.replaceChildren = function (...k) { return orig.apply(this, k.flat(Infinity).filter(x => x !== null && x !== undefined && x !== false)); }; }
  const $ = (s, r = document) => r.querySelector(s);
  const isEmpty = v => v === '' || v === null || v === undefined;
  const norm = t => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const capFirst = s => s.charAt(0).toUpperCase() + s.slice(1);
  const plural = (n, a, b) => n > 1 ? b : a;
  const ND = 'Pas de donnée';
  const nr = () => h('span', { class: 'nr' }, NR);

  // Telechargement d'un vrai PDF genere par le serveur
  async function downloadPDF(path, json, btn) {
    if (btn) { btn.disabled = true; btn.style.opacity = '.6'; }
    try {
      const r = await fetch(path, json === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(json) });
      if (!r.ok) { let j = {}; try { j = await r.json(); } catch { /* corps vide */ } throw new Error(j.error || 'Erreur ' + r.status); }
      const name = ((r.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/) || [])[1] || 'document.pdf';
      const url = URL.createObjectURL(await r.blob()); const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000); toast('PDF téléchargé');
    } catch (e) { toast('PDF impossible : ' + e.message); } finally { if (btn) { btn.disabled = false; btn.style.opacity = ''; } }
  }
  // Deconnexion complete : session, selection de comparaison, retour a l'accueil (pas de retour possible sur la page quittee)
  async function doLogout() {
    try { await fetch('/api/logout', { method: 'POST' }); } catch { /* hors ligne */ }
    state.me = null; state.cmp = []; state.crit = null; state.diff = false;
    try { localStorage.removeItem('fh_cmp'); sessionStorage.removeItem('fh_tab'); localStorage.removeItem('fh_keep'); } catch { /* ignore */ }
    history.replaceState(null, '', location.pathname + '#/'); renderLogin();
  }
  async function api(path, opts = {}) {
    const o = Object.assign({ headers: {} }, opts);
    if (o.json !== undefined) { o.method = o.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(o.json); delete o.json; }
    const r = await fetch(path, o);
    let j = {}; try { j = await r.json(); } catch { /* corps vide */ }
    if (r.status === 401 && path !== '/api/login') { renderLogin(); throw new Error('Connexion requise'); }
    if (!r.ok) throw new Error(j.error || 'Erreur ' + r.status);
    return j;
  }
  function toast(t) { document.querySelectorAll('.toast-host').forEach(e => e.remove()); const e = h('div', { class: 'toast-host', role: 'status' }, h('div', { class: 'toast' }, S('check'), t)); document.body.append(e); setTimeout(() => e.remove(), 1800); }
  // menus deroulants : fermeture au clic ailleurs
  document.addEventListener('click', e => {
    document.querySelectorAll('details.menu[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); });
    document.querySelectorAll('.dd-open').forEach(d => { if (!d.contains(e.target)) d.remove(); });
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') document.querySelectorAll('.dd-open').forEach(d => d.remove()); });
  window.addEventListener('beforeprint', () => document.querySelectorAll('details.sec').forEach(d => { d.dataset.wasOpen = d.open ? '1' : ''; d.open = true; }));
  window.addEventListener('afterprint', () => document.querySelectorAll('details.sec').forEach(d => { d.open = d.dataset.wasOpen === '1'; }));

  // liste deroulante legere : renvoie un conteneur .dd-open place sous le declencheur
  function dropdown(anchor, items, { selected, onPick, width }) {
    document.querySelectorAll('.dd-open').forEach(d => d.remove());
    const box = h('div', { class: 'dd-open menu-l', role: 'listbox', style: `position:absolute;z-index:50;min-width:${width || 240}px` },
      items.map(o => h('div', { class: 'mi', role: 'option', 'aria-selected': o === selected ? 'true' : 'false', tabindex: '-1', onclick: ev => { ev.stopPropagation(); box.remove(); onPick(o); } }, o, o === selected ? ico('check', 'ico-s', 'stroke-width:2.4;margin-left:auto') : null)));
    const wrap = anchor.parentElement; wrap.style.position = 'relative'; box.style.top = (anchor.offsetTop + anchor.offsetHeight + 6) + 'px'; box.style.left = anchor.offsetLeft + 'px';
    wrap.append(box); const on = box.querySelector('[aria-selected="true"]'); if (on) on.scrollIntoView({ block: 'nearest' });
    return box;
  }

  // ---------- coque de page ----------
  function shell(active, content, opt = {}) {
    document.title = 'Formulation Hub';
    const spaceOn = ['fiches', 'notes', 'agenda'].includes(active);
    const cur = k => active === k ? 'page' : null;
    const tab = (href, id, label, key, badge) => h('a', { class: 'tab', href, 'aria-current': cur(key) }, ico(id), label, badge);
    const cmpBadge = cls => h('span', { class: cls, 'data-cmp': '1', hidden: !state.cmp.length }, state.cmp.length);
    const initial = state.me.name.charAt(0).toUpperCase();
    const logout = doLogout;
    root.replaceChildren(h('div', { class: 'app' },
      h('header', { class: 'hdr noprint' }, h('div', { class: 'hdr-in' },
        h('a', { class: 'brand', href: '#/' }, ico('logo', 'brand-mark', null), 'Formulation Hub'),
        h('nav', { class: 'nav', 'aria-label': 'Navigation principale' },
          h('details', { class: 'menu' }, h('summary', { class: 'nav-link', 'aria-current': spaceOn ? 'page' : null }, 'Mon espace', S('chev-d')),
            h('div', { class: 'pop' }, h('a', { href: '#/fiches' }, ico('doc'), 'Fiches existantes'), h('a', { href: '#/notes' }, ico('note'), 'Bloc-notes'), h('a', { href: '#/agenda' }, ico('cal'), 'Agenda et rappels'))),
          h('a', { class: 'nav-link', href: '#/consulter', 'aria-current': cur('consulter') }, 'Consulter une fiche'),
          h('a', { class: 'nav-link', href: '#/ajout', 'aria-current': cur('ajout') }, 'Ajouter une MP'),
          h('a', { class: 'nav-link', href: '#/veille', 'aria-current': cur('veille') }, 'Veille'),
          h('a', { class: 'nav-link', href: '#/comparaison', 'aria-current': cur('comparaison') }, 'Comparaison', cmpBadge('count'))),
        h('details', { class: 'menu' }, h('summary', { class: 'user' }, h('span', { class: 'avatar' }, initial), state.me.name),
          h('div', { class: 'pop pop-r' }, h('button', { type: 'button', onclick: logout }, ico('logout'), 'Déconnexion'))))),
      h('header', { class: 'mhdr noprint' }, h('div', { class: 'mhdr-in' }, h('a', { class: 'brand', href: '#/' }, ico('logo', 'brand-mark', null), 'Formulation Hub'),
        h('a', { class: 'av-btn', href: '#/espace', 'aria-label': 'Mon espace : fiches existantes, bloc-notes, agenda, déconnexion' }, h('span', { class: 'avatar' }, initial)))),
      h('main', { class: 'wrap' + (opt.narrow ? ' wrap-n' : ''), style: `${opt.max ? 'max-width:' + opt.max + 'px;' : ''}padding-top:${opt.top || 56}px;padding-bottom:72px;display:flex;flex-direction:column;gap:${opt.gap || 24}px` }, content),
      h('footer', { class: 'foot noprint' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.' + (state.me.mock ? ' Mode démonstration.' : '')),
      h('nav', { class: 'tabbar noprint', 'aria-label': 'Navigation principale' },
        tab('#/', 'home', 'Accueil', 'home'), tab('#/consulter', 'search', 'Consulter', 'consulter'), tab('#/ajout', 'plus', 'Ajouter', 'ajout'), tab('#/veille', 'news', 'Veille', 'veille'), tab('#/comparaison', 'compare', 'Comparaison', 'comparaison', cmpBadge('tab-n')))));
    window.scrollTo(0, 0);
  }

  // ---------- connexion ----------
  function renderLogin() {
    let saved = ''; try { saved = localStorage.getItem('fh_name') || ''; } catch { /* stockage indisponible */ }
    const name = h('input', { class: 'input', id: 'prenom', type: 'text', autocomplete: 'username', value: saved });
    const pw = h('input', { class: 'input', id: 'mdp', type: 'password', autocomplete: 'current-password', style: 'padding-right:52px' });
    const msg = h('p', { class: 'err', role: 'alert' });
    const keepIn = h('input', { type: 'checkbox', id: 'garder', style: 'position:absolute;opacity:0;width:1px;height:1px' });
    const box = h('span', { class: 'box', 'aria-hidden': 'true' }, ico('check', 'ico-s', 'stroke-width:2.4'));
    keepIn.addEventListener('change', () => box.classList.toggle('on', keepIn.checked));
    const eye = h('button', { type: 'button', class: 'btn btn-plain btn-icon', 'aria-label': 'Afficher le mot de passe', style: 'position:absolute;right:2px;top:2px;color:var(--text-2)', onclick: () => { const show = pw.type === 'password'; pw.type = show ? 'text' : 'password'; eye.setAttribute('aria-label', show ? 'Masquer le mot de passe' : 'Afficher le mot de passe'); } }, ico('eye'));
    const btn = h('button', { type: 'submit', class: 'btn btn-primary btn-lg btn-block' }, 'Se connecter');
    const go = async ev => {
      ev.preventDefault(); msg.textContent = ''; btn.disabled = true; btn.replaceChildren(h('span', { class: 'spin' }), 'Connexion...');
      try { const r = await api('/api/login', { json: { name: name.value, password: pw.value, remember: keepIn.checked } }); try { localStorage.setItem('fh_name', r.name); } catch { /* ignore */ } pw.value = ''; try { sessionStorage.setItem('fh_tab', '1'); if (keepIn.checked) localStorage.setItem('fh_keep', '1'); else localStorage.removeItem('fh_keep'); } catch { /* ignore */ } history.replaceState(null, '', location.pathname + '#/'); await boot(); }
      catch (e) { msg.textContent = e.message; pw.classList.add('is-error'); btn.disabled = false; btn.replaceChildren('Se connecter'); }
    };
    root.replaceChildren(h('div', { class: 'app', style: 'min-height:100vh' },
      h('main', { style: 'display:flex;align-items:center;justify-content:center;padding:72px 24px 40px' },
        h('div', { style: 'width:100%;max-width:420px;display:flex;flex-direction:column;align-items:center;gap:32px' },
          h('div', { style: 'display:flex;flex-direction:column;align-items:center;gap:18px;text-align:center' }, (() => { const s = ico('logo', '', null); s.setAttribute('width', 72); s.setAttribute('height', 72); s.setAttribute('viewBox', '0 0 256 256'); s.removeAttribute('class'); s.style.cssText = 'width:72px;height:72px'; return s; })(), h('h1', { class: 't-large' }, 'Formulation Hub')),
          h('form', { class: 'card pad-l', style: 'width:100%;display:flex;flex-direction:column;gap:22px', onsubmit: go },
            h('div', { class: 'field' }, h('label', { class: 'label', for: 'prenom' }, 'Prénom'), name),
            h('div', { class: 'field' }, h('label', { class: 'label', for: 'mdp' }, 'Mot de passe'), h('div', { style: 'position:relative' }, pw, eye)),
            h('label', { class: 'check' }, keepIn, box, 'Rester connectée sur cet appareil'),
            msg, btn))),
      h('footer', { class: 'foot' }, '© 2026 Thierry Ravelojaona. Tous droits réservés.')));
    (saved ? pw : name).focus();
  }

  // ---------- accueil ----------
  const ago = iso => {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 2) return 'À l\'instant'; if (m < 60) return 'Il y a ' + m + ' min'; const hr = Math.round(m / 60);
    if (hr < 24) return 'Il y a ' + hr + ' h'; const d = Math.round(hr / 24); return d === 1 ? 'Hier' : 'Il y a ' + d + ' j';
  };
  const COLOR_VAR = { teal: 'vert', blue: 'bleu', indigo: 'indigo', mauve: 'mauve', pink: 'rose', red: 'rouge', amber: 'orange', yellow: 'jaune', brown: 'marron', gray: 'gris' };
  const cv = c => `--c:var(--c-${COLOR_VAR[c] || 'vert'})`;
  const todayLabel = () => capFirst(new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }));
  async function viewHome() {
    const [home, names] = await Promise.all([api('/api/home'), api('/api/mp-names')]);
    const catOf = Object.fromEntries(names.items.map(n => [n.id, n.cat || n.category || '']));
    const next = 'MP-' + String(Math.max(0, ...names.items.map(n => parseInt(n.id.slice(3), 10) || 0)) + 1).padStart(4, '0');
    const tile = (href, id, title, text, detail) => h('a', { class: 'card tile', href }, h('span', { class: 'tile-i' }, ico(id, 'ico-l')), h('span', { class: 't-title3', style: 'font-size:21px' }, title), h('span', { class: 't-callout muted' }, text), detail ? h('span', { class: 'tile-d' }, detail) : null);
    const n = state.cmp.length;
    shell('home', [
      h('div', { style: 'display:flex;flex-direction:column;gap:6px;margin-bottom:12px' }, h('h1', { class: 't-display' }, 'Bonjour ' + state.me.name), h('p', { class: 't-title3 muted', style: 'font-weight:500' }, todayLabel())),
      h('section', { class: 'card pad', 'aria-labelledby': 'ag' },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:6px' }, h('h2', { class: 't-title3', id: 'ag' }, 'Aujourd\'hui dans l\'agenda'), h('a', { class: 'btn btn-plain btn-sm edge', href: '#/agenda' }, 'Ouvrir l\'agenda')),
        home.agenda.length ? h('div', { class: 'list' }, home.agenda.map(e => h('a', { class: 'li', href: '#/agenda/' + e.id },
          h('span', { class: 'num w6', style: 'width:52px;color:var(--text-2)' }, e.time || 'Jour'), h('span', { class: 'dot', style: cv(e.color) }), h('span', { class: 'li-t', style: 'flex:1' }, e.title),
          e.note ? ico('lines', 'ico-s', 'color:var(--text-2)') : null, ico('chev-r', 'chev')))) : h('p', { class: 't-callout muted', style: 'padding:8px 0' }, 'Aucun rappel aujourd\'hui.')),
      h('section', { 'aria-label': 'Actions principales', class: 'tiles', style: 'display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px' },
        tile('#/consulter', 'search', 'Consulter une fiche', 'Recherchez une matière première et affichez sa fiche.', names.items.length + ' ' + plural(names.items.length, 'matière première', 'matières premières')),
        tile('#/ajout', 'plus', 'Ajouter une matière première', 'Créez une entrée, puis déposez ses documents.', 'Prochain identifiant : ' + next),
        tile('#/veille', 'news', 'Veille de la semaine', 'Articles, salons et sites suivis.', null),
        tile('#/comparaison', 'compare', 'Comparaison', 'Jusqu\'à ' + MAX_CMP + ' fiches côte à côte.', n ? n + ' ' + plural(n, 'fiche', 'fiches') + ' en cours' : 'Aucune fiche en cours')),
      h('div', { class: 'home2', style: 'display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);gap:20px;align-items:start' },
        h('section', { class: 'card pad', 'aria-labelledby': 'rec' }, h('h2', { class: 't-title3', id: 'rec', style: 'margin-bottom:6px' }, 'Dernières fiches consultées'),
          home.recents.length ? h('div', { class: 'list' }, home.recents.map(r => h('a', { class: 'li', href: '#/fiche/' + r.id },
            h('span', { style: 'flex:1;min-width:0;display:flex;flex-direction:column' }, h('span', { class: 'li-t' }, r.name), h('span', { class: 't-caption muted' }, r.id + (catOf[r.id] ? ', ' + catOf[r.id] : ''))), h('span', { class: 't-sub muted' }, ago(r.at)), ico('chev-r', 'chev')))) : h('p', { class: 't-callout muted', style: 'padding:8px 0' }, 'Aucune fiche consultée pour le moment.')),
        h('div', { style: 'display:flex;flex-direction:column;gap:20px' },
          h('section', { class: 'card pad', 'aria-labelledby': 'cmp', style: 'display:flex;flex-direction:column;gap:14px' },
            h('div', { style: 'display:flex;align-items:baseline;justify-content:space-between;gap:12px' }, h('h2', { class: 't-title3', id: 'cmp' }, 'Comparaison en cours'), h('span', { class: 't-sub muted num' }, n + ' ' + plural(n, 'fiche', 'fiches') + ' sur ' + MAX_CMP)),
            n ? h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px' }, state.cmp.map(c => h('span', { class: 'pill' }, c.name))) : h('p', { class: 't-callout muted' }, 'Ajoutez des fiches depuis leur page pour les comparer.'),
            h('a', { class: 'btn btn-tinted', href: '#/comparaison', style: 'align-self:flex-start;margin-top:4px' }, 'Ouvrir la comparaison')),
          h('section', { class: 'card pad', 'aria-labelledby': 'fav' },
            h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:6px' }, h('h2', { class: 't-title3', id: 'fav' }, 'Fiches existantes'), h('a', { class: 'btn btn-plain btn-sm edge', href: '#/fiches' }, 'Tout voir')),
            home.fiches.length ? h('div', { class: 'list' }, home.fiches.map(r => h('a', { class: 'li', href: '#/fiche/' + r.id }, ico('doc', 'ico-s', 'color:var(--accent)'), h('span', { class: 'li-t', style: 'flex:1' }, r.name), h('span', { class: 'id' }, r.id)))) : h('p', { class: 't-callout muted', style: 'padding:8px 0' }, 'Aucune fiche pour le moment. Elles apparaissent ici automatiquement après la lecture d\'un document.'))))
    ], { top: 64, gap: 28, max: 1120 });
  }

  // ---------- Mon espace (mobile) ----------
  async function viewEspace() {
    const [f, b, a] = await Promise.all([api('/api/fiches'), api('/api/bloc'), api('/api/home')]);
    const link = (href, id, label, extra) => h('a', { href }, h('span', { class: 'gi' }, ico(id)), h('span', { style: 'flex:1;font-weight:550' }, label), extra ? h('span', { class: 't-sub muted num' }, extra) : null, ico('chev-r', 'chev'));
    shell('espace', [
      h('h1', { class: 't-large' }, 'Mon espace'),
      h('div', { style: 'display:flex;align-items:center;gap:14px' }, h('span', { class: 'avatar', style: 'width:48px;height:48px;font-size:20px' }, state.me.name.charAt(0).toUpperCase()), h('span', { class: 'w6', style: 'font-size:17px' }, state.me.name)),
      h('nav', { class: 'grp', 'aria-label': 'Mon espace' }, link('#/fiches', 'doc', 'Fiches existantes', String(f.items.length)), link('#/notes', 'note', 'Bloc-notes', String(b.items.length)), link('#/agenda', 'cal', 'Agenda et rappels', a.agenda.length ? a.agenda.length + ' aujourd\'hui' : '')),
      h('div', { class: 'grp' }, h('a', { href: '#/', style: 'color:var(--danger)', onclick: e => { e.preventDefault(); doLogout(); } }, h('span', { class: 'gi', style: 'background:var(--danger-soft);color:var(--danger)' }, ico('logout')), h('span', { style: 'flex:1;font-weight:550' }, 'Déconnexion')))
    ], { narrow: true, top: 28 });
  }

  // ---------- consulter une fiche ----------
  const fmtSize = b => b >= 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(b / 1024)) + ' Ko';
  const isImg = f => /^image\/(jpeg|png|webp)$/.test(f.type) || /\.(jpe?g|png|webp)$/i.test(f.name);
  async function viewConsulter(preId) {
    let selected = null; let items = []; const ready = []; // { id, name, size, kind, state, error, pct }
    const msg = h('p', { class: 'err', role: 'alert' });
    const search = h('input', { class: 'input', id: 'q', type: 'search', placeholder: 'Nom commercial', autocomplete: 'off' });
    const listBox = h('div'); const selBox = h('div'); const docList = h('div'); const status = h('div');
    const step1 = h('span', { class: 'step-n', 'aria-hidden': 'true' }, '1'); const count = h('span', { class: 't-sub muted num', style: 'margin-left:auto' });
    const go = h('button', { type: 'button', class: 'btn btn-primary btn-lg', disabled: true, onclick: run }, 'Extraire et afficher la fiche');
    let tmr;
    async function load() {
      const q = search.value.trim();
      try { items = (await api('/api/mps?q=' + encodeURIComponent(q))).items; } catch (e) { msg.textContent = e.message; return; }
      drawList(q);
    }
    function drawList(q) {
      listBox.replaceChildren(items.length ? h('div', { class: 'list', style: 'max-height:300px;overflow-y:auto;margin-top:12px' }, items.slice(0, 50).map(m => { const on = selected && selected.id === m.id;
        return h('button', { type: 'button', class: 'li', style: 'width:100%;text-align:left;border:0;cursor:pointer;font:inherit;' + (on ? 'background:var(--accent-soft);box-shadow:inset 4px 0 0 var(--accent)' : 'background:none'), 'aria-pressed': String(!!on), onclick: () => choose(m) },
          on ? h('span', { style: 'display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;background:var(--accent);color:#fff;flex:none' }, ico('check', 'ico-s', 'stroke-width:2.6;color:#fff')) : null,
          h('span', { class: 'li-t', style: 'flex:1;font-weight:' + (on ? 700 : 500) }, m.name), m.fiche ? h('span', { style: 'display:flex;gap:6px;flex:none;width:250px' }, h('span', { class: 'pill' }, 'Fiche existante'), m.statut === 'Verifie' ? h('span', { class: 'badge badge-ok' }, 'Vérifiée') : h('span', { class: 'flag' }, S('alert'), 'À vérifier')) : h('span', { style: 'flex:none;width:250px' }), h('span', { class: 'id', style: 'flex:none;width:64px;text-align:right' }, m.id)); })) :
        h('p', { class: 't-callout muted', style: 'margin-top:12px' }, q ? 'Aucune matière première ne correspond. ' : '', h('a', { href: '#/ajout' }, 'Ajouter une MP')));
    }
    function choose(m) { selected = m; step1.className = 'step-n done'; step1.replaceChildren(ico('check', 'ico-s', 'stroke-width:2.4')); drawList(search.value.trim()); drawSel(); syncGo(); }
    function drawSel() {
      selBox.replaceChildren(selected ? h('div', { style: 'margin-top:16px;padding:16px 20px;border-radius:var(--r-md);background:var(--accent-soft);box-shadow:inset 0 0 0 1.5px var(--accent);display:flex;align-items:center;gap:16px;flex-wrap:wrap' },
        h('span', { style: 'display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;background:var(--accent);flex:none' }, ico('check', 'ico-s', 'stroke-width:2.6;color:#fff')),
        h('span', { style: 'flex:1;min-width:220px;display:flex;flex-direction:column;gap:2px' }, h('span', { class: 't-caption', style: 'color:var(--accent-text);font-weight:600' }, 'Matière première sélectionnée'), h('span', { class: 'w6', style: 'font-size:19px' }, selected.name), h('span', { class: 't-sub muted' }, h('span', { class: 'nw' }, selected.id))),
        h('a', { class: selected.fiche ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm', href: '#/fiche/' + selected.id }, ico('doc', 'ico-s'), selected.fiche ? 'Voir la fiche existante' : 'Voir la fiche (vide pour l\'instant)'),
        h('button', { type: 'button', class: 'btn btn-secondary btn-sm', onclick: () => { selected = null; step1.className = 'step-n'; step1.replaceChildren('1'); drawList(search.value.trim()); drawSel(); syncGo(); search.focus(); } }, 'Changer')) : null);
    }
    const syncGo = () => { go.disabled = !(selected && ready.some(f => f.state === 'ok')); count.textContent = ready.length ? ready.length + ' sur ' + MAX_DOCS : ''; };
    search.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(load, 250); });
    const file = h('input', { type: 'file', accept: 'application/pdf,image/jpeg,image/png,image/webp', multiple: true, style: 'display:none', onchange: e => { upload([...e.target.files]); e.target.value = ''; } });
    const drop = h('div', { class: 'drop', onclick: () => file.click() }, h('span', { class: 'drop-ico' }, ico('up', 'ico-l')), h('p', { class: 'w6', style: 'margin:4px 0 0;font-size:17px' }, 'Glissez vos documents ici'),
      h('p', { class: 't-sub muted' }, `PDF ou images JPG, PNG, WebP. Jusqu'à ${MAX_DOCS} documents de ${MAX_MB} Mo chacun.`), h('button', { type: 'button', class: 'btn btn-secondary', style: 'margin-top:6px' }, 'Choisir des fichiers'));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('is-over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('is-over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('is-over'); upload([...e.dataTransfer.files]); });
    function drawDocs() {
      docList.replaceChildren(ready.length ? h('div', { class: 'list', style: 'margin-top:12px', 'aria-label': 'Documents déposés' }, ready.map(f => h('div', { class: 'file' },
        h('span', { class: 'file-ico', style: f.state === 'err' ? 'color:var(--danger)' : null }, ico(f.kind === 'img' ? 'img' : 'doc')),
        h('span', { style: 'flex:1;min-width:0;display:flex;flex-direction:column;gap:2px' }, h('span', { class: 'w5', style: 'overflow-wrap:anywhere' }, f.name), f.state === 'err' ? h('span', { class: 't-caption', style: 'color:var(--danger)' }, f.error) : h('span', { class: 't-caption muted' }, (f.kind === 'img' ? 'Image' : 'PDF') + ', ' + fmtSize(f.size))),
        f.state === 'ok' ? h('span', { class: 'st st-ok' }, S('check'), 'Prêt') : f.state === 'err' ? h('span', { class: 'st st-err' }, S('alert'), 'Erreur') : h('span', { class: 'st st-run' }, 'Envoi...'),
        h('button', { type: 'button', class: 'btn btn-plain btn-sm', style: 'color:var(--text-2)', onclick: () => { ready.splice(ready.indexOf(f), 1); drawDocs(); syncGo(); } }, 'Retirer')))) : null);
    }
    async function upload(fl) {
      msg.textContent = '';
      const batch = [];
      for (const f of fl) {
        if (ready.length >= MAX_DOCS) { msg.textContent = `${MAX_DOCS} documents maximum.`; break; }
        const img = isImg(f); const pdf = /\.pdf$/i.test(f.name) || f.type === 'application/pdf';
        const it = { name: f.name, size: f.size, kind: img ? 'img' : 'pdf', state: 'up' };
        if (!img && !pdf) { it.state = 'err'; it.error = 'Format non pris en charge. Convertissez-le en PDF ou en image (JPG, PNG, WebP).'; ready.push(it); continue; }
        if (f.size > MAX_MB * 1024 * 1024) { it.state = 'err'; it.error = `Dépasse ${MAX_MB} Mo.`; ready.push(it); continue; }
        ready.push(it); batch.push([it, f]);
      }
      drawDocs(); syncGo(); // tous les documents apparaissent d'un coup, puis chacun passe a "Pret" des qu'il est envoye
      await Promise.all(batch.map(async ([it, f]) => {
        const ct = it.kind === 'img' ? (f.type || (/\.png$/i.test(f.name) ? 'image/png' : /\.webp$/i.test(f.name) ? 'image/webp' : 'image/jpeg')) : 'application/pdf';
        try { const r = await api('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f, headers: { 'Content-Type': ct } }); it.id = r.id; it.state = 'ok'; } catch (e) { it.state = 'err'; it.error = e.message; }
        drawDocs(); syncGo();
      }));
    }
    async function run() {
      msg.textContent = ''; go.disabled = true;
      const fill = h('i', { style: 'width:0%' }); const stepEl = h('p', { class: 't-sub muted' });
      status.replaceChildren(h('div', { style: 'margin-top:20px;display:flex;flex-direction:column;gap:10px' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Analyse en cours...'), h('div', { class: 'bar', role: 'progressbar' }, fill), stepEl,
        h('p', { class: 't-caption muted' }, 'Comptez environ une minute par document. Vous pouvez laisser cette page ouverte.')));
      const anim = { base: 0, max: 6, t0: Date.now(), shown: 0, last: -1 };
      const tick = setInterval(() => { const p = anim.base + (anim.max - anim.base) * (1 - Math.exp(-(Date.now() - anim.t0) / 25000)); anim.shown = Math.max(anim.shown, p); fill.style.width = anim.shown.toFixed(1) + '%'; }, 250);
      try {
        const { job } = await api('/api/extract', { json: { mp_id: selected.id, files: ready.filter(f => f.state === 'ok').map(f => ({ id: f.id })) } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500));
          const j = await api('/api/jobs/' + job);
          if (j.pct !== anim.last) { anim.last = j.pct; anim.base = Math.max(anim.shown, j.pct); anim.max = Math.max(j.pctMax || j.pct, anim.base); anim.t0 = Date.now(); }
          stepEl.textContent = j.step;
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') {
            const r = j.result; fill.style.width = '100%';
            if (!r.failed.length && !r.skipped.length) { location.hash = '#/fiche/' + selected.id; return; }
            status.replaceChildren(h('div', { style: 'margin-top:20px;display:flex;flex-direction:column;gap:8px' }, h('p', { class: 'w6', style: 'font-size:17px' }, `${r.docsRead} ${plural(r.docsRead, 'document analysé', 'documents analysés')}`),
              r.skipped.map(s => h('p', { class: 't-sub muted' }, `${s.name} : ${s.reason}.`)), r.failed.map(f => h('p', { class: 'err' }, `${f.name} : ${f.error}`)),
              h('a', { class: 'btn btn-primary', style: 'align-self:flex-start', href: '#/fiche/' + selected.id }, 'Voir la fiche')));
            ready.length = 0; drawDocs(); return;
          }
        }
      } catch (e) { status.replaceChildren(h('p', { class: 'err', style: 'margin-top:16px' }, e.message)); syncGo(); } finally { clearInterval(tick); }
    }
    shell('consulter', [
      h('h1', { class: 't-large', style: 'margin-bottom:8px' }, 'Consulter une fiche'),
      h('section', { class: 'card pad-l', 'aria-labelledby': 's1' }, h('div', { class: 'step-h' }, step1, h('h2', { class: 't-title3', id: 's1' }, 'Choisir la matière première')),
        h('div', { class: 'field' }, h('label', { class: 'label', for: 'q' }, 'Nom commercial'), h('div', { class: 'search search-lg' }, ico('search'), search)), listBox, selBox),
      h('section', { class: 'card pad-l', 'aria-labelledby': 's2' }, h('div', { class: 'step-h' }, h('span', { class: 'step-n', 'aria-hidden': 'true' }, '2'), h('h2', { class: 't-title3', id: 's2' }, 'Déposer les documents'), count),
        drop, file, docList, msg,
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-top:24px;padding-top:24px;border-top:1px solid var(--line)' },
          h('p', { class: 't-sub muted', style: 'display:flex;align-items:center;gap:8px' }, S('lock'), 'Les documents sont analysés puis supprimés.'), go), status)
    ], { narrow: true });
    if (preId) { try { const all = (await api('/api/mp-names')).items; const m = all.find(x => x.id === preId); if (m) { search.value = m.name; await load(); const hit = items.find(x => x.id === preId); if (hit) choose(hit); } } catch { /* ignore */ } } else load();
    search.focus();
  }

  // ---------- ajouter une MP ----------
  async function viewAjout() {
    const names = (await api('/api/mp-names')).items;
    const next = 'MP-' + String(Math.max(0, ...names.map(n => parseInt(n.id.slice(3), 10) || 0)) + 1).padStart(4, '0');
    const input = h('input', { class: 'input', id: 'nom', type: 'text', placeholder: 'Ex : Camellia oil', 'aria-describedby': 'nom-h', style: 'min-height:56px;font-size:17px' });
    const msg = h('p', { class: 'err', role: 'alert' }); const done = h('div');
    const add = async ev => {
      if (ev) ev.preventDefault(); msg.textContent = ''; input.classList.remove('is-error');
      try { const r = await api('/api/mps', { json: { name: input.value } });
        done.replaceChildren(h('section', { class: 'card pad-l', style: 'display:flex;flex-direction:column;gap:14px;background:var(--accent-soft)' }, h('p', { class: 'w6', style: 'display:flex;align-items:center;gap:8px;color:var(--accent-text)' }, S('check'), `Matière première ajoutée : ${r.name} (${r.id})`), h('a', { class: 'btn btn-primary', style: 'align-self:flex-start', href: '#/consulter/' + r.id }, 'Déposer ses documents')));
        input.value = ''; } catch (e) { msg.textContent = e.message; input.classList.add('is-error'); }
    };
    shell('ajout', [
      h('h1', { class: 't-large', style: 'margin-bottom:8px' }, 'Ajouter une matière première'),
      h('form', { class: 'card pad-l', style: 'display:flex;flex-direction:column;gap:24px', onsubmit: add },
        h('div', { class: 'field' }, h('label', { class: 'label', for: 'nom' }, 'Nom commercial'), input, h('p', { class: 'hint', id: 'nom-h' }, 'Tel qu\'il figure sur la fiche technique du fournisseur.'), msg),
        h('div', { class: 'inset', style: 'padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap' }, h('span', { style: 'display:flex;flex-direction:column;gap:2px' }, h('span', { class: 't-sub w5' }, 'Identifiant'), h('span', { class: 't-caption muted' }, 'Attribué automatiquement à l\'ajout')), h('span', { class: 'w6 num', style: 'font-size:22px;letter-spacing:-.01em' }, next)),
        h('div', { style: 'display:flex;justify-content:flex-end;gap:12px' }, h('a', { class: 'btn btn-plain btn-lg', href: '#/' }, 'Annuler'), h('button', { type: 'submit', class: 'btn btn-primary btn-lg' }, 'Ajouter à la base'))),
      done
    ], { max: 704 });
    input.focus();
  }

  // ---------- fiche ----------
  const joinRange = (lo, hi) => (isEmpty(lo) && isEmpty(hi)) ? '' : isEmpty(hi) ? String(lo) : isEmpty(lo) ? String(hi) : lo + ' - ' + hi;
  const numUnit = (v, unit) => h('span', { class: 'range' }, h('span', { class: 'num' }, v), unit ? h('span', { class: 'unit' }, unit) : null);
  // affichage d'une valeur (hors edition), partage avec la comparaison
  function valueNode(row, fields) {
    const v = fields[row.header];
    if (row.kind === 'range') {
      const lo = v; const hi = fields[row.header2];
      if (isEmpty(lo) && isEmpty(hi)) return nr();
      if (isEmpty(hi)) return numUnit(lo, row.unit);
      if (isEmpty(lo)) return [h('span', { class: 'muted' }, 'jusqu\'à'), numUnit(hi, row.unit)];
      return [numUnit(lo, row.unit), h('span', { class: 'muted' }, 'à'), numUnit(hi, row.unit)];
    }
    if (isEmpty(v)) return nr();
    if (v === ND) return h('span', { class: 'nd', title: 'Le document indique que cette donnée n\'est pas disponible' }, ND);
    if (row.kind === 'num') return numUnit(v, row.unit);
    return String(v);
  }
  // Bloc "ajouter des documents" d'une fiche : depot + lecture, la fiche se met a jour a la fin
  function docExtractor(mpId, onDone) {
    const ready = []; const msg = h('p', { class: 'err', role: 'alert' }); const docList = h('div'); const status = h('div');
    const count = h('span', { class: 't-sub muted num', style: 'margin-left:auto' });
    const go = h('button', { type: 'button', class: 'btn btn-primary', disabled: true, onclick: run }, 'Extraire les informations');
    const syncGo = () => { go.disabled = !ready.some(f => f.state === 'ok'); count.textContent = ready.length ? ready.length + ' sur ' + MAX_DOCS : ''; };
    const file = h('input', { type: 'file', accept: 'application/pdf,image/jpeg,image/png,image/webp', multiple: true, style: 'display:none', onchange: e => { upload([...e.target.files]); e.target.value = ''; } });
    const drop = h('div', { class: 'drop', onclick: () => file.click() }, h('span', { class: 'drop-ico' }, ico('up', 'ico-l')), h('p', { class: 'w6', style: 'margin:4px 0 0;font-size:17px' }, 'Glissez des documents ici'),
      h('p', { class: 't-sub muted' }, `PDF ou images JPG, PNG, WebP. Jusqu'à ${MAX_DOCS} documents de ${MAX_MB} Mo chacun.`), h('button', { type: 'button', class: 'btn btn-secondary', style: 'margin-top:6px' }, 'Choisir des fichiers'));
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('is-over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('is-over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('is-over'); upload([...e.dataTransfer.files]); });
    function drawDocs() {
      docList.replaceChildren(ready.length ? h('div', { class: 'list', style: 'margin-top:12px', 'aria-label': 'Documents déposés' }, ready.map(f => h('div', { class: 'file' },
        h('span', { class: 'file-ico', style: f.state === 'err' ? 'color:var(--danger)' : null }, ico(f.kind === 'img' ? 'img' : 'doc')),
        h('span', { style: 'flex:1;min-width:0;display:flex;flex-direction:column;gap:2px' }, h('span', { class: 'w5', style: 'overflow-wrap:anywhere' }, f.name), f.state === 'err' ? h('span', { class: 't-caption', style: 'color:var(--danger)' }, f.error) : null),
        f.state === 'ok' ? h('span', { class: 'st st-ok' }, S('check'), 'Prêt') : f.state === 'err' ? h('span', { class: 'st st-err' }, S('alert'), 'Erreur') : h('span', { class: 'st st-run' }, 'Envoi...'),
        h('button', { type: 'button', class: 'btn btn-plain btn-sm', style: 'color:var(--text-2)', onclick: () => { ready.splice(ready.indexOf(f), 1); drawDocs(); syncGo(); } }, 'Retirer')))) : null);
    }
    async function upload(fl) {
      msg.textContent = ''; const batch = [];
      for (const f of fl) {
        if (ready.length >= MAX_DOCS) { msg.textContent = `${MAX_DOCS} documents maximum.`; break; }
        const img = isImg(f); const pdf = /\.pdf$/i.test(f.name) || f.type === 'application/pdf';
        const it = { name: f.name, kind: img ? 'img' : 'pdf', state: 'up' };
        if (!img && !pdf) { it.state = 'err'; it.error = 'Format non pris en charge. Convertissez-le en PDF ou en image (JPG, PNG, WebP).'; ready.push(it); continue; }
        if (f.size > MAX_MB * 1024 * 1024) { it.state = 'err'; it.error = `Dépasse ${MAX_MB} Mo.`; ready.push(it); continue; }
        ready.push(it); batch.push([it, f]);
      }
      drawDocs(); syncGo();
      await Promise.all(batch.map(async ([it, f]) => {
        const ct = it.kind === 'img' ? (f.type || (/\.png$/i.test(f.name) ? 'image/png' : /\.webp$/i.test(f.name) ? 'image/webp' : 'image/jpeg')) : 'application/pdf';
        try { const r = await api('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f, headers: { 'Content-Type': ct } }); it.id = r.id; it.state = 'ok'; } catch (e) { it.state = 'err'; it.error = e.message; }
        drawDocs(); syncGo();
      }));
    }
    async function run() {
      msg.textContent = ''; go.disabled = true;
      const fill = h('i', { style: 'width:0%' }); const stepEl = h('p', { class: 't-sub muted' });
      status.replaceChildren(h('div', { style: 'margin-top:20px;display:flex;flex-direction:column;gap:10px' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Analyse en cours...'), h('div', { class: 'bar', role: 'progressbar' }, fill), stepEl,
        h('p', { class: 't-caption muted' }, 'Comptez environ une minute par document. Vous pouvez laisser cette page ouverte.')));
      const anim = { base: 0, max: 6, t0: Date.now(), shown: 0, last: -1 };
      const tick = setInterval(() => { const p = anim.base + (anim.max - anim.base) * (1 - Math.exp(-(Date.now() - anim.t0) / 25000)); anim.shown = Math.max(anim.shown, p); fill.style.width = anim.shown.toFixed(1) + '%'; }, 250);
      try {
        const { job } = await api('/api/extract', { json: { mp_id: mpId, files: ready.filter(f => f.state === 'ok').map(f => ({ id: f.id })) } });
        for (;;) {
          await new Promise(r => setTimeout(r, 1500));
          const j = await api('/api/jobs/' + job);
          if (j.pct !== anim.last) { anim.last = j.pct; anim.base = Math.max(anim.shown, j.pct); anim.max = Math.max(j.pctMax || j.pct, anim.base); anim.t0 = Date.now(); }
          stepEl.textContent = j.step;
          if (j.status === 'error') throw new Error(j.error);
          if (j.status === 'done') {
            const r = j.result; fill.style.width = '100%';
            status.replaceChildren(h('div', { style: 'margin-top:20px;display:flex;flex-direction:column;gap:8px' }, h('p', { class: 'w6', style: 'font-size:17px;display:flex;align-items:center;gap:8px' }, S('check'), `${r.docsRead} ${plural(r.docsRead, 'document analysé', 'documents analysés')} : la fiche est à jour`),
              r.skipped.map(x => h('p', { class: 't-sub muted' }, `${x.name} : ${x.reason}.`)), r.failed.map(x => h('p', { class: 'err' }, `${x.name} : ${x.error}`))));
            ready.length = 0; drawDocs(); syncGo(); await onDone(); return;
          }
        }
      } catch (e) { status.replaceChildren(h('p', { class: 'err', style: 'margin-top:16px' }, e.message)); syncGo(); } finally { clearInterval(tick); }
    }
    return h('section', { class: 'card pad noprint', 'aria-labelledby': 'addocs' }, h('div', { style: 'display:flex;align-items:center;gap:12px' }, h('h2', { class: 't-title3', id: 'addocs' }, 'Ajouter des documents'), count),
      h('p', { class: 't-callout muted', style: 'margin:4px 0 14px' }, 'Pour compléter ou vérifier cette fiche, maintenant ou plus tard. Les valeurs déjà présentes ne sont jamais écrasées : les différences apparaissent dans les points à vérifier.'),
      drop, file, docList, msg, h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-top:16px' }, h('p', { class: 't-sub muted', style: 'display:flex;align-items:center;gap:8px' }, S('lock'), 'Les documents sont analysés puis supprimés.'), go), status);
  }
  async function viewFiche(id) {
    const d = await api('/api/mp/' + id);
    api('/api/mp/' + id + '/open', { method: 'POST' }).catch(() => { });
    const ui = state.me.ui; const f = () => d.fields;
    const msg = h('p', { class: 'err noprint', role: 'alert' });
    const top = h('div', { class: 'actions noprint', 'aria-label': 'Actions sur la fiche', style: 'margin-top:10px' });
    const bottom = h('div', { class: 'actions noprint', 'aria-label': 'Actions sur la fiche', style: 'margin-top:12px;padding-top:24px;border-top:1px solid var(--line)' });
    const verifyBox = h('div'); const head = h('div', { style: 'display:flex;flex-direction:column;gap:14px' }); const groupsBox = h('div', { style: 'display:flex;flex-direction:column;gap:20px' }); const docsLu = h('div');
    const extractBox = docExtractor(id, async () => { const nd = await api('/api/mp/' + id); delete nd.notes; Object.assign(d, nd); drawAll(); toast('Fiche mise à jour'); });
    const isCmp = () => state.cmp.some(c => c.id === id);
    let chain = Promise.resolve(); // enregistrements en file : l'ecran suit tout de suite, le serveur ensuite
    function save(changes) {
      msg.textContent = '';
      const before = {}; for (const k of Object.keys(changes)) before[k] = d.fields[k];
      Object.assign(d.fields, changes); drawAll();
      chain = chain.then(async () => {
        try {
          const nd = await api('/api/mp/' + id, { method: 'PUT', json: { changes } });
          const changed = JSON.stringify([nd.sources, nd.toVerify]) !== JSON.stringify([d.sources, d.toVerify]);
          d.sources = nd.sources; d.toVerify = nd.toVerify; d.fields.Statut = nd.fields.Statut;
          if (changed) drawAll(); toast('Enregistré');
        } catch (e) { Object.assign(d.fields, before); msg.textContent = 'Non enregistré : ' + e.message; drawAll(); }
      });
      return chain;
    }
    function toggleFav() {
      d.fav = !d.fav; drawAll(); toast(d.fav ? 'Ajouté aux favoris' : 'Retiré des favoris');
      const want = d.fav;
      chain = chain.then(async () => { try { await api('/api/favs/' + id, { method: want ? 'PUT' : 'DELETE' }); } catch (e) { d.fav = !want; msg.textContent = 'Non enregistré : ' + e.message; drawAll(); } });
    }
    const unverify = () => save({ Statut: 'A verifier' });
    function markVerified() {
      const oldTv = d.toVerify; const oldSt = d.fields.Statut; d.fields.Statut = 'Verifie'; d.toVerify = []; drawAll(); toast('Marqué comme vérifié');
      chain = chain.then(async () => { try { await api('/api/mp/' + id + '/verify', { method: 'POST' }); } catch (e) { d.toVerify = oldTv; d.fields.Statut = oldSt; msg.textContent = 'Non enregistré : ' + e.message; drawAll(); } });
    }
    const srcOf = row => { for (const l of row.src) if (d.sources[l]) return d.sources[l]; return ''; };
    const rowFilled = row => row.kind === 'range' ? !(isEmpty(f()[row.header]) && isEmpty(f()[row.header2])) : !isEmpty(f()[row.header]) && f()[row.header] !== ND;
    const flagged = row => d.toVerify.some(t => t.field === row.header || t.field === row.label || (row.header2 && t.field === row.header2));
    const editText = row => {
      const val = f()[row.header];
      const v = row.kind === 'range' ? joinRange(f()[row.header], f()[row.header2]) : (isEmpty(val) ? '' : String(val));
      const kvv = h('span', { class: 'kv-v', tabindex: '0', role: 'button', 'aria-label': row.label + ' : modifier' });
      const show = () => { kvv.className = 'kv-v'; kvv.replaceChildren(valueNode(row, f()), srcFlag(row)); };
      function edit() {
        kvv.className = 'kv-v is-edit';
        const ta = h('textarea', { class: 'input', rows: 1, placeholder: NR, 'aria-label': row.label, 'aria-describedby': 'hint-' + row.header, style: 'min-height:44px;resize:none;overflow:hidden;flex:1 1 280px' }); ta.value = v;
        const fit = () => { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 'px'; };
        let done = false;
        ta.addEventListener('input', fit);
        ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ta.blur(); } if (e.key === 'Escape') { done = true; show(); } });
        ta.addEventListener('blur', () => {
          if (done) { done = false; return; } const nv = ta.value.trim(); if (nv === v) { show(); return; }
          if (row.kind === 'range') { const p = nv.split(/\s*[-;\/]\s*/); save({ [row.header]: (p[0] || '').trim(), [row.header2]: p[1] !== undefined ? p[1].trim() : '' }); } else save({ [row.header]: nv });
        });
        kvv.replaceChildren(ta, row.unit ? h('span', { class: 'unit' }, row.unit) : null, h('span', { class: 'hint', id: 'hint-' + row.header, style: 'flex-basis:100%' }, row.kind === 'range' ? 'Format : minimum - maximum. Entrée pour enregistrer, Échap pour annuler.' : 'Entrée pour enregistrer, Échap pour annuler.'));
        ta.focus(); fit(); ta.setSelectionRange(ta.value.length, ta.value.length);
      }
      kvv.addEventListener('click', e => { if (e.target.closest('.q,.tip')) return; if (!kvv.classList.contains('is-edit')) edit(); });
      kvv.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target === kvv) { e.preventDefault(); edit(); } });
      show(); return kvv;
    };
    function srcFlag(row) {
      const s = srcOf(row); const out = [];
      if (rowFilled(row) && flagged(row)) out.push(h('span', { class: 'flag' }, S('alert'), 'À vérifier'));
      if (rowFilled(row) && s) {
        const tip = h('div', { class: 'tip', role: 'tooltip', hidden: true, style: 'left:0;top:30px' }, h('b', {}, 'Source'), h('br'), s);
        const q = h('button', { type: 'button', class: 'q', 'aria-label': 'Source de la valeur', 'aria-expanded': 'false', onclick: e => { e.stopPropagation(); const open = tip.hidden; document.querySelectorAll('.tip').forEach(t => { t.hidden = true; }); tip.hidden = !open; q.setAttribute('aria-expanded', String(open)); } }, '?');
        q.addEventListener('mouseenter', () => { tip.hidden = false; }); q.addEventListener('mouseleave', () => { tip.hidden = true; });
        out.push(h('span', { style: 'position:relative;display:inline-flex' }, q, tip));
      }
      return out;
    }
    function controlFor(row) {
      const val = f()[row.header];
      if (row.kind === 'yn') {
        const set = o => save({ [row.header]: val === o ? '' : o });
        return h('span', { class: 'seg seg-yn', role: 'group', 'aria-label': row.label }, h('button', { type: 'button', class: 'yes', 'aria-pressed': String(val === 'Oui'), onclick: () => set('Oui') }, 'Oui'), h('button', { type: 'button', 'aria-pressed': String(val === 'Non'), onclick: () => set('Non') }, 'Non'));
      }
      const picker = (opts) => {
        const btn = h('button', { type: 'button', class: 'select', 'aria-haspopup': 'listbox', style: 'min-width:240px' + (isEmpty(val) ? ';color:var(--text-2)' : '') }, isEmpty(val) ? NR : val, ico('chev-d', 'ico-s', 'color:var(--text-2)'));
        btn.addEventListener('click', e => { e.stopPropagation(); dropdown(btn, [NR].concat(opts), { selected: isEmpty(val) ? NR : val, onPick: o => save({ [row.header]: o === NR ? '' : o }) }); });
        return h('span', { class: 'kv-v', style: 'cursor:default' }, btn, srcFlag(row));
      };
      if (row.kind === 'cat') return picker(ui.cats);
      if (row.kind === 'charge') return picker(ui.charges);
      if (row.kind === 'multi') {
        const cur = isEmpty(val) ? [] : String(val).split(/\s*,\s*/);
        const add = h('button', { type: 'button', class: 'pill pill-add' }, S('plus'), 'Ajouter une fonction');
        add.addEventListener('click', e => { e.stopPropagation(); dropdown(add, ui.foncs.filter(x => !cur.includes(x)), { onPick: o => save({ [row.header]: cur.concat([o]).join(', ') }), width: 280 }); });
        return h('span', { class: 'kv-v', style: 'cursor:default' }, cur.length ? null : nr(), cur.map(x => h('span', { class: 'pill pill-on' }, x, h('button', { type: 'button', class: 'pill-x', 'aria-label': 'Retirer ' + x, onclick: () => save({ [row.header]: cur.filter(y => y !== x).join(', ') }) }, S('x')))), add, srcFlag(row));
      }
      return editText(row);
    }
    const openGroups = {};
    function drawGroups() {
      groupsBox.querySelectorAll('details.sec').forEach(g => { openGroups[g.dataset.t] = g.open; });
      groupsBox.replaceChildren(...ui.groups.map((g, gi) => {
        const filled = g.rows.filter(rowFilled).length; const isApps = /^Applications/i.test(g.title); const isRegs = /^R[ée]glementation/i.test(g.title);
        const rows = g.rows.map((row, ri) => {
          const anchor = { id: 'row-' + gi + '-' + ri };
          if (isApps && row.kind === 'yn') return h('div', Object.assign({ class: 'app-i' }, anchor), h('span', { class: 'w5' }, row.label), controlFor(row));
          return h('div', Object.assign({ class: 'kv' }, anchor), h('span', { class: 'kv-k' }, row.label), controlFor(row));
        });
        const det = h('details', { class: 'sec', 'data-t': g.title }, h('summary', {}, h('h2', { class: 't-title3', style: 'flex:1' }, g.title), h('span', { class: 'sec-c' }, `${filled} sur ${g.rows.length} renseignés`), ico('chev-d', 'sec-chev')), h('div', { class: 'sec-b' + (isApps ? ' apps' : isRegs ? ' regs' : '') }, rows));
        det.open = openGroups[g.title] !== undefined ? openGroups[g.title] : gi === 0;
        return det;
      }));
    }
    function gotoRow(field) {
      for (let gi = 0; gi < ui.groups.length; gi++) for (let ri = 0; ri < ui.groups[gi].rows.length; ri++) {
        const r = ui.groups[gi].rows[ri];
        if (r.header === field || r.label === field || r.header2 === field) { const el = document.getElementById('row-' + gi + '-' + ri); if (!el) return; const det = el.closest('details'); if (det) det.open = true; el.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
      }
    }
    let delAsk = false;
    async function delFiche() {
      try { await api('/api/mp/' + id + '/fiche', { method: 'DELETE' }); } catch (e) { msg.textContent = e.message; delAsk = false; drawAll(); return; }
      state.cmp = state.cmp.filter(c => c.id !== id); saveCmp(); toast('Fiche supprimée'); location.hash = '#/fiches';
    }
    function actions() {
      const verified = d.fields.Statut === 'Verifie'; const inCmp = isCmp();
      return [
        h('button', { type: 'button', class: inCmp ? 'btn btn-tinted' : 'btn btn-secondary', 'aria-pressed': String(inCmp), onclick: () => { if (inCmp) { state.cmp = state.cmp.filter(c => c.id !== id); saveCmp(); drawAll(); toast('Retiré de la comparaison'); return; } if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches dans la comparaison.`; return; } state.cmp.push({ id, name: f()['Trade name'] }); saveCmp(); drawAll(); toast('Ajouté à la comparaison'); } }, S('compare'), inCmp ? 'Retirer de la comparaison' : 'Ajouter à la comparaison'),
        h('button', { type: 'button', class: verified ? 'btn btn-secondary' : 'btn btn-primary', 'aria-pressed': String(verified), onclick: verified ? unverify : markVerified }, S('shield'), verified ? 'Retirer le statut vérifié' : 'Marquer comme vérifié'),
        delAsk ? [h('button', { type: 'button', class: 'btn btn-danger', style: 'font-weight:700', onclick: delFiche }, S('trash'), 'Confirmer la suppression de la fiche'), h('button', { type: 'button', class: 'btn btn-plain', onclick: () => { delAsk = false; drawAll(); } }, 'Annuler')]
          : h('button', { type: 'button', class: 'btn btn-danger', onclick: () => { delAsk = true; drawAll(); } }, S('trash'), 'Supprimer la fiche'),
        h('button', { type: 'button', class: 'btn btn-secondary', onclick: e => downloadPDF('/api/mp/' + id + '/pdf', undefined, e.currentTarget) }, S('download'), 'Télécharger la fiche (PDF)')
      ];
    }
    function drawAll() {
      const verified = d.fields.Statut === 'Verifie';
      head.replaceChildren(h('div', { style: 'display:flex;align-items:center;gap:12px' }, h('span', { class: 'id', style: 'font-size:var(--t-sub)' }, id), verified ? h('span', { class: 'badge badge-ok' }, S('shield'), 'Vérifié') : h('span', { class: 'badge badge-warn' }, S('alert'), 'À vérifier')),
        h('h1', { class: 't-display' }, f()['Trade name'] || id),
        h('div', { style: 'display:flex;flex-direction:column;gap:2px' }, f().INCI ? h('p', { class: 't-title3', style: 'font-weight:500' }, f().INCI) : null, f().Supplier ? h('p', { class: 't-callout muted' }, f().Supplier) : null), top);
      top.replaceChildren(...actions()); bottom.replaceChildren(...actions());
      verifyBox.replaceChildren(d.toVerify.length ? h('section', { class: 'warnbox noprint', 'aria-labelledby': 'av', style: 'margin-top:12px' }, h('h2', { id: 'av', style: 'margin:0 0 8px;font-size:var(--t-body);font-weight:650;display:flex;align-items:center;gap:8px' }, ico('alert'), `${d.toVerify.length} ${plural(d.toVerify.length, 'point à vérifier', 'points à vérifier')}`),
        h('ul', { style: 'margin:0;padding-left:28px;display:flex;flex-direction:column;gap:4px;font-size:var(--t-callout)' }, d.toVerify.map(t => h('li', {}, h('a', { href: '#', style: 'color:inherit;text-decoration:underline;text-underline-offset:3px', onclick: e => { e.preventDefault(); gotoRow(t.field); } }, t.field), ' : ' + (t.reason || '') + (t.source_excerpt ? ' « ' + t.source_excerpt + ' »' : ''))))) : null);
      const names = [...new Set(Object.values(d.sources).flatMap(s => String(s).split(' ; ')).filter(s => s && !s.startsWith('Saisie manuelle') && !s.startsWith('DETA')))];
      docsLu.replaceChildren(h('h2', { class: 't-title3' }, 'Documents lus'), h('p', { class: 't-sub muted', style: 'margin:4px 0 8px' }, 'Analysés puis supprimés. Seules les données extraites sont gardées.'),
        names.length ? h('div', { class: 'list' }, names.map(n => h('div', { class: 'file' }, h('span', { class: 'file-ico' }, ico('doc')), h('span', { style: 'flex:1;min-width:0' }, h('span', { class: 'w5', style: 'overflow-wrap:anywhere' }, n))))) : h('p', { class: 't-callout muted' }, 'Aucun document analysé pour le moment.'));
      drawGroups();
    }
    // notes de la fiche
    const notes = d.notes;
    const ta = h('textarea', { class: 'input', id: 'nt', rows: 4, style: 'margin-top:12px', placeholder: 'Ajouter une note, une remarque, un contexte' }); ta.value = notes.text || '';
    let tmr; const noteState = h('span', { class: 't-caption muted', role: 'status' });
    ta.addEventListener('input', () => { clearTimeout(tmr); noteState.textContent = ''; tmr = setTimeout(async () => { try { await api('/api/notes/' + id, { method: 'PUT', json: { text: ta.value } }); noteState.textContent = 'Enregistré'; } catch (e) { noteState.textContent = e.message; } }, 800); });
    const imgs = h('div', { style: 'display:flex;flex-wrap:wrap;gap:10px;margin-top:14px' });
    const imgIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', multiple: true, style: 'display:none', onchange: async e => {
      const files = [...e.target.files]; e.target.value = ''; let n = 0;
      for (const fl of files) {
        noteState.textContent = `Envoi de l'image ${n + 1} sur ${files.length}...`;
        try { const r = await api('/api/notes/' + id + '/image', { method: 'POST', body: fl, headers: { 'Content-Type': fl.type } }); notes.images = r.images; drawImgs(); n++; } catch (er) { noteState.textContent = fl.name + ' : ' + er.message; return; }
      }
      noteState.textContent = n > 1 ? n + ' images ajoutées' : 'Image ajoutée';
    } });
    const drawImgs = () => imgs.replaceChildren(notes.images.map(n => h('div', { class: 'thumb', style: 'padding:0' },
      h('img', { src: '/api/note-img/' + n, alt: 'Image de la note', style: 'width:100%;height:100%;object-fit:cover;display:block' }),
      h('button', { type: 'button', class: 'btn btn-icon btn-secondary noprint', 'aria-label': 'Retirer l\'image', style: 'position:absolute;top:4px;right:4px;width:28px;height:28px;min-height:0;padding:0', onclick: async () => { const r = await api('/api/notes/' + id + '/image/' + n, { method: 'DELETE' }); notes.images = r.images; drawImgs(); } }, S('x')))),
      h('button', { type: 'button', class: 'thumb noprint', style: 'border:1.5px dashed var(--line-strong);background:var(--surface-2);flex-direction:column;align-items:center;justify-content:center;gap:4px;color:var(--text-2);cursor:pointer;font:inherit;font-size:13px', onclick: () => imgIn.click() }, ico('img'), 'Ajouter des images'));
    drawImgs(); drawAll();
    document.title = (f()['Trade name'] || 'Fiche') + ' - Formulation Hub';
    shell('fiche', [
      head, msg, verifyBox, groupsBox, extractBox,
      h('div', { class: 'fiche2', style: 'display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.2fr);gap:20px;align-items:start;margin-top:8px' },
        h('section', { class: 'card pad', 'aria-labelledby': 'docs' }, docsLu),
        h('section', { class: 'card pad', 'aria-labelledby': 'notes' }, h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px' }, h('h2', { class: 't-title3', id: 'notes' }, 'Notes'), noteState), h('label', { class: 'sr', for: 'nt', style: 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)' }, 'Notes sur la fiche'), ta, imgs, imgIn)),
      h('div', { class: 'only-print' }, notes.text ? h('p', { style: 'white-space:pre-wrap' }, notes.text) : null),
      bottom
    ], { max: 1024, gap: 20 });
  }

  // ---------- comparaison ----------
  async function viewComparaison() {
    const names = (await api('/api/mp-names')).items;
    const data = state.cmp.length ? (await api('/api/compare', { json: { ids: state.cmp.map(c => c.id) } })).items : [];
    const ui = state.me.ui; const msg = h('p', { class: 'err', role: 'alert' });
    const rkey = (g, r) => g.title + '|' + r.label;
    const allKeys = ui.groups.flatMap(g => g.rows.map(r => rkey(g, r)));
    const chosen = k => !state.crit || state.crit.has(k);
    const cellText = (r, c) => { const n = r.kind === 'range' ? joinRange(c.fields[r.header], c.fields[r.header2]) : c.fields[r.header]; return isEmpty(n) ? '' : String(n); };
    const differs = (r) => new Set(data.map(c => norm(cellText(r, c)))).size > 1;
    const visibleRows = g => g.rows.filter(r => chosen(rkey(g, r)) && (!state.diff || data.length < 2 || differs(r)));
    // ajout par recherche
    const add = h('input', { class: 'input', id: 'add', type: 'search', placeholder: 'Ajouter une fiche', autocomplete: 'off', role: 'combobox', 'aria-expanded': 'false', 'aria-controls': 'res' });
    const results = h('div', { class: 'lb', id: 'res', role: 'listbox', 'aria-label': 'Fiches trouvées', hidden: true }); let hi = -1; let shown = [];
    const pick = n => {
      if (state.cmp.some(c => c.id === n.id)) return;
      if (state.cmp.length >= MAX_CMP) { msg.textContent = `Maximum ${MAX_CMP} fiches.`; return; }
      state.cmp.push({ id: n.id, name: n.name }); saveCmp(); viewComparaison();
    };
    const mark = (name, q) => { const i = norm(name).indexOf(q); return i < 0 ? name : [name.slice(0, i), h('mark', {}, name.slice(i, i + q.length)), name.slice(i + q.length)]; };
    const drawResults = () => {
      const q = norm(add.value.trim()); msg.textContent = '';
      if (!q) { results.hidden = true; add.setAttribute('aria-expanded', 'false'); return; }
      shown = names.filter(n => norm(n.name).includes(q) || n.id.toLowerCase().includes(q)).slice(0, 8);
      const firstFree = shown.findIndex(n => !state.cmp.some(c => c.id === n.id)); hi = firstFree;
      results.replaceChildren(...(shown.length ? shown.map((n, i) => { const already = state.cmp.some(c => c.id === n.id);
        return h('div', { class: 'opt', role: 'option', 'aria-selected': String(i === hi), 'aria-disabled': already ? 'true' : null, onmousedown: e => { e.preventDefault(); if (!already) pick(n); } },
          h('span', { style: 'flex:1;' + (already ? 'color:var(--text-2)' : ''), class: already ? '' : 'w5' }, mark(n.name, q)), already ? h('span', { class: 't-caption muted nw' }, 'Déjà comparée') : h('span', { class: 'id' }, n.id)); }) : [h('div', { class: 'opt', 'aria-disabled': 'true', style: 'color:var(--text-2)' }, 'Aucune matière première trouvée')]));
      results.hidden = false; add.setAttribute('aria-expanded', 'true');
    };
    add.addEventListener('input', drawResults); add.addEventListener('focus', drawResults); add.addEventListener('blur', () => { results.hidden = true; add.setAttribute('aria-expanded', 'false'); });
    add.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!shown.length) return; hi = (hi + (e.key === 'ArrowDown' ? 1 : -1) + shown.length) % shown.length; [...results.children].forEach((c, i) => c.setAttribute('aria-selected', String(i === hi))); }
      else if (e.key === 'Enter') { e.preventDefault(); if (shown[hi]) pick(shown[hi]); }
      else if (e.key === 'Escape') { results.hidden = true; }
    });
    // tableau
    const tableBox = h('div'); const counter = h('span', { class: 't-sub muted num nw' });
    const cellNode = (r, c) => {
      const v = c.fields[r.header];
      if (r.kind === 'range') { const n = valueNode(r, c.fields); return h('td', { class: isEmpty(c.fields[r.header]) && isEmpty(c.fields[r.header2]) ? '' : 'nw num' }, h('span', { style: 'display:inline-flex;align-items:baseline;gap:6px;flex-wrap:wrap' }, n)); }
      if (isEmpty(v)) return h('td', {}, nr());
      if (v === 'Oui' || v === 'Approuvé') return h('td', {}, h('span', { class: 'yes' }, String(v)));
      if (v === 'Non' && (r.kind === 'yn')) return h('td', {}, h('span', { class: 'no' }, 'Non'));
      return h('td', { class: r.kind === 'num' ? 'nw num' : '' }, r.kind === 'num' ? valueNode(r, c.fields) : String(v));
    };
    function drawTable() {
      const shownCount = ui.groups.reduce((n, g) => n + visibleRows(g).length, 0);
      counter.textContent = `${shownCount} ${plural(shownCount, 'critère affiché', 'critères affichés')} sur ${allKeys.length}`;
      if (!data.length) { tableBox.replaceChildren(h('section', { class: 'card empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Aucune fiche dans la comparaison'), h('p', { class: 't-callout muted' }, 'Utilisez le champ ci-dessus ou le bouton « Ajouter à la comparaison » d\'une fiche.'), h('a', { class: 'btn btn-tinted', href: '#/consulter' }, 'Consulter une fiche'))); return; }
      const body = [];
      for (const g of ui.groups) {
        const rows = visibleRows(g); if (!rows.length) continue;
        body.push(h('tr', { class: 'grp' }, h('th', { class: 'crit', scope: 'rowgroup' }, g.title), h('td', { colspan: data.length })));
        for (const r of rows) body.push(h('tr', {}, h('th', { class: 'crit', scope: 'row' }, r.label), data.map(c => cellNode(r, c))));
      }
      tableBox.replaceChildren(h('div', { class: 'cmp', role: 'region', 'aria-label': 'Tableau de comparaison', tabindex: '0' }, h('table', {},
        h('thead', {}, h('tr', {}, h('th', { class: 'crit', scope: 'col' }, h('span', { class: 't-caption muted' }, 'Critères')), data.map(c => h('th', { scope: 'col' }, h('div', { class: 'colh' }, h('a', { href: '#/fiche/' + c.id }, c.name), h('span', { class: 'id' }, c.id)))))),
        h('tbody', {}, body.length ? body : h('tr', {}, h('td', { colspan: data.length + 1, class: 'muted', style: 'padding:24px' }, state.diff ? 'Aucune différence entre ces fiches pour les critères choisis.' : 'Aucun critère choisi.'))),
        h('tfoot', {}, h('tr', {}, h('td', { class: 'crit' }), data.map(c => h('td', {}, h('button', { type: 'button', class: 'btn btn-plain btn-sm noprint', style: 'color:var(--text-2);margin-left:-10px', onclick: () => { state.cmp = state.cmp.filter(x => x.id !== c.id); saveCmp(); viewComparaison(); } }, 'Retirer'))))))));
    }
    const diffToggle = () => h('button', { type: 'button', class: 'toggle', role: 'switch', 'aria-checked': String(state.diff), 'aria-labelledby': 'diff', onclick: e => { state.diff = !state.diff; e.currentTarget.setAttribute('aria-checked', String(state.diff)); drawTable(); } });
    // panneau de choix des criteres
    function openCriteria() {
      const overlay = h('div', { class: 'crit-overlay noprint' }); const close = () => { overlay.remove(); document.removeEventListener('keydown', onKey); }; const onKey = e => { if (e.key === 'Escape') close(); };
      document.addEventListener('keydown', onKey);
      const openG = new Set();
      function setCrit(fn) { const cur = state.crit ? new Set(state.crit) : new Set(allKeys); fn(cur); state.crit = cur.size === allKeys.length ? null : cur; drawTable(); drawPanel(); }
      function drawPanel() {
        const nShown = allKeys.filter(chosen).length;
        const groups = ui.groups.map(g => {
          const keys = g.rows.map(r => rkey(g, r)); const on = keys.filter(chosen).length; const st = on === keys.length ? 'on' : on === 0 ? '' : 'mixed';
          const det = h('details', { class: 'cg' }, h('summary', {}, h('span', { class: 'box' + (st ? ' ' + st : ''), role: 'checkbox', 'aria-checked': st === 'mixed' ? 'mixed' : String(st === 'on'), tabindex: '0', 'aria-label': 'Tout le groupe ' + g.title, onclick: e => { e.preventDefault(); e.stopPropagation(); setCrit(c => keys.forEach(k => on === keys.length ? c.delete(k) : c.add(k))); } }, st === 'on' ? ico('check', 'ico-s', 'stroke-width:2.4') : st === 'mixed' ? ico('minus', 'ico-s', 'stroke-width:2.4') : null),
            h('span', { class: 'w6', style: 'flex:1' }, g.title), h('span', { class: 't-caption muted' }, on === keys.length ? 'Tous' : on + ' ' + plural(on, 'choisi', 'choisis')), ico('chev-d', 'sec-chev')),
            g.rows.map(r => { const k = rkey(g, r); const sel = chosen(k); return h('label', { class: 'ci' }, h('input', { type: 'checkbox', checked: sel, style: 'position:absolute;opacity:0;width:1px;height:1px', onchange: () => setCrit(c => { if (c.has(k)) c.delete(k); else c.add(k); }) }), h('span', { class: 'box' + (sel ? ' on' : ''), 'aria-hidden': 'true' }, sel ? ico('check', 'ico-s', 'stroke-width:2.4') : null), r.label); }));
          det.open = openG.has(g.title); det.addEventListener('toggle', () => { if (det.open) openG.add(g.title); else openG.delete(g.title); });
          return det;
        });
        panel.replaceChildren(
          h('div', { class: 'sheet-h' }, h('h2', { class: 't-title3', id: 'ct' }, 'Choisir les critères'), h('button', { type: 'button', class: 'btn btn-secondary btn-icon', 'aria-label': 'Fermer', onclick: close }, ico('x'))),
          h('p', { class: 't-callout muted num' }, `${nShown} ${plural(nShown, 'critère affiché', 'critères affichés')} sur ${allKeys.length}`),
          h('div', { style: 'display:flex;gap:8px;margin:12px 0' }, h('button', { type: 'button', class: 'btn btn-secondary btn-sm', onclick: () => { state.crit = null; drawTable(); drawPanel(); } }, 'Tout afficher'), h('button', { type: 'button', class: 'btn btn-secondary btn-sm', onclick: () => { state.crit = new Set(); drawTable(); drawPanel(); } }, 'Tout masquer')),
          h('div', { style: 'display:flex;align-items:center;gap:12px;padding:10px 0 14px' }, diffToggle(), h('span', { id: 'diff', class: 't-callout' }, 'Afficher uniquement les différences')),
          h('div', { style: 'overflow:auto;flex:1' }, groups),
          h('div', { style: 'padding-top:14px' }, h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: close }, 'Terminé')));
      }
      const panel = h('aside', { class: 'side crit-panel', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'ct' });
      overlay.append(h('div', { class: 'crit-scrim', onclick: close }), panel); document.body.append(overlay); drawPanel();
    }
    const dl = () => h('button', { type: 'button', class: 'btn btn-primary', onclick: e => downloadPDF('/api/compare/pdf', { ids: state.cmp.map(c => c.id), crit: state.crit ? [...state.crit] : null, diff: !!state.diff }, e.currentTarget) }, S('download'), 'Télécharger la comparaison (PDF)');
    drawTable();
    shell('comparaison', [
      h('div', { style: 'display:flex;align-items:baseline;gap:16px;flex-wrap:wrap' }, h('h1', { class: 't-large' }, 'Comparaison'), h('span', { class: 't-title3 muted num', style: 'font-weight:500' }, `${state.cmp.length} ${plural(state.cmp.length, 'fiche', 'fiches')} sur ${MAX_CMP}`)),
      h('div', { class: 'noprint', style: 'display:flex;align-items:center;gap:12px;flex-wrap:wrap' },
        h('div', { style: 'position:relative;flex:0 1 420px;min-width:260px' }, h('label', { for: 'add', style: 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)' }, 'Ajouter une fiche'), h('div', { class: 'search' }, ico('search'), add), results),
        data.length ? dl() : null, h('span', { style: 'flex:1' }),
        data.length ? [h('button', { type: 'button', class: 'btn btn-secondary', 'aria-haspopup': 'dialog', onclick: openCriteria }, S('sliders'), 'Choisir les critères'), counter] : null),
      msg,
      data.length > 1 ? h('div', { class: 'noprint', style: 'display:flex;align-items:center;gap:12px' }, diffToggle(), h('span', { id: 'diff', class: 't-callout' }, 'Afficher uniquement les différences')) : null,
      tableBox,
      data.length ? h('div', { class: 'noprint', style: 'display:flex;justify-content:flex-end' }, dl()) : null
    ], { max: 1280, gap: 20 });
  }

  // ---------- fiches existantes ----------
  const fold = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  async function viewFiches() {
    let items = (await api('/api/fiches')).items; let confirmId = null;
    const search = h('input', { class: 'input', id: 'fq', type: 'search', placeholder: 'Rechercher une fiche (nom, INCI, fournisseur, identifiant)', autocomplete: 'off', style: 'padding-left:44px' });
    const count = h('span', { class: 't-title3 muted num', style: 'font-weight:500' }); const box = h('div'); const msg = h('p', { class: 'err', role: 'alert' });
    async function del(m) {
      try { await api('/api/mp/' + m.id + '/fiche', { method: 'DELETE' }); } catch (e) { msg.textContent = e.message; return; }
      items = items.filter(x => x.id !== m.id); confirmId = null; draw(); toast('Fiche supprimée');
    }
    function draw() {
      const n = items.length; const q = fold(search.value.trim());
      const shown = q ? items.filter(m => [m.name, m.inci, m.supplier, m.id, m.cat].some(v => fold(v).includes(q))) : items;
      count.textContent = !n ? '' : q ? `${shown.length} sur ${n} ${plural(n, 'fiche', 'fiches')}` : `${n} ${plural(n, 'fiche', 'fiches')}`;
      search.parentNode && (search.parentNode.hidden = !n);
      if (!n) { box.replaceChildren(h('section', { class: 'card empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Aucune fiche pour le moment'), h('p', { class: 't-callout muted' }, 'Déposez un document sur une matière première : sa fiche apparaîtra ici automatiquement.'), h('a', { class: 'btn btn-tinted', href: '#/consulter' }, 'Consulter une fiche'))); return; }
      if (!shown.length) { box.replaceChildren(h('section', { class: 'card empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Aucune fiche ne correspond'), h('p', { class: 't-callout muted' }, 'Essayez un autre nom, un INCI ou un identifiant.'))); return; }
      box.replaceChildren(h('section', { class: 'card', style: 'padding:8px 28px', 'aria-label': 'Fiches existantes' }, shown.map(m => {
        const asking = confirmId === m.id;
        return h('div', { class: 'fr' }, ico('doc', '', 'color:var(--accent)'), h('a', { href: '#/fiche/' + m.id }, m.name), h('span', { class: 'id' }, m.id), h('span', { class: 't-callout muted' }, m.cat || ''),
          h('span', { style: 'display:flex;align-items:center;gap:6px' }, m.statut === 'Verifie' ? h('span', { class: 'pill' }, 'Vérifiée') : null,
            asking ? [h('button', { type: 'button', class: 'btn btn-danger btn-sm', style: 'font-weight:700', onclick: () => del(m) }, 'Confirmer la suppression'), h('button', { type: 'button', class: 'btn btn-plain btn-sm', onclick: () => { confirmId = null; draw(); } }, 'Annuler')]
              : h('button', { type: 'button', class: 'btn btn-plain btn-sm btn-icon', 'aria-label': 'Supprimer la fiche ' + m.name, title: 'Supprimer la fiche', style: 'color:var(--text-2)', onclick: () => { confirmId = m.id; draw(); } }, ico('trash'))));
      })));
    }
    search.addEventListener('input', draw);
    const sw = h('div', { style: 'position:relative' }, h('span', { style: 'position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text-2);display:flex;pointer-events:none' }, ico('search')), search);
    shell('fiches', [
      h('div', { style: 'display:flex;align-items:baseline;gap:16px;flex-wrap:wrap' }, h('h1', { class: 't-large' }, 'Fiches existantes'), count),
      h('p', { class: 't-callout muted' }, 'Les matières premières dont la fiche a été remplie. Chaque fiche s\'ajoute ici automatiquement après la lecture d\'un document.'),
      sw, msg, box
    ], { narrow: true });
    draw(); if (items.length > 6 && !matchMedia('(max-width:760px)').matches) search.focus();
  }

  // ---------- bloc-notes ----------
  const hhmm = () => new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  async function viewNotes(selId) {
    let items = (await api('/api/bloc')).items; let cur = items.find(n => n.id === selId) || items[0] || null;
    const side = h('nav', { 'aria-label': 'Notes', class: 'notes-nav' }); const edit = h('article', { class: 'notes-edit' });
    let tmr;
    function drawSide() {
      side.replaceChildren(...(items.length ? items.map(n => h('a', { class: 'nl', href: '#', 'aria-current': cur && cur.id === n.id ? 'true' : null, onclick: e => { e.preventDefault(); cur = n; drawSide(); drawEdit(); } }, h('span', { class: 'w6' }, n.title || 'Sans titre'), h('span', { class: 't-caption muted' }, ago(n.updated)))) : [h('p', { class: 't-callout muted', style: 'padding:12px' }, 'Aucune note.')]));
    }
    function drawEdit() {
      if (!cur) { edit.replaceChildren(h('div', { class: 'empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Aucune note'), h('p', { class: 't-callout muted' }, 'Ce bloc-notes est libre : il n\'est lié à aucune fiche.'))); return; }
      const t = h('input', { class: 'bare t-title2', id: 'tt', type: 'text', placeholder: 'Titre', value: cur.title, style: 'font-size:28px' });
      const x = h('textarea', { class: 'bare t-body', id: 'tx', rows: 14, placeholder: 'Idées, essais à faire, remarques...', style: 'resize:none;line-height:1.65;max-width:66ch' }); x.value = cur.text;
      const st = h('span', { class: 'st st-ok', role: 'status', hidden: true });
      const saveSoon = () => { clearTimeout(tmr); st.hidden = true; tmr = setTimeout(async () => { try { const r = await api('/api/bloc/' + cur.id, { method: 'PUT', json: { title: t.value, text: x.value } }); Object.assign(cur, r); st.replaceChildren(S('check'), 'Enregistré automatiquement à ' + hhmm()); st.hidden = false; drawSide(); } catch (e) { st.replaceChildren(e.message); st.hidden = false; } }, 700); };
      t.addEventListener('input', saveSoon); x.addEventListener('input', saveSoon);
      edit.replaceChildren(h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:16px' }, st, h('button', { type: 'button', class: 'btn btn-danger btn-sm', onclick: async () => { await api('/api/bloc/' + cur.id, { method: 'DELETE' }); items = items.filter(n => n.id !== cur.id); cur = items[0] || null; drawSide(); drawEdit(); } }, S('trash'), 'Supprimer cette note')),
        h('label', { for: 'tt', style: 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)' }, 'Titre'), t, h('label', { for: 'tx', style: 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)' }, 'Texte'), x);
    }
    drawSide(); drawEdit();
    shell('notes', [
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:16px' }, h('h1', { class: 't-large' }, 'Bloc-notes'),
        h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => { const n = await api('/api/bloc', { json: { title: 'Nouvelle note', text: '' } }); items.unshift(n); cur = n; drawSide(); drawEdit(); } }, S('plus'), 'Nouvelle note')),
      h('div', { class: 'card notes-grid' }, side, edit)
    ]);
  }

  // ---------- agenda ----------
  const pad = n => String(n).padStart(2, '0'); const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseIso = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const monday = d => addDays(d, -((d.getDay() + 6) % 7));
  const COLORS = [['teal', 'Vert'], ['blue', 'Bleu'], ['indigo', 'Indigo'], ['mauve', 'Mauve'], ['pink', 'Rose'], ['red', 'Rouge'], ['amber', 'Orange'], ['yellow', 'Jaune'], ['brown', 'Marron'], ['gray', 'Gris']];
  const HOUR0 = 8; const HOUR1 = 18; // grille horaire 08:00 - 18:00 (60 px par heure)
  const minutes = t => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0); };
  const dLong = d => capFirst(d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));
  async function viewAgenda(openId) {
    const today = parseIso(state.me.today); let mode = 'month'; let cursor = new Date(today); let events = []; let openEv = null;
    const cal = h('section', { class: 'card', style: 'flex:999 1 640px;min-width:0;overflow:hidden;padding-bottom:0' });
    const panel = h('aside', { class: 'side pad ag-panel', 'aria-live': 'polite' });
    const range = () => {
      if (mode === 'day') return [cursor, cursor];
      if (mode === 'week') { const s = monday(cursor); return [s, addDays(s, 6)]; }
      const s = monday(new Date(cursor.getFullYear(), cursor.getMonth(), 1)); const e = addDays(monday(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)), 6); return [s, e];
    };
    async function load() { const [a, b] = range(); events = (await api(`/api/agenda?from=${iso(a)}&to=${iso(b)}`)).items; draw(); }
    const title = () => mode === 'month' ? capFirst(cursor.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })) : mode === 'week' ? (() => { const s = monday(cursor); const e = addDays(s, 6); return s.getMonth() === e.getMonth() ? `${s.getDate()} au ${e.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}` : `${s.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })} au ${e.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}`; })() : dLong(cursor);
    const move = n => { if (mode === 'month') cursor = new Date(cursor.getFullYear(), cursor.getMonth() + n, 1); else cursor = addDays(cursor, n * (mode === 'week' ? 7 : 1)); load(); };
    const byTime = (a, b) => (a.time || '').localeCompare(b.time || '');
    const unit = mode => mode === 'month' ? 'Mois' : mode === 'week' ? 'Semaine' : 'Jour';
    function evBtn(e) {
      return h('button', { type: 'button', class: 'ev' + (openEv && openEv.id === e.id ? ' on' : ''), style: cv(e.color), 'aria-pressed': String(!!(openEv && openEv.id === e.id)), title: e.title, onclick: ev => { ev.stopPropagation(); showEvent(e); } },
        h('span', { class: 'dot' }), h('span', { class: 'ev-t' }, (e.time ? e.time + ' ' : '') + e.title), e.note ? ico('lines', 'nm') : null);
    }
    function weekGrid(days) {
      const n = days.length; const cols = `60px repeat(${n},minmax(0,1fr))`;
      const head = h('div', { class: 'wk', style: `grid-template-columns:${cols};border-bottom:1px solid var(--line)` }, h('div'), days.map(day => h('div', { class: 'wh' + (iso(day) === iso(today) ? ' today' : '') }, capFirst(day.toLocaleDateString('fr-FR', { weekday: 'short' })), h('b', {}, day.getDate()))));
      const allDay = events.filter(e => !e.time);
      const allRow = allDay.length ? h('div', { class: 'wk', style: `grid-template-columns:${cols};border-bottom:1px solid var(--line);padding:8px 0` }, h('div', { class: 't-caption muted', style: 'text-align:right;padding-right:12px;padding-top:4px' }, 'Journée'), days.map(day => h('div', { style: 'padding:0 6px;display:flex;flex-direction:column;gap:2px;min-width:0' }, allDay.filter(e => e.date === iso(day)).map(evBtn)))) : null;
      const labels = h('div', {}, Array.from({ length: HOUR1 - HOUR0 + 1 }, (_, i) => h('div', { class: 'tl' }, pad(HOUR0 + i) + ':00')));
      const nowMin = (() => { const t = new Date(); return t.getHours() * 60 + t.getMinutes(); })();
      const colEls = days.map(day => {
        const k = iso(day); const list = events.filter(e => e.date === k && e.time).sort(byTime);
        const lanes = []; // simple repartition des evenements qui se chevauchent
        list.forEach(e => { const s = minutes(e.time); let l = lanes.findIndex(end => end <= s); if (l < 0) { l = lanes.length; lanes.push(0); } lanes[l] = s + 50; e._lane = l; });
        const nl = Math.max(1, lanes.length);
        const col = h('div', { class: 'col' + (k === iso(today) ? ' today' : ''), onclick: ev => { if (ev.target !== col) return; const mins = Math.floor(ev.offsetY / 30) * 30 + HOUR0 * 60; showForm(k, null, pad(Math.floor(mins / 60)) + ':' + pad(mins % 60)); } },
          list.map(e => { const top = Math.max(0, Math.min((HOUR1 - HOUR0) * 60, minutes(e.time) - HOUR0 * 60)); const w = `calc((100% - 24px) / ${nl})`;
            return h('button', { type: 'button', class: 'we', style: `${cv(e.color)};top:${top}px;height:50px;left:calc(8px + ${e._lane} * ${w});right:auto;width:calc(${w} - 4px)`, onclick: ev => { ev.stopPropagation(); showEvent(e); } }, h('b', {}, e.title), h('span', {}, e.time)); }),
          k === iso(today) && nowMin >= HOUR0 * 60 && nowMin <= HOUR1 * 60 + 60 ? h('div', { class: 'now', style: `top:${nowMin - HOUR0 * 60}px`, 'aria-label': 'Heure actuelle' }) : null);
        return col;
      });
      return h('div', {}, head, allRow, h('div', { class: 'wk', style: `grid-template-columns:${cols};padding-top:12px;padding-bottom:16px` }, labels, colEls));
    }
    function draw() {
      const nav = (label, id, n) => h('button', { type: 'button', class: 'btn btn-secondary btn-icon', 'aria-label': label, onclick: () => move(n) }, ico(id));
      const U = unit(mode).toLowerCase();
      const bar = h('div', { style: 'display:flex;align-items:center;gap:12px;flex-wrap:wrap' },
        h('h1', { class: 't-large', style: 'margin-right:8px' }, title()),
        nav(capFirst(U) === 'Mois' ? 'Mois précédent' : U === 'semaine' ? 'Semaine précédente' : 'Jour précédent', 'chev-l', -1), nav(U === 'mois' ? 'Mois suivant' : U === 'semaine' ? 'Semaine suivante' : 'Jour suivant', 'chev-r', 1),
        h('button', { type: 'button', class: 'btn btn-secondary', onclick: () => { cursor = new Date(today); load(); } }, 'Aujourd\'hui'), h('span', { style: 'flex:1' }),
        h('div', { class: 'seg', role: 'group', 'aria-label': 'Vue' }, [['month', 'Mois'], ['week', 'Semaine'], ['day', 'Jour']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(mode === k), onclick: () => { mode = k; load(); } }, l))),
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => showForm(iso(mode === 'month' ? (cursor.getMonth() === today.getMonth() && cursor.getFullYear() === today.getFullYear() ? today : new Date(cursor.getFullYear(), cursor.getMonth(), 1)) : cursor)) }, S('plus'), 'Nouveau rappel'));
      barBox.replaceChildren(bar);
      let body;
      if (mode === 'month') {
        const [a] = range(); const weeks = Math.round((range()[1] - a) / 86400000 + 1) / 7; const cells = ['Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.', 'Dim.'].map(n => h('div', { class: 'cal-h', role: 'columnheader' }, n));
        for (let i = 0; i < weeks * 7; i++) {
          const day = addDays(a, i); const k = iso(day); const out = day.getMonth() !== cursor.getMonth(); const list = events.filter(e => e.date === k).sort(byTime);
          const isT = k === iso(today); const sel = openEv && openEv.date === k;
          cells.push(h('div', { class: 'cal-d' + (out ? ' out' : '') + (isT ? ' today' : '') + (sel ? ' sel' : ''), onclick: () => showForm(k) },
            h('button', { type: 'button', class: 'cal-n', 'aria-label': day.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }) + (isT ? ', aujourd\'hui' : ''), 'aria-current': isT ? 'date' : null, onclick: e => { e.stopPropagation(); showForm(k); } }, day.getDate()),
            list.slice(0, 2).map(evBtn), list.length > 2 ? h('button', { type: 'button', class: 'more', onclick: e => { e.stopPropagation(); cursor = day; mode = 'day'; load(); } }, `${list.length - 2} ${plural(list.length - 2, 'autre', 'autres')}`) : null));
        }
        body = h('div', { class: 'cal', role: 'grid' }, cells);
      } else body = weekGrid(mode === 'week' ? Array.from({ length: 7 }, (_, i) => addDays(monday(cursor), i)) : [cursor]);
      cal.replaceChildren(body);
    }
    const barBox = h('div');
    function clearPanel() { openEv = null; panel.classList.remove('has'); panel.replaceChildren(h('div', { class: 'empty', style: 'padding:6px 0' }, h('p', { class: 'w6' }, 'Aucun rappel ouvert'), h('p', { class: 't-callout muted' }, 'Cliquez sur un rappel pour le consulter, ou sur un jour pour en ajouter un.'))); if (events.length || cal.childNodes.length) draw(); }
    function setPanel(...els) { panel.classList.add('has'); panel.replaceChildren(...els); }
    function showForm(date, ev, time) {
      openEv = ev || null;
      const t = h('input', { class: 'input', id: 'ti', type: 'text', value: ev ? ev.title : '', placeholder: 'Ex : Appel fournisseur' });
      const dt = h('input', { class: 'input', id: 'da', type: 'date', value: ev ? ev.date : date });
      const tm = h('input', { class: 'input num', id: 'he', type: 'time', value: ev ? ev.time : (time || '') });
      let colVal = ev ? ev.color : 'teal';
      const sws = h('div', { style: 'display:grid;grid-template-columns:repeat(5,44px);gap:8px 10px', role: 'radiogroup', 'aria-label': 'Couleur du rappel' }, COLORS.map(([k, l]) => h('button', { type: 'button', class: 'swatch' + (k === colVal ? ' on' : ''), role: 'radio', 'aria-checked': String(k === colVal), 'aria-label': l, style: cv(k) + ';margin:6px', onclick: () => { colVal = k; sws.querySelectorAll('.swatch').forEach((x, i) => { const on = COLORS[i][0] === k; x.classList.toggle('on', on); x.setAttribute('aria-checked', String(on)); }); legend.textContent = ': ' + l.toLowerCase(); } })));
      const legend = h('span', { class: 'muted', style: 'font-weight:400' }, ': ' + COLORS.find(c => c[0] === colVal)[1].toLowerCase());
      const note = h('textarea', { class: 'input', id: 'no', rows: 3, placeholder: 'Ajouter une note' }); note.value = ev ? (ev.note || '') : '';
      const err = h('p', { class: 'err', role: 'alert' });
      const save = async e => {
        if (e) e.preventDefault(); err.textContent = '';
        const body = { title: t.value, date: dt.value, time: tm.value, color: colVal, note: note.value };
        try { const r = ev ? await api('/api/agenda/' + ev.id, { method: 'PUT', json: body }) : await api('/api/agenda', { json: body }); const d = parseIso(r.date || dt.value); if (mode === 'month' ? (d.getMonth() !== cursor.getMonth() || d.getFullYear() !== cursor.getFullYear()) : false) cursor = d; await load(); if (ev || r.id) showEvent(r.id ? r : ev); else clearPanel(); } catch (er) { err.textContent = er.message; }
      };
      setPanel(h('form', { style: 'display:flex;flex-direction:column;gap:18px', onsubmit: save },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px' }, h('h2', { class: 't-title3', id: 'ft' }, ev ? 'Modifier le rappel' : 'Nouveau rappel'), h('button', { type: 'button', class: 'btn btn-secondary btn-icon', 'aria-label': 'Fermer', onclick: () => clearPanel() }, ico('x'))),
        h('div', { class: 'field' }, h('label', { class: 'label', for: 'ti' }, 'Intitulé'), t),
        h('div', { style: 'display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:12px' }, h('div', { class: 'field' }, h('label', { class: 'label', for: 'da' }, 'Date'), dt), h('div', { class: 'field' }, h('label', { class: 'label', for: 'he' }, 'Heure'), tm)),
        h('fieldset', { style: 'border:0;margin:0;padding:0;display:flex;flex-direction:column;gap:10px' }, h('legend', { class: 'label', style: 'padding:0;margin-bottom:6px' }, 'Couleur ', legend), sws),
        h('div', { class: 'field' }, h('label', { class: 'label', for: 'no' }, 'Note ', h('span', { class: 'muted', style: 'font-weight:400' }, '(facultative)')), note), err,
        h('div', { style: 'display:flex;gap:10px;justify-content:flex-end' }, h('button', { type: 'button', class: 'btn btn-secondary', onclick: () => { if (ev) showEvent(ev); else clearPanel(); } }, 'Annuler'), h('button', { type: 'submit', class: 'btn btn-primary' }, 'Enregistrer'))));
      draw(); t.focus();
    }
    function showEvent(e) {
      openEv = e; const d = parseIso(e.date);
      setPanel(h('div', { style: 'display:flex;flex-direction:column;gap:18px' },
        h('div', { style: 'display:flex;align-items:flex-start;gap:12px' }, h('span', { class: 'dot', style: cv(e.color) + ';width:14px;height:14px;margin-top:8px' }), h('h2', { class: 't-title2', id: 'rt', style: 'flex:1' }, e.title), h('button', { type: 'button', class: 'btn btn-secondary btn-icon', 'aria-label': 'Fermer', onclick: () => clearPanel() }, ico('x'))),
        h('div', { style: 'display:flex;flex-direction:column;gap:8px' }, h('p', { class: 't-callout', style: 'display:flex;align-items:center;gap:10px' }, S('cal'), dLong(d)), e.time ? h('p', { class: 't-callout num', style: 'display:flex;align-items:center;gap:10px' }, S('clock'), e.time) : null),
        e.note ? h('div', { class: 'inset', style: 'padding:14px 16px' }, h('p', { class: 't-caption muted w5', style: 'margin-bottom:4px' }, 'Note'), h('p', { class: 't-callout', style: 'white-space:pre-wrap' }, e.note)) : null,
        h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-top:4px' },
          h('button', { type: 'button', class: 'btn btn-secondary btn-sm', onclick: () => showForm(e.date, e) }, S('pencil'), 'Modifier'),
          h('button', { type: 'button', class: 'btn btn-danger btn-sm', onclick: async () => { await api('/api/agenda/' + e.id, { method: 'DELETE' }); openEv = null; panel.classList.remove('has'); await load(); clearPanel(); } }, S('trash'), 'Supprimer'),
          h('button', { type: 'button', class: 'btn btn-plain btn-sm', onclick: () => clearPanel() }, 'Fermer'))));
      draw();
    }
    shell('agenda', [barBox, h('div', { style: 'display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap' }, cal, panel)], { max: 1320, top: 44, gap: 20 });
    clearPanel();
    if (openId) { try { const ev = await api('/api/agenda/' + openId); cursor = parseIso(ev.date); await load(); showEvent(ev); return; } catch { /* rappel supprime */ } }
    await load();
  }

  // ---------- veille ----------
  const TONES = [['#D7EAE4', '#0A5E55'], ['#E7E3F4', '#4A3F8C'], ['#F6E1E9', '#8E2F55'], ['#E1EAF6', '#2A5591'], ['#FAE9D6', '#7F4405'], ['#E6EAE3', '#3E4A3A']];
  const toneOf = s => { let n = 0; for (const c of String(s)) n = (n * 31 + c.charCodeAt(0)) >>> 0; return TONES[n % TONES.length]; };
  const initials = s => { const w = String(s).replace(/[^\p{L}\p{N} ]/gu, '').split(/\s+/).filter(Boolean); return ((w[0] || '?').charAt(0) + (w[1] ? w[1].charAt(0) : (w[0] || '').charAt(1) || '')).toUpperCase(); };
  const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  async function viewVeille() {
    const v = await api('/api/veille');
    const dateFr = s => s ? new Date(s).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }).replace(/^1 /, '1er ') : '';
    const arts = v.articles.slice(0, 24);
    const tile = (a, size, extra) => { const [bg, fg] = toneOf(a.source); return h('span', { class: 'ap', style: `background:${bg};color:${fg};font-size:${size}px;${extra || ''}` }, a.source); };
    const meta = a => h('span', { class: 'meta' }, a.source + (a.date ? ', ' + dateFr(a.date) : ''), S('ext'));
    const card = (a, o = {}) => { const [bg, fg] = toneOf(a.source);
      return h('a', { class: 'art', href: a.url, target: '_blank', rel: 'noopener noreferrer', style: o.span ? 'grid-column:span ' + o.span : null },
        o.size ? tile(a, o.size, 'height:' + o.h + 'px') : null,
        h('span', { class: 'art-b', style: o.size ? null : 'padding-top:24px' }, o.size ? null : h('span', { class: 'fav', style: `background:${bg};color:${fg}` }, initials(a.source)), h('h3', { class: 'art-t', style: o.title ? 'font-size:' + o.title + 'px' : null }, a.title), meta(a))); };
    const hero = arts[0]; const rest = arts.slice(1);
    const heroEl = hero ? (() => { const [bg, fg] = toneOf(hero.source); return h('a', { class: 'art hero', href: hero.url, target: '_blank', rel: 'noopener noreferrer', style: 'display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,1fr);min-height:400px' },
      h('span', { class: 'ap', style: `background:${bg};color:${fg};font-size:56px;padding:36px` }, hero.source),
      h('span', { class: 'art-b', style: 'padding:40px;gap:16px;justify-content:center' }, h('span', { class: 'meta', style: 'margin-top:0' }, hero.source + (hero.date ? ', ' + dateFr(hero.date) : '')), h('h2', { class: 'art-t', style: 'font-size:34px;line-height:1.15;letter-spacing:-.022em' }, hero.title), h('span', { class: 'btn btn-tinted', style: 'align-self:flex-start;margin-top:8px' }, 'Lire l\'article', S('ext')))); })() : null;
    const pattern = [{ span: 2, size: 40, h: 200, title: 22 }, { size: 30, h: 200 }, {}, { size: 44, h: 150 }, {}];
    const grid = rest.map((a, i) => card(a, i < pattern.length ? pattern[i] : {}));
    const salonDate = s => { const t = String(s.dates || ''); const m = t.match(/(\d{1,2})(?:\s*(?:-|au|et|à)\s*\d{1,2})?\s*(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)/i); if (m) return [capFirst(m[2].toLowerCase().replace('fevrier', 'février').replace('aout', 'août').replace('decembre', 'décembre')), m[1]]; const y = t.match(/\d{4}/); return [y ? y[0] : '', '']; };
    const mon = monday(parseIso(state.me.today));
    shell('veille', [
      h('div', { style: 'display:flex;align-items:baseline;justify-content:space-between;gap:16px;flex-wrap:wrap' }, h('h1', { class: 't-display' }, 'Veille de la semaine'), h('span', { class: 't-title3 muted', style: 'font-weight:500' }, 'Semaine du ' + mon.getDate() + (mon.getDate() === 1 ? 'er ' : ' ') + MONTHS[mon.getMonth()])),
      heroEl || h('section', { class: 'card empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Aucun article récupéré pour le moment'), h('p', { class: 't-callout muted' }, 'Les sites suivis ci-dessous restent consultables.')),
      grid.length ? h('section', { 'aria-label': 'Articles', class: 'art-grid', style: 'display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px' }, grid) : null,
      v.ko && v.ko.length ? h('p', { class: 't-caption muted' }, 'Flux injoignables : ' + v.ko.join(', ') + '.') : null,
      h('div', { class: 'vl2', style: 'display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:20px;align-items:start;margin-top:20px' },
        h('section', { 'aria-labelledby': 'sal' }, h('h2', { class: 't-title2', id: 'sal', style: 'margin-bottom:14px' }, 'Salons'),
          h('div', { class: 'card', style: 'padding:4px 24px' }, v.salons.map(s => { const [mo, dy] = salonDate(s); return h('a', { class: 'salon', href: s.url, target: '_blank', rel: 'noopener noreferrer' },
            h('span', { class: 'cal-b' }, mo ? h('span', { class: 't-caption muted w6' }, mo) : ico('cal', '', 'color:var(--text-2)'), dy ? h('span', { class: 'w6 num', style: 'font-size:20px;line-height:1.1' }, dy) : null),
            h('span', { style: 'display:flex;flex-direction:column;gap:2px' }, h('span', { class: 'w6', style: 'font-size:17px' }, s.name), s.dates ? h('span', { class: 't-sub muted' }, s.dates) : h('span', { class: 't-sub nr' }, 'Dates : non renseigné'), s.place ? h('span', { class: 't-sub muted', style: 'display:flex;align-items:center;gap:6px' }, S('pin'), s.place) : null), ico('ext', 'ico-s', 'color:var(--text-2)')); }))),
        h('section', { 'aria-labelledby': 'sit' }, h('h2', { class: 't-title2', id: 'sit', style: 'margin-bottom:14px' }, 'Sites suivis'),
          h('div', { style: 'display:flex;flex-direction:column;gap:10px' }, v.sites.map(s => { const [bg, fg] = toneOf(s.name); return h('a', { class: 'site', href: s.url, target: '_blank', rel: 'noopener noreferrer' }, h('span', { class: 'fav', style: `background:${bg};color:${fg}` }, initials(s.name)),
            h('span', { style: 'flex:1;display:flex;flex-direction:column;min-width:0' }, h('span', { class: 'w6' }, s.name), h('span', { class: 't-caption muted' }, hostOf(s.url))), ico('ext', 'ico-s', 'color:var(--text-2)')); }))))
    ], { max: 1200, top: 56, gap: 28 });
  }

  // ---------- routeur ----------
  async function route() {
    if (!state.me) return;
    const parts = (location.hash.replace(/^#/, '') || '/').split('/').filter(Boolean);
    try {
      if (!parts.length) return await viewHome();
      const [a, b] = parts;
      if (a === 'consulter') return await viewConsulter(/^MP-\d+$/.test(b || '') ? b : null);
      if (a === 'ajout') return await viewAjout();
      if (a === 'fiche' && /^MP-\d+$/.test(b || '')) return await viewFiche(b);
      if (a === 'comparaison') return await viewComparaison();
      if (a === 'fiches' || a === 'favoris') return await viewFiches();
      if (a === 'notes') return await viewNotes();
      if (a === 'agenda') return await viewAgenda(/^[a-f0-9]+$/.test(b || '') ? b : null);
      if (a === 'veille') return await viewVeille();
      if (a === 'espace') return await viewEspace();
      location.hash = '#/';
    } catch (e) { if (e.message !== 'Connexion requise') shell('', [h('div', { class: 'card empty' }, h('p', { class: 'w6', style: 'font-size:17px' }, 'Une erreur est survenue'), h('p', { class: 'err' }, e.message), h('a', { class: 'btn btn-tinted', href: '#/' }, 'Retour à l\'accueil'))], { narrow: true }); }
  }
  // Page rouverte (nouvel onglet ou navigateur ferme puis relance) sans "Rester connectee" : retour a l'ecran de connexion
  async function boot() {
    mountSprite();
    let again = false; try { again = !sessionStorage.getItem('fh_tab') && localStorage.getItem('fh_keep') !== '1'; } catch { again = false; }
    if (again) { try { await fetch('/api/logout', { method: 'POST' }); } catch { /* ignore */ } history.replaceState(null, '', location.pathname + '#/'); renderLogin(); return; }
    try { state.me = await api('/api/me'); } catch { renderLogin(); return; }
    try { sessionStorage.setItem('fh_tab', '1'); } catch { /* ignore */ }
    route();
  }
  window.addEventListener('hashchange', route);
  boot();
})();
